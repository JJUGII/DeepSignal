#!/bin/bash
# macOS에서 Windows 배포용 ZIP 파일 생성
# 실행: ./zip배포용_맥에서실행.sh

cd "$(dirname "$0")/.."

echo "Windows 배포용 ZIP 생성 중..."
zip -r -X deepsignal_windows.zip deepsignal_install/ \
    --exclude "*.DS_Store" \
    --exclude "*/__pycache__/*" \
    --exclude "*/*.pyc" \
    --exclude "*/._*" \
    --exclude "deepsignal_install/._*"

echo ""
echo "완료: deepsignal_windows.zip"
du -sh deepsignal_windows.zip
echo ""
echo "이 ZIP 파일을 Windows PC에 복사 후 압축 해제하세요."
