@echo off
cd /d "%~dp0"
setlocal EnableDelayedExpansion

echo.
echo ============================================================
echo   DeepSignal - Coin Auto Trading (Upbit)
echo   WebSocket driven / Real-time TP/SL monitoring
echo ============================================================
echo.

:: venv Python 경로 감지 (Windows: Scripts\, MSYS2: bin\)
if exist ".venv\Scripts\python.exe" (
    set VENV_PYTHON=.venv\Scripts\python.exe
) else if exist ".venv\bin\python.exe" (
    set VENV_PYTHON=.venv\bin\python.exe
) else (
    echo [ERROR] Virtual environment not found.
    echo   Please run 1_install.bat first.
    pause
    exit /b 1
)

if not exist ".env" (
    echo [ERROR] .env file not found.
    echo   Please run 1_install.bat first and enter API keys.
    pause
    exit /b 1
)

:: Check if real trading mode is active
findstr /i "UPBIT_DRY_RUN=false" .env > nul
if %ERRORLEVEL% equ 0 (
    findstr /i "CRYPTO_PAPER_MODE=false" .env > nul
    if %ERRORLEVEL% equ 0 (
        echo ============================================================
        echo   [WARNING] LIVE TRADING MODE ACTIVE
        echo   UPBIT_DRY_RUN=false + CRYPTO_PAPER_MODE=false detected.
        echo   Real money orders will be placed!
        echo ============================================================
        echo.
        choice /C YN /M "Continue? (Y=Yes / N=Cancel)"
        if %ERRORLEVEL% equ 2 exit /b 0
        echo.
    )
)

echo   Started: %date% %time%
echo   Close this window or press Ctrl+C to stop.
echo.
echo   NOTE: run_binance_stream.bat must be running in a separate window.
echo.

:loop
%VENV_PYTHON% main.py crypto-auto-runner ^
    --broker upbit ^
    --interval-minutes 1.0 ^
    --take-profit-pct 2.0 ^
    --take-profit-buffer-pct 0.05 ^
    --stop-loss-pct -1.5 ^
    --stop-loss-buffer-pct 0.05 ^
    --min-volume-ratio 0.3 ^
    --crypto-universe all_krw ^
    --max-scan-markets 100 ^
    --max-orders-per-day 0 ^
    --output-dir outputs ^
    --wait-fill-seconds 60.0 ^
    --fill-poll-interval 3.0 ^
    --execute

set EXIT=%ERRORLEVEL%
echo.
echo   [%time%] Process stopped (code: %EXIT%)
if %EXIT% equ 0 exit /b 0

echo   Abnormal exit - restarting in 10 seconds (Ctrl+C to cancel)
timeout /t 10
goto loop
