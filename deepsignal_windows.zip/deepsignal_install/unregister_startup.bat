@echo off

set STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
set VBS=%STARTUP%\DeepSignal.vbs

echo.
if exist "%VBS%" (
    del /f /q "%VBS%"
    echo [OK] DeepSignal removed from startup.
) else (
    echo [INFO] DeepSignal was not registered in startup.
)

echo.
pause
