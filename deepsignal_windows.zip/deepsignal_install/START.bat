@echo off
cd /d "%~dp0"
setlocal EnableDelayedExpansion

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] Not installed. Run 1_install.bat first.
    pause
    exit /b 1
)
if not exist ".env" (
    echo [ERROR] .env not found. Run 1_install.bat first.
    pause
    exit /b 1
)

:menu
cls
echo.
echo ============================================================
echo   DeepSignal
echo ============================================================
echo.
echo   [1] Start  (coin + stock + dashboard)
echo   [2] Settings  (edit .env)
echo   [3] Exit
echo.
set /p CHOICE="   Select (1-3): "

if "%CHOICE%"=="1" goto start_all
if "%CHOICE%"=="2" goto settings
if "%CHOICE%"=="3" exit /b 0
goto menu

:start_all
cls
echo.
echo   Starting DeepSignal...
echo.

set ROOT=%~dp0

:: 1. Binance price stream (minimized background window)
start /min /d "%ROOT%" "DS-Stream" cmd /k "%ROOT%.venv\Scripts\python.exe %ROOT%main.py binance-stream --output-dir outputs"
timeout /t 2 > nul

:: 2. Coin auto runner (minimized background window)
:: Note: --execute is omitted here. To enable real orders, set UPBIT_DRY_RUN=false + CRYPTO_PAPER_MODE=false in .env
start /min /d "%ROOT%" "DS-Coin" cmd /k "%ROOT%.venv\Scripts\python.exe %ROOT%main.py crypto-auto-runner --broker upbit --interval-minutes 1.0 --take-profit-pct 2.0 --take-profit-buffer-pct 0.05 --stop-loss-pct -1.5 --stop-loss-buffer-pct 0.05 --min-volume-ratio 0.3 --crypto-universe all_krw --max-scan-markets 100 --max-orders-per-day 0 --output-dir outputs --wait-fill-seconds 60.0 --fill-poll-interval 3.0"
timeout /t 2 > nul

:: 3. Stock daily runner (minimized background window)
start /min /d "%ROOT%" "DS-Stock" cmd /k "%ROOT%.venv\Scripts\python.exe %ROOT%main.py run-daily --log-json"
timeout /t 3 > nul

:: 4. Web UI - browser opens automatically after server starts
echo   All runners started. Opening web dashboard...
echo.
"%ROOT%.venv\Scripts\python.exe" "%ROOT%main.py" web-ui

echo.
echo   Web UI closed. Stop background runners? (close their windows manually)
pause
goto menu

:settings
start notepad .env
goto menu
