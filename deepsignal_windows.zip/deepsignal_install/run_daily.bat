@echo off
cd /d "%~dp0"
setlocal EnableDelayedExpansion

echo.
echo ============================================================
echo   DeepSignal - Daily Stock AI Runner (KIS)
echo   Run after 9:00 AM KST (market open)
echo ============================================================
echo.

:: venv Python 경로 감지 (Windows: Scripts\, MSYS2: bin\)
if exist ".venv\Scripts\python.exe" (
    set VENV_PYTHON=.venv\Scripts\python.exe
) else if exist ".venv\bin\python.exe" (
    set VENV_PYTHON=.venv\bin\python.exe
) else (
    echo [ERROR] Virtual environment not found.
    echo   Please run 1_install.bat first.
    pause
    exit /b 1
)

if not exist ".env" (
    echo [ERROR] .env file not found. Run 1_install.bat first.
    pause
    exit /b 1
)

findstr /i "KIS_APP_KEY=" .env | findstr /v "^#\|=$" > nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] KIS_APP_KEY is not set in .env
    echo   Get a KIS Open API key and enter it in .env
    pause
    exit /b 1
)

if not exist "logs" mkdir logs
echo   Started: %date% %time%
echo.

%VENV_PYTHON% main.py run-daily --log-json 1>> "logs\run_daily_%date:~0,4%%date:~5,2%%date:~8,2%.log" 2>&1

set EXIT=%ERRORLEVEL%
if %EXIT% neq 0 (
    echo.
    echo [ERROR] Run failed (code: %EXIT%). Check the logs folder.
    pause
    exit /b %EXIT%
)
echo.
echo   Done. Check the logs folder for results.
pause
