@echo off
cd /d "%~dp0"

:: venv Python 경로 감지 (Windows: Scripts\, MSYS2: bin\)
if exist ".venv\Scripts\python.exe" (
    set VENV_PYTHON=.venv\Scripts\python.exe
) else if exist ".venv\bin\python.exe" (
    set VENV_PYTHON=.venv\bin\python.exe
) else (
    echo [ERROR] Please run 1_install.bat first.
    pause
    exit /b 1
)

echo [DeepSignal] Starting dashboard...
%VENV_PYTHON% main.py dashboard
pause
