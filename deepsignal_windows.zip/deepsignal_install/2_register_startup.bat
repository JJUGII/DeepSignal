@echo off
cd /d "%~dp0"

set ROOT=%~dp0
set STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
set VBS=%STARTUP%\DeepSignal.vbs

echo.
echo Creating startup launcher...

(
echo Dim sRoot
echo sRoot = "%ROOT%"
echo Set objShell = CreateObject("WScript.Shell"^)
echo objShell.Run Chr(34^) ^& sRoot ^& "autostart.bat" ^& Chr(34^), 0, False
) > "%VBS%"

if exist "%VBS%" (
    echo.
    echo [OK] DeepSignal registered as startup program.
    echo      Will start automatically on next login.
    echo.
    echo      Location: %VBS%
) else (
    echo.
    echo [ERROR] Registration failed. Check permissions.
)

echo.
pause
