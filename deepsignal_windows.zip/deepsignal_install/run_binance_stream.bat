@echo off
cd /d "%~dp0"
setlocal EnableDelayedExpansion

echo.
echo ============================================================
echo   DeepSignal - Binance Price Stream
echo   Feeds real-time data to ML engine (keep this window open)
echo ============================================================
echo.

:: venv Python 경로 감지 (Windows: Scripts\, MSYS2: bin\)
if exist ".venv\Scripts\python.exe" (
    set VENV_PYTHON=.venv\Scripts\python.exe
) else if exist ".venv\bin\python.exe" (
    set VENV_PYTHON=.venv\bin\python.exe
) else (
    echo [ERROR] Virtual environment not found.
    echo   Please run 1_install.bat first.
    pause
    exit /b 1
)

echo   Started: %date% %time%
echo   Close this window or press Ctrl+C to stop.
echo.

:loop
%VENV_PYTHON% main.py binance-stream --output-dir outputs

set EXIT=%ERRORLEVEL%
echo.
echo   [%time%] Stream disconnected (code: %EXIT%)
if %EXIT% equ 0 exit /b 0

echo   Reconnecting in 5 seconds...
timeout /t 5 > nul
goto loop
