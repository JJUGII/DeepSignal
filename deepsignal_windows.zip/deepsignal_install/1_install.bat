@echo off
cd /d "%~dp0"
setlocal EnableDelayedExpansion

echo.
echo ============================================================
echo   DeepSignal Installer v1.1
echo   Coin (Upbit) + Stock (KIS) Auto Trading System
echo ============================================================
echo.

:: Check admin
net session >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [WARN] Not running as Administrator.
    echo   Right-click install.bat and select "Run as administrator"
    echo   Press any key to continue anyway...
    pause > nul
)

:: --------------------------------------------------
:: 1. Python 3.11+ check
:: --------------------------------------------------
echo [1/6] Checking Python version...
python --version 2>nul | findstr /R "3\.[1-9][0-9]*\." > nul
if %ERRORLEVEL% neq 0 (
    echo.
    echo [ERROR] Python 3.11 or higher is required.
    echo.
    echo   1. Download Python 3.11+ from:
    echo      https://www.python.org/downloads/
    echo.
    echo   2. IMPORTANT: Check "Add python.exe to PATH" during install!
    echo.
    echo   3. After install, close this window and run install.bat again.
    echo.
    pause
    exit /b 1
)
for /f "tokens=2" %%V in ('python --version 2^>nul') do set PY_VER=%%V
echo   OK - Python %PY_VER% found

:: MSYS2 감지 (경로에 msys64 포함 여부)
set IS_MSYS2=0
for /f "tokens=*" %%P in ('python -c "import sys; print(sys.executable)" 2^>nul') do set PY_EXE=%%P
echo %PY_EXE% | findstr /i "msys64" > nul
if %ERRORLEVEL% equ 0 (
    set IS_MSYS2=1
    echo   [INFO] MSYS2 Python detected - using bin/ layout
)
echo.

:: --------------------------------------------------
:: 2. Create virtual environment
:: --------------------------------------------------
echo [2/6] Setting up virtual environment...

:: venv 존재 여부 확인 (Scripts 또는 bin 레이아웃 모두 체크)
set VENV_OK=0
if exist ".venv\Scripts\python.exe" set VENV_OK=1
if exist ".venv\bin\python.exe"     set VENV_OK=1

if %VENV_OK% equ 1 (
    echo   Already exists - skipping
) else (
    python -m venv .venv
    if %ERRORLEVEL% neq 0 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
    echo   Created .venv
)

:: Python / pip 실행 경로 결정 (Scripts vs bin)
if exist ".venv\Scripts\python.exe" (
    set VENV_PYTHON=.venv\Scripts\python.exe
    set VENV_PIP=.venv\Scripts\pip.exe
) else (
    set VENV_PYTHON=.venv\bin\python.exe
    set VENV_PIP=.venv\bin\pip.exe
)
echo   Using: %VENV_PYTHON%
echo.

:: --------------------------------------------------
:: 3. Upgrade pip
:: --------------------------------------------------
echo [3/6] Upgrading pip...
%VENV_PYTHON% -m pip install --upgrade pip --quiet
if %ERRORLEVEL% neq 0 (
    echo   [WARN] pip upgrade failed - continuing anyway
) else (
    echo   Done
)
echo.

:: --------------------------------------------------
:: 4. Install packages
:: --------------------------------------------------
echo [4/6] Installing packages... (may take a few minutes)
echo   (pandas, lightgbm, scikit-learn, websockets, etc.)

if exist "requirements_windows.txt" (
    %VENV_PYTHON% -m pip install -r requirements_windows.txt
) else (
    %VENV_PYTHON% -m pip install ^
        python-dotenv>=1.0.0 ^
        requests>=2.28.0 ^
        websockets>=12.0 ^
        pandas>=2.0.0 ^
        numpy>=1.24.0 ^
        lightgbm>=4.0.0 ^
        scikit-learn>=1.3.0 ^
        fastapi>=0.111 ^
        "uvicorn[standard]>=0.29" ^
        feedparser>=6.0.0 ^
        yfinance>=0.2.40
)
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Package installation failed.
    echo   Check your internet connection and try again.
    pause
    exit /b 1
)
echo   Done
echo.

:: --------------------------------------------------
:: 5. PyTorch CPU
:: --------------------------------------------------
echo [5/6] Installing PyTorch (CPU, ~500MB)...
echo   Please wait...
%VENV_PYTHON% -m pip install torch --index-url https://download.pytorch.org/whl/cpu --quiet
if %ERRORLEVEL% neq 0 (
    echo [WARN] PyTorch install failed. ML features may be limited.
    echo   You can set CRYPTO_ML_ENSEMBLE=false in .env to disable ML.
) else (
    echo   Done
)
echo.

:: --------------------------------------------------
:: 6. Create folders and .env
:: --------------------------------------------------
echo [6/6] Creating folders and config...
if not exist "logs"    mkdir logs
if not exist "outputs" mkdir outputs
if not exist "data"    mkdir data

if not exist ".env" (
    copy ".env.example" ".env" > nul
    echo   .env created from template
    echo.
    echo ============================================================
    echo   [ACTION REQUIRED] Open .env in Notepad and enter your API keys!
    echo ============================================================
    echo.
    echo   Required keys:
    echo     UPBIT_ACCESS_KEY       - Upbit Open API access key
    echo     UPBIT_SECRET_KEY       - Upbit Open API secret key
    echo     DEEPSIGNAL_NOTIFY_TELEGRAM_BOT_TOKEN  - Telegram bot token
    echo     DEEPSIGNAL_NOTIFY_TELEGRAM_CHAT_ID    - Telegram chat ID
    echo.
    echo   Opening .env in Notepad...
    timeout /t 3 > nul
    notepad .env
) else (
    echo   .env already exists - keeping existing file
)
echo.

echo ============================================================
echo   Installation Complete!
echo ============================================================
echo.
echo   Next steps:
echo   1. Enter API keys in .env (if not done yet)
echo   2. Run: run_binance_stream.bat  (keep this window open)
echo   3. Run: run_crypto.bat          (coin auto trading)
echo.
echo   For stock trading (KIS):
echo   4. Run: run_daily.bat  (run after 9:00 AM KST)
echo.
pause
