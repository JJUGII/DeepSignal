"""설정 관리 — .env 읽기/쓰기 (섹션별 구조화)."""

from __future__ import annotations

import re
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any

# 화면에 노출할 설정 정의 (key, label, type, section, description)
SETTINGS_SCHEMA: list[dict[str, Any]] = [
    # ── 🔒 개인정보 (API 키 / 계좌 / 토큰) ────────────────────────
    # Upbit
    {"key": "UPBIT_ACCESS_KEY",    "label": "Upbit Access Key",  "type": "secret",  "section": "private", "group": "Upbit API",    "desc": "Upbit Open API Access Key"},
    {"key": "UPBIT_SECRET_KEY",    "label": "Upbit Secret Key",  "type": "secret",  "section": "private", "group": "Upbit API",    "desc": "Upbit Open API Secret Key"},
    # KIS
    {"key": "KIS_APP_KEY",         "label": "KIS App Key",       "type": "secret",  "section": "private", "group": "KIS API",      "desc": "한국투자증권 API App Key"},
    {"key": "KIS_APP_SECRET",      "label": "KIS App Secret",    "type": "secret",  "section": "private", "group": "KIS API",      "desc": "한국투자증권 API App Secret"},
    {"key": "KIS_ACCOUNT_NO",      "label": "KIS 계좌번호",       "type": "secret",  "section": "private", "group": "KIS API",      "desc": "CANO 8자리 (예: 12345678)"},
    {"key": "KIS_HTS_ID",          "label": "KIS HTS ID",        "type": "secret",  "section": "private", "group": "KIS API",      "desc": "HTS 로그인 ID"},
    # Telegram
    {"key": "TELEGRAM_BOT_TOKEN",  "label": "Telegram Bot Token","type": "secret",  "section": "private", "group": "Telegram",     "desc": "BotFather에서 발급한 봇 토큰"},
    {"key": "TELEGRAM_CHAT_ID",    "label": "Telegram Chat ID",  "type": "secret",  "section": "private", "group": "Telegram",     "desc": "알림 수신 채팅 ID"},
    {"key": "DEEPSIGNAL_NOTIFY_TELEGRAM_CHAT_ID", "label": "알림 전용 Chat ID", "type": "secret", "section": "private", "group": "Telegram", "desc": "별도 알림 채팅 ID (비우면 위와 동일)"},
    # Webhook
    {"key": "WEBHOOK_URL",         "label": "Webhook URL",       "type": "secret",  "section": "private", "group": "알림 서비스", "desc": "Discord / Slack 웹훅 URL"},

    # ── Upbit 매매 설정 ────────────────────────────────────────────
    {"key": "UPBIT_DRY_RUN",       "label": "Dry Run",           "type": "bool",    "section": "upbit",
     "desc": "활성화하면 실제 주문을 거래소에 보내지 않고 로그만 기록합니다. 설정을 테스트할 때 켜두세요."},
    {"key": "CRYPTO_PAPER_MODE",   "label": "페이퍼 모드",        "type": "bool",    "section": "upbit",
     "desc": "가상 잔고로 매매를 시뮬레이션합니다. 첫 실행 후 14일이 지나야 실거래로 전환되는 안전장치입니다."},
    {"key": "CRYPTO_AUTO_EXECUTE_WITHOUT_APPROVAL", "label": "무승인 자동실행", "type": "bool", "section": "upbit",
     "desc": "텔레그램 승인 버튼 없이 신호 발생 즉시 자동으로 매수/매도를 실행합니다. 충분히 검증한 뒤 활성화하세요."},
    {"key": "CRYPTO_GATE_MODE",    "label": "Gate 모드",          "type": "select",  "section": "upbit",
     "desc": "매수 진입 판단 방식을 선택합니다. hybrid=전통 지표+ML 혼합(권장), ml_primary=ML 결과 우선, ml_only=ML 신호만 사용",
     "options": ["hybrid", "ml_primary", "ml_only"]},
    {"key": "CRYPTO_ENSEMBLE_MODE","label": "Ensemble 모드",      "type": "select",  "section": "upbit",
     "desc": "여러 ML 모델의 신호를 합치는 방식입니다. unanimous=전 모델 동의 시만 매수(보수적), weighted=가중 평균(균형), lgbm_only=LGBM 모델만 사용",
     "options": ["unanimous", "weighted", "lgbm_only"]},
    {"key": "CRYPTO_ML_BUY_GATE",  "label": "ML 매수 게이트",    "type": "bool",    "section": "upbit",
     "desc": "머신러닝 모델의 예측 승률이 55% 이상일 때만 매수를 허용하는 필터입니다. 불확실한 구간 진입을 차단합니다."},
    {"key": "CRYPTO_ML_ENSEMBLE",  "label": "ML 앙상블",          "type": "bool",    "section": "upbit",
     "desc": "LGBM(의사결정 트리 계열), LSTM(시계열 딥러닝), 규칙 기반 3가지 모델을 동시에 실행해 합산한 결과로 최종 신호를 생성합니다."},

    # ── KIS 매매 설정 ──────────────────────────────────────────────
    {"key": "KIS_ENV",             "label": "KIS 환경",           "type": "select",  "section": "kis",
     "desc": "paper=한국투자증권 모의투자 서버(테스트용, 실제 돈 없음), live=실제 계좌 실전 서버. 반드시 확인 후 사용하세요.",
     "options": ["paper", "live"]},
    {"key": "KIS_STOCK_AUTO_EXECUTE_WITHOUT_APPROVAL", "label": "주식 무승인 자동실행", "type": "bool", "section": "kis",
     "desc": "주식 장중(09:00~15:30) 신호 발생 시 텔레그램 승인 없이 바로 주문을 실행합니다."},

    # ── Telegram 표시 설정 ─────────────────────────────────────────
    {"key": "TELEGRAM_MENU_VERBOSE_LOG", "label": "상세 로그",   "type": "bool",    "section": "telegram",
     "desc": "텔레그램 봇 메뉴에서 서버 상태를 조회할 때 간략 요약 대신 상세 로그까지 함께 출력합니다. 기본 꺼짐."},

    # ── 시스템 ─────────────────────────────────────────────────────
    {"key": "DEEPSIGNAL_INACTIVE_AUTO_EXECUTE", "label": "비활동 자동실행", "type": "bool", "section": "system",
     "desc": "지정한 비활동 시간대(예: 밤 20시~다음날 09시)에는 텔레그램을 확인하지 않아도 자동으로 주문을 실행합니다."},
    {"key": "DEEPSIGNAL_INACTIVE_START",        "label": "비활동 시작시각", "type": "text", "section": "system",
     "desc": "비활동 자동실행이 시작되는 시각입니다. 예: 20:00 → 밤 8시부터 다음날 아침 9시까지를 비활동 구간으로 처리합니다."},
    {"key": "DEEPSIGNAL_ALLOW_AFTER_HOURS",     "label": "시간외 거래",     "type": "bool", "section": "system",
     "desc": "주말·공휴일·장 마감 이후에도 거래를 허용합니다. 24시간 운영하는 코인에는 영향이 없으며 주식 종목에 적용됩니다."},
    {"key": "NOTIFY_ON_FAILURE",   "label": "실패 알림",          "type": "bool",    "section": "system",
     "desc": "run-daily 스케줄 작업이 오류로 실패했을 때 등록된 Webhook(Discord/Slack)으로 즉시 알림을 보냅니다."},
    {"key": "MARKET_PERIOD",       "label": "데이터 기간",         "type": "text",    "section": "system",
     "desc": "yfinance로 주가 데이터를 가져올 기간입니다. 예: 6mo=6개월, 1y=1년. 길수록 분석이 정확하지만 처리 시간이 늘어납니다."},
]

SECTION_LABELS = {
    "private":  "🔒 개인정보",
    "upbit":    "Upbit (코인)",
    "kis":      "KIS (주식)",
    "telegram": "Telegram",
    "system":   "시스템",
}

# 개인정보 탭 안의 그룹 순서
PRIVATE_GROUPS = ["Upbit API", "KIS API", "Telegram", "알림 서비스"]

_SECRET_MASK = "••••••••"
_SHOW_LAST = 4  # 시크릿 마지막 N자 표시


def _mask(value: str) -> str:
    if not value:
        return ""
    if len(value) <= _SHOW_LAST:
        return _SECRET_MASK
    return _SECRET_MASK + value[-_SHOW_LAST:]


def read_env_raw(env_path: Path) -> dict[str, str]:
    """모든 KEY=VALUE 파싱 (주석/빈줄 제외)."""
    result: dict[str, str] = {}
    if not env_path.is_file():
        return result
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            k, _, v = line.partition("=")
            result[k.strip()] = v.strip()
    return result


def read_settings(env_path: Path) -> dict[str, Any]:
    """UI에 전달할 설정 구조 (시크릿 마스킹 포함)."""
    raw = read_env_raw(env_path)
    sections: dict[str, list[dict[str, Any]]] = {s: [] for s in SECTION_LABELS}

    for item in SETTINGS_SCHEMA:
        key = item["key"]
        val = raw.get(key, "")
        is_secret = item["type"] == "secret"
        entry: dict[str, Any] = {
            "key":   key,
            "label": item["label"],
            "type":  item["type"],
            "desc":  item.get("desc", ""),
            "value": _mask(val) if is_secret else val,
            "set":   bool(val),
        }
        if "options" in item:
            entry["options"] = item["options"]
        if "group" in item:
            entry["group"] = item["group"]
        sections[item["section"]].append(entry)

    return {
        "sections": sections,
        "section_labels": SECTION_LABELS,
    }


def write_settings(env_path: Path, updates: dict[str, str]) -> tuple[bool, str]:
    """
    updates: {KEY: new_value} — 마스킹 값은 원본 유지.
    .env.bak 백업 후 저장.
    """
    if not env_path.is_file():
        env_path.touch()

    # 백업
    bak = env_path.with_suffix(".bak")
    try:
        shutil.copy2(env_path, bak)
    except Exception:
        pass

    raw = read_env_raw(env_path)

    # 마스킹 값은 무시 (변경 없음)
    schema_map = {s["key"]: s for s in SETTINGS_SCHEMA}
    for key, val in updates.items():
        schema = schema_map.get(key, {})
        if schema.get("type") == "secret":
            if val.startswith(_SECRET_MASK) or val == "":
                # 빈 문자열이면 키 제거, 마스킹이면 원본 유지
                if val == "":
                    raw.pop(key, None)
                continue
        raw[key] = val

    # 파일 재작성 (기존 주석 보존하면서 값만 업데이트)
    try:
        original = env_path.read_text(encoding="utf-8")
        lines = original.splitlines(keepends=True)
        written: set[str] = set()
        new_lines: list[str] = []

        for line in lines:
            stripped = line.strip()
            if stripped.startswith("#") or not stripped:
                new_lines.append(line)
                continue
            if "=" in stripped:
                k = stripped.split("=", 1)[0].strip()
                if k in raw:
                    new_lines.append(f"{k}={raw[k]}\n")
                    written.add(k)
                elif k in updates and updates[k] == "":
                    # 삭제 요청 → 줄 생략
                    pass
                else:
                    new_lines.append(line)
            else:
                new_lines.append(line)

        # 새로 추가된 키 (기존에 없던 것)
        new_keys = [k for k in raw if k not in written]
        if new_keys:
            new_lines.append("\n# Web UI 추가\n")
            for k in new_keys:
                if k in updates:  # 업데이트로 추가된 것만
                    new_lines.append(f"{k}={raw[k]}\n")

        env_path.write_text("".join(new_lines), encoding="utf-8")
        return True, f"{len(updates)}개 설정 저장 완료 (백업: {bak.name})"
    except Exception as e:
        return False, str(e)
