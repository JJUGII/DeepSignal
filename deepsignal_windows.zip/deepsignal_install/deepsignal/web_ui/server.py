"""FastAPI 서버 — 러너 제어 / 설정 / 상태 / 로그 스트리밍."""

from __future__ import annotations

import asyncio
import json
import os
import platform
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from deepsignal.web_ui.auth import (
    get_auth_config,
    create_session_token,
    verify_init_data,
    verify_session_token,
)
from deepsignal.web_ui.event_bus import bus as _event_bus
from deepsignal.web_ui.runner_manager import (
    get_runner_status,
    restart_runner,
    set_pause_state,
    start_runner,
    stop_runner,
)
from deepsignal.web_ui.settings_manager import read_settings, write_settings

# ──────────────────────────────────────────
# 경로 설정
# ──────────────────────────────────────────
_HERE = Path(__file__).parent
_STATIC = _HERE / "static"

@asynccontextmanager
async def _lifespan(app: FastAPI):
    from deepsignal.web_ui.state_watcher import watch_loop
    task = asyncio.create_task(watch_loop(_OUTPUT_DIR, _event_bus))
    try:
        yield
    finally:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


app = FastAPI(title="DeepSignal Web UI", docs_url=None, redoc_url=None, lifespan=_lifespan)

# 전역 설정 (run_web_ui()에서 주입)
_OUTPUT_DIR: Path = Path("outputs")
_PROJECT_ROOT: Path = Path(".")
_ENV_PATH: Path = Path(".env")

# ──────────────────────────────────────────
# 인증 미들웨어
# ──────────────────────────────────────────

_AUTH_BYPASS_PREFIXES = ("/static/", "/auth/", "/ws/")
_AUTH_BYPASS_EXACT   = {"/", "/favicon.ico"}

@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    from dotenv import load_dotenv
    load_dotenv(str(_ENV_PATH), override=False)
    cfg = get_auth_config()

    # 인증 불필요: 로컬 또는 REQUIRE_AUTH=false
    client_host = (request.client.host if request.client else "") or ""
    is_local = client_host in ("127.0.0.1", "::1", "localhost")
    if not cfg["require_auth"] or is_local:
        return await call_next(request)

    # 인증 우회 경로
    path = request.url.path
    if path in _AUTH_BYPASS_EXACT or any(path.startswith(p) for p in _AUTH_BYPASS_PREFIXES):
        return await call_next(request)

    # 세션 토큰 확인 (헤더 우선, 쿼리 파라미터 폴백)
    token = request.headers.get("X-Session-Token") or request.query_params.get("token")
    if token and cfg["bot_token"]:
        user_id = verify_session_token(token, cfg["bot_token"])
        if user_id and (cfg["allowed_id"] == 0 or user_id == cfg["allowed_id"]):
            return await call_next(request)

    # SPA 경로(페이지)는 index.html 반환 → JS에서 인증
    if not path.startswith("/api/") and not path.startswith("/ws/"):
        return FileResponse(str(_STATIC / "index.html"))

    return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=401)


# ──────────────────────────────────────────
# 텔레그램 알림 헬퍼
# ──────────────────────────────────────────

def _telegram_notify_sync(text: str) -> None:
    """텔레그램으로 단순 메시지 발송 (블로킹, to_thread 에서 호출)."""
    from dotenv import load_dotenv
    load_dotenv(str(_ENV_PATH), override=False)
    token = os.environ.get("DEEPSIGNAL_NOTIFY_TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.environ.get("DEEPSIGNAL_NOTIFY_TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat_id:
        return
    try:
        from deepsignal.live_trading.telegram.approval import telegram_api_post
        telegram_api_post(
            "sendMessage",
            {"chat_id": chat_id, "text": text, "parse_mode": "HTML"},
            bot_token=token,
        )
    except Exception:
        pass


async def _telegram_notify(text: str) -> None:
    await asyncio.to_thread(_telegram_notify_sync, text)


# ──────────────────────────────────────────
# 대시보드 데이터 헬퍼
# ──────────────────────────────────────────

def _read_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _make_broker():
    """환경변수 로드 후 UpbitBroker 생성."""
    from dotenv import load_dotenv
    load_dotenv(str(_ENV_PATH), override=False)
    from deepsignal.crypto_trading.upbit_config import load_upbit_config_from_env
    from deepsignal.crypto_trading.upbit_broker import UpbitBroker
    cfg = load_upbit_config_from_env()
    return UpbitBroker(cfg)


def _get_holdings() -> list[dict[str, Any]]:
    """Upbit 보유 코인 조회."""
    try:
        broker = _make_broker()
        holdings = broker.get_crypto_holdings()
        return [
            {
                "market": h.market,
                "quantity": round(float(h.total_quantity), 6),
                "avg_buy_price": round(float(h.avg_buy_price or 0), 2),
                "current_price": round(float(h.current_price or 0), 2),
                "pnl_pct": round(float(h.pnl_pct or 0), 2),
                "valuation_krw": round(float(h.valuation_krw or 0), 0),
            }
            for h in holdings
        ]
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning("holdings fetch failed: %s", e)
        return []


def _get_balance() -> dict[str, float]:
    try:
        broker = _make_broker()
        for b in broker.get_balances():
            if b.currency.upper() == "KRW":
                available = float(b.balance or 0)
                locked    = float(b.locked or 0)
                return {"available": available, "total": available + locked}
        return {"available": 0.0, "total": 0.0}
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning("balance fetch failed: %s", e)
        return {"available": 0.0, "total": 0.0}


def _make_kis_broker():
    """환경변수 로드 후 KISBroker 생성."""
    from dotenv import load_dotenv
    load_dotenv(str(_ENV_PATH), override=False)
    from deepsignal.live_trading.kis_config import load_kis_config_from_env
    from deepsignal.live_trading.kis_broker import KISBroker
    cfg = load_kis_config_from_env(load_dotenv_file=False)
    return KISBroker(cfg)


def _get_stock_holdings() -> list[dict[str, Any]]:
    """KIS 보유 주식 조회."""
    try:
        broker = _make_kis_broker()
        positions = broker.get_positions()
        result = []
        for p in positions:
            avg = float(p.avg_price or 0)
            cur = float(p.current_price or 0)
            pnl_pct = round((cur - avg) / avg * 100, 2) if avg > 0 else None
            name = (p.raw.get("prdt_abrv_name") or p.raw.get("prdt_name") or "").strip()
            result.append({
                "symbol": p.symbol,
                "name": name or p.symbol,
                "quantity": p.quantity,
                "avg_price": round(avg, 0),
                "current_price": round(cur, 0),
                "market_value": round(float(p.market_value or 0), 0),
                "pnl_pct": pnl_pct,
            })
        return result
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning("stock holdings fetch failed: %s", e)
        return []


def _get_stock_balance() -> dict[str, float]:
    try:
        broker = _make_kis_broker()
        bal = broker.get_cash_balance()
        return {
            "balance": float(bal.cash or 0),
            "withdrawable": float(bal.withdrawable_cash or bal.cash or 0),
        }
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning("stock balance fetch failed: %s", e)
        return {"balance": 0.0, "withdrawable": 0.0}


def _get_last_plan() -> dict[str, Any]:
    plan = _read_json(_OUTPUT_DIR / "CRYPTO_ORDER_PLAN.json")
    if not plan:
        return {}
    return {
        "market": plan.get("market"),
        "side": plan.get("side"),
        "status": plan.get("status"),
        "reason": plan.get("reason", "")[:120],
        "pnl_pct": plan.get("pnl_pct"),
        "created_at": plan.get("created_at"),
        "sell_trigger": plan.get("sell_trigger"),
        "technical_score": plan.get("technical_score"),
        "macro_score": plan.get("macro_score"),
        "final_score": plan.get("final_score"),
        "macro_regime": plan.get("macro_regime"),
        "score_breakdown": plan.get("score_breakdown", {}),
        "quality_gates": plan.get("quality_gates", {}),
    }


def _get_crypto_approval() -> dict[str, Any]:
    try:
        path = _OUTPUT_DIR / "crypto_telegram_approval_request.json"
        if not path.is_file():
            return {"pending": False}
        data = json.loads(path.read_text(encoding="utf-8"))
        status = data.get("status", "")
        # side는 플랜 파일에서 읽음
        plan_side = "sell"
        try:
            plan = _read_json(_OUTPUT_DIR / "CRYPTO_ORDER_PLAN.json")
            plan_side = plan.get("side", "sell")
        except Exception:
            pass
        # 만료 여부 확인
        expires_str = data.get("expires_at", "")
        if status == "PENDING" and expires_str:
            try:
                from datetime import timezone
                from dateutil.parser import parse as _parse
                expires_dt = _parse(expires_str)
                if expires_dt.tzinfo is None:
                    expires_dt = expires_dt.replace(tzinfo=timezone.utc)
                from datetime import datetime as _dt
                if _dt.now(tz=timezone.utc) > expires_dt:
                    status = "EXPIRED"
                    data["status"] = "EXPIRED"
                    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass

        show = status in ("PENDING", "EXPIRED")
        return {
            "pending": status == "PENDING",
            "show_banner": show,
            "status": status,
            "token": data.get("token", ""),
            "market": data.get("market", ""),
            "display_name": data.get("display_name", ""),
            "side": plan_side,
            "krw_amount": data.get("krw_amount", 0),
            "current_price": data.get("current_price", 0),
            "reason": (data.get("reason", "") or "")[:300],
            "message_text": (data.get("message_text", "") or "")[:500],
            "created_at": data.get("created_at", ""),
            "expires_at": data.get("expires_at", ""),
        }
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning("crypto approval read failed: %s", e)
        return {"pending": False, "show_banner": False}


def _get_stock_approval() -> dict[str, Any]:
    try:
        path = _OUTPUT_DIR / "TELEGRAM_APPROVAL_STATE.json"
        if not path.is_file():
            return {"pending": False}
        data = json.loads(path.read_text(encoding="utf-8"))
        status = data.get("status", "")
        expires_str = data.get("expires_at", "")
        if status == "PENDING" and expires_str:
            try:
                from datetime import timezone
                from dateutil.parser import parse as _parse
                from datetime import datetime as _dt
                expires_dt = _parse(expires_str)
                if expires_dt.tzinfo is None:
                    expires_dt = expires_dt.replace(tzinfo=timezone.utc)
                if _dt.now(tz=timezone.utc) > expires_dt:
                    status = "EXPIRED"
                    data["status"] = "EXPIRED"
                    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass
        return {
            "pending": status == "PENDING",
            "status": status,
            "token": data.get("token", ""),
            "order_count": data.get("order_count", 0),
            "total_order_value": data.get("total_order_value", 0),
            "created_at": data.get("created_at", ""),
            "expires_at": data.get("expires_at", ""),
            "request_markdown": (data.get("request_markdown", "") or "")[:80],
            "manual_live_approve_command": data.get("manual_live_approve_command", ""),
            "plan_warnings": data.get("plan_warnings", []),
        }
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning("stock approval read failed: %s", e)
        return {"pending": False}


def _handle_crypto_approval_action(action: str, token: str) -> tuple[bool, str]:
    import logging
    from dotenv import load_dotenv
    load_dotenv(str(_ENV_PATH), override=False)
    try:
        from deepsignal.crypto_trading.crypto_telegram_flow import (
            load_crypto_approval_request, _save_request, _write_audit,
            STATUS_APPROVED, STATUS_REJECTED, STATUS_PENDING,
            execute_approved_crypto_order,
        )
        from deepsignal.live_trading.time_utils import now_kst_iso
    except ImportError as e:
        return False, f"모듈 로드 실패: {e}"

    approval = load_crypto_approval_request(_OUTPUT_DIR)
    if approval is None:
        return False, "승인 요청 없음"
    if approval.token != token:
        return False, "토큰 불일치"
    if approval.status != STATUS_PENDING:
        return False, f"이미 처리됨: {approval.status}"

    if action == "reject":
        approval.status = STATUS_REJECTED
        _save_request(_OUTPUT_DIR, approval)
        _write_audit(_OUTPUT_DIR, {"action": "rejected", "source": "web_ui", "token": token, "ts": now_kst_iso()})
        _event_bus.publish_sync("crypto_approval_update", {
            "action": "rejected", "market": approval.market, "source": "web_ui",
        })
        asyncio.create_task(_telegram_notify(f"❌ [웹UI] {approval.market} 코인 매수 거부됨"))
        return True, f"{approval.market} 주문 거부됨"

    if action == "approve":
        approval.status = STATUS_APPROVED
        _save_request(_OUTPUT_DIR, approval)
        _write_audit(_OUTPUT_DIR, {"action": "approved", "source": "web_ui", "token": token, "ts": now_kst_iso()})
        _event_bus.publish_sync("crypto_approval_update", {
            "action": "approved", "market": approval.market, "source": "web_ui",
        })
        asyncio.create_task(_telegram_notify(f"✅ [웹UI] {approval.market} 코인 매수 승인됨"))
        try:
            from deepsignal.crypto_trading.crypto_order_plan import load_crypto_plan
            broker = _make_broker()
            plan_path = Path(approval.plan_path)
            if not plan_path.is_file():
                plan_path = _OUTPUT_DIR / "CRYPTO_ORDER_PLAN.json"
            plan = load_crypto_plan(plan_path)
            result = execute_approved_crypto_order(broker, plan, execute=True, output_dir=_OUTPUT_DIR)
            return True, f"{approval.market} 주문 실행 완료"
        except Exception as e:
            logging.getLogger(__name__).error("crypto web approval execution failed: %s", e)
            return True, f"승인됨 (실행 오류: {str(e)[:100]})"

    return False, f"알 수 없는 액션: {action}"


def _handle_stock_approval_action(action: str, token: str) -> tuple[bool, str]:
    req_path = _OUTPUT_DIR / "TELEGRAM_APPROVAL_STATE.json"
    if not req_path.is_file():
        return False, "승인 요청 없음"
    try:
        data = json.loads(req_path.read_text(encoding="utf-8"))
    except Exception as e:
        return False, f"파일 읽기 오류: {e}"

    if data.get("token") != token:
        return False, "토큰 불일치"
    if data.get("status") != "PENDING":
        return False, f"이미 처리됨: {data.get('status')}"

    symbol = data.get("symbol", data.get("ticker", "주식"))
    from datetime import date as _date
    if action == "reject":
        data["status"] = "REJECTED"
        data["action"] = "reject"
        req_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        state_path = _OUTPUT_DIR / f"telegram_approval_state_{token}.json"
        state_path.write_text(json.dumps({"status": "TELEGRAM_APPROVAL_REJECTED", "action": "reject", "source": "web_ui"}, ensure_ascii=False), encoding="utf-8")
        _event_bus.publish_sync("stock_approval_update", {
            "action": "rejected", "symbol": symbol, "source": "web_ui",
        })
        asyncio.create_task(_telegram_notify(f"❌ [웹UI] {symbol} 주식 주문 거부됨"))
        return True, "주식 주문 거부됨"

    if action == "approve":
        data["status"] = "APPROVED"
        data["action"] = "approve"
        req_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        state_path = _OUTPUT_DIR / f"telegram_approval_state_{token}.json"
        state_path.write_text(json.dumps({"status": "TELEGRAM_APPROVAL_APPROVED_MANUAL_EXECUTION_REQUIRED", "action": "approve", "source": "web_ui"}, ensure_ascii=False), encoding="utf-8")
        _event_bus.publish_sync("stock_approval_update", {
            "action": "approved", "symbol": symbol, "source": "web_ui",
        })
        asyncio.create_task(_telegram_notify(f"✅ [웹UI] {symbol} 주식 주문 승인됨"))
        cmd = data.get("manual_live_approve_command", "python main.py execute-last-approved")
        return True, f"주식 주문 승인됨 — 실행: {cmd}"

    if action == "halt":
        halt_path = _OUTPUT_DIR / f"telegram_approval_halt_{_date.today().strftime('%Y%m%d')}.json"
        halt_path.write_text(json.dumps({"halt": True, "source": "web_ui"}), encoding="utf-8")
        _event_bus.publish_sync("stock_approval_update", {"action": "halt", "symbol": symbol, "source": "web_ui"})
        asyncio.create_task(_telegram_notify(f"⏹ [웹UI] 오늘 {symbol} 주식 승인 중단됨"))
        return True, "오늘 주식 승인 중단됨"

    return False, f"알 수 없는 액션: {action}"


# ──────────────────────────────────────────
# 인증 엔드포인트
# ──────────────────────────────────────────

class TelegramAuthRequest(BaseModel):
    init_data: str

@app.post("/auth/telegram")
async def auth_telegram(req: TelegramAuthRequest) -> JSONResponse:
    from dotenv import load_dotenv
    load_dotenv(str(_ENV_PATH), override=False)
    cfg = get_auth_config()

    if not cfg["bot_token"]:
        return JSONResponse({"ok": False, "error": "bot_token not configured"}, status_code=500)

    user = verify_init_data(req.init_data, cfg["bot_token"])
    if user is None:
        return JSONResponse({"ok": False, "error": "invalid or expired initData"}, status_code=401)

    user_id = int(user.get("id", 0))
    if cfg["allowed_id"] and user_id != cfg["allowed_id"]:
        return JSONResponse({"ok": False, "error": "unauthorized user"}, status_code=403)

    token = create_session_token(user_id, cfg["bot_token"], hours=cfg["session_hours"])
    return JSONResponse({
        "ok": True,
        "token": token,
        "user": {"id": user_id, "first_name": user.get("first_name", "")},
        "expires_hours": cfg["session_hours"],
    })


@app.get("/auth/status")
async def auth_status(request: Request) -> JSONResponse:
    from dotenv import load_dotenv
    load_dotenv(str(_ENV_PATH), override=False)
    cfg = get_auth_config()

    client_host = (request.client.host if request.client else "") or ""
    is_local = client_host in ("127.0.0.1", "::1", "localhost")
    if not cfg["require_auth"] or is_local:
        return JSONResponse({"ok": True, "auth": "local_bypass"})

    token = request.headers.get("X-Session-Token") or request.query_params.get("token")
    if token and cfg["bot_token"]:
        user_id = verify_session_token(token, cfg["bot_token"])
        if user_id:
            return JSONResponse({"ok": True, "auth": "session", "user_id": user_id})

    return JSONResponse({"ok": False, "auth": "none"}, status_code=401)


@app.get("/auth/config")
async def auth_config_endpoint() -> JSONResponse:
    """프론트엔드가 인증 필요 여부 확인용."""
    from dotenv import load_dotenv
    load_dotenv(str(_ENV_PATH), override=False)
    cfg = get_auth_config()
    return JSONResponse({
        "require_auth": cfg["require_auth"],
        "public_url":   cfg["public_url"],
    })


# ──────────────────────────────────────────
# API 라우터
# ──────────────────────────────────────────

@app.get("/api/status")
async def api_status() -> JSONResponse:
    runner = get_runner_status(_OUTPUT_DIR)
    # 코인 + 주식 동시 조회
    holdings, balance, stock_holdings, stock_balance = await asyncio.gather(
        asyncio.to_thread(_get_holdings),
        asyncio.to_thread(_get_balance),
        asyncio.to_thread(_get_stock_holdings),
        asyncio.to_thread(_get_stock_balance),
    )
    last_plan = _get_last_plan()
    thresholds = _read_json(_OUTPUT_DIR / "CRYPTO_ACTIVE_THRESHOLDS.json")

    return JSONResponse({
        "runner": runner,
        "balance_krw": balance.get("available", 0) if isinstance(balance, dict) else balance,
        "balance_krw_total": balance.get("total", 0) if isinstance(balance, dict) else balance,
        "holdings": holdings,
        "stock_holdings": stock_holdings,
        "stock_balance_krw": stock_balance.get("balance", 0) if isinstance(stock_balance, dict) else stock_balance,
        "stock_withdrawable_krw": stock_balance.get("withdrawable", 0) if isinstance(stock_balance, dict) else stock_balance,
        "last_plan": last_plan,
        "thresholds": {
            "take_profit_pct": thresholds.get("take_profit_pct"),
            "stop_loss_pct": thresholds.get("stop_loss_pct"),
            "min_volume_ratio": thresholds.get("min_volume_ratio"),
        },
        "server_time": datetime.now().isoformat(),
        "platform": platform.system(),
    })


# ── 러너 제어 ──────────────────────────────

@app.post("/api/runner/start")
async def api_start() -> JSONResponse:
    ok, msg = await asyncio.to_thread(start_runner, _OUTPUT_DIR, _PROJECT_ROOT)
    if ok:
        await _event_bus.publish("runner_control", {"action": "started", "source": "web_ui"})
        await _telegram_notify("▶️ [웹UI] 코인 러너 시작됨")
    return JSONResponse({"ok": ok, "message": msg})


@app.post("/api/runner/stop")
async def api_stop() -> JSONResponse:
    ok, msg = await asyncio.to_thread(stop_runner, _OUTPUT_DIR)
    if ok:
        await _event_bus.publish("runner_control", {"action": "stopped", "source": "web_ui"})
        await _telegram_notify("⏹ [웹UI] 코인 러너 중지됨")
    return JSONResponse({"ok": ok, "message": msg})


@app.post("/api/runner/restart")
async def api_restart() -> JSONResponse:
    ok, msg = await asyncio.to_thread(restart_runner, _OUTPUT_DIR, _PROJECT_ROOT)
    if ok:
        await _event_bus.publish("runner_control", {"action": "restarted", "source": "web_ui"})
        await _telegram_notify("🔄 [웹UI] 코인 러너 재시작됨")
    return JSONResponse({"ok": ok, "message": msg})


class PauseRequest(BaseModel):
    paused: bool
    reason: str = ""


@app.post("/api/runner/pause")
async def api_pause(req: PauseRequest) -> JSONResponse:
    ok, msg = await asyncio.to_thread(
        set_pause_state, _OUTPUT_DIR, paused=req.paused, reason=req.reason
    )
    return JSONResponse({"ok": ok, "message": msg})


# ── 승인 관리 ─────────────────────────────

@app.get("/api/approval")
async def api_approval() -> JSONResponse:
    crypto, stock = await asyncio.gather(
        asyncio.to_thread(_get_crypto_approval),
        asyncio.to_thread(_get_stock_approval),
    )
    return JSONResponse({"crypto": crypto, "stock": stock})


class ApprovalActionRequest(BaseModel):
    type: str
    action: str
    token: str


@app.post("/api/approval/action")
async def api_approval_action(req: ApprovalActionRequest) -> JSONResponse:
    if req.type == "crypto":
        ok, msg = await asyncio.to_thread(_handle_crypto_approval_action, req.action, req.token)
    elif req.type == "stock":
        ok, msg = await asyncio.to_thread(_handle_stock_approval_action, req.action, req.token)
    else:
        return JSONResponse({"ok": False, "message": "알 수 없는 유형"})
    return JSONResponse({"ok": ok, "message": msg})


# ── 분석 데이터 ────────────────────────────

@app.get("/api/plan/detail")
async def api_plan_detail() -> JSONResponse:
    return JSONResponse(_read_json(_OUTPUT_DIR / "CRYPTO_ORDER_PLAN.json"))


@app.get("/api/sizing")
async def api_sizing() -> JSONResponse:
    return JSONResponse(_read_json(_OUTPUT_DIR / "CRYPTO_ACTIVE_SIZING.json"))


@app.get("/api/universe")
async def api_universe() -> JSONResponse:
    return JSONResponse(_read_json(_OUTPUT_DIR / "CRYPTO_UNIVERSE_SNAPSHOT.json"))


@app.get("/api/slippage")
async def api_slippage(limit: int = 100) -> JSONResponse:
    path = _OUTPUT_DIR / "CRYPTO_FILL_SLIPPAGE.jsonl"
    if not path.is_file():
        return JSONResponse({"entries": [], "exists": False})
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
        entries = []
        for line in lines[-limit:]:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except Exception:
                    pass
        return JSONResponse({"entries": list(reversed(entries)), "exists": True, "total": len(lines)})
    except Exception as e:
        return JSONResponse({"entries": [], "error": str(e), "exists": False})


@app.get("/api/reconcile")
async def api_reconcile() -> JSONResponse:
    return JSONResponse(_read_json(_OUTPUT_DIR / "LATEST_RECONCILE_STATE.json"))


# ── 리포트 ─────────────────────────────────

@app.get("/api/reports")
async def api_reports() -> JSONResponse:
    try:
        md_files = sorted(
            [p for p in _OUTPUT_DIR.glob("*.md") if not p.name.startswith("._")],
            key=lambda p: p.stat().st_mtime, reverse=True,
        )
        reports = []
        for f in md_files[:30]:
            try:
                reports.append({
                    "name": f.name,
                    "size": f.stat().st_size,
                    "modified": datetime.fromtimestamp(f.stat().st_mtime).isoformat(),
                })
            except Exception:
                pass
        return JSONResponse({"reports": reports})
    except Exception as e:
        return JSONResponse({"reports": [], "error": str(e)})


@app.get("/api/reports/{filename}")
async def api_report_content(filename: str) -> JSONResponse:
    if ".." in filename or "/" in filename or "\\" in filename:
        raise HTTPException(400, "잘못된 파일명")
    path = _OUTPUT_DIR / filename
    if not path.is_file() or path.suffix not in (".md", ".txt"):
        raise HTTPException(404, "리포트 없음")
    try:
        content = path.read_text(encoding="utf-8", errors="replace")
        return JSONResponse({"name": filename, "content": content})
    except Exception as e:
        raise HTTPException(500, str(e))


# ── 분석 실행 트리거 ──────────────────────

class RecommendRequest(BaseModel):
    type: str = "crypto"


@app.post("/api/runner/recommend")
async def api_runner_recommend(req: RecommendRequest) -> JSONResponse:
    import subprocess as _sp
    import asyncio
    cmd_map = {
        "crypto": [sys.executable, str(_PROJECT_ROOT / "main.py"), "crypto-daily-plan",
                   "--output-dir", str(_OUTPUT_DIR)],
        "stock":  [sys.executable, str(_PROJECT_ROOT / "main.py"), "daily-ai-trade-plan",
                   "--output-dir", str(_OUTPUT_DIR)],
    }
    cmd = cmd_map.get(req.type)
    if not cmd:
        return JSONResponse({"ok": False, "message": "알 수 없는 유형"})
    label = "코인" if req.type == "crypto" else "주식"
    try:
        log_path = _OUTPUT_DIR / "webui_recommend.log"
        proc = await asyncio.create_subprocess_exec(
            *cmd, cwd=str(_PROJECT_ROOT),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        try:
            stdout_bytes, _ = await asyncio.wait_for(proc.communicate(), timeout=180)
        except asyncio.TimeoutError:
            proc.kill()
            return JSONResponse({"ok": False, "message": f"{label} 분석 시간 초과 (3분)"})
        output = stdout_bytes.decode("utf-8", errors="replace")
        # 로그 파일에도 기록
        try:
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(output)
        except Exception:
            pass
        rc = proc.returncode
        if rc != 0:
            last_lines = "\n".join(output.strip().splitlines()[-3:])
            return JSONResponse({"ok": False, "message": f"{label} 분석 실패 (exit {rc}): {last_lines}"})
        # 결과 요약
        if req.type == "crypto":
            plan_path = _OUTPUT_DIR / "CRYPTO_ORDER_PLAN.json"
            if plan_path.exists():
                try:
                    import json as _j
                    plan_raw = _j.loads(plan_path.read_text(encoding="utf-8"))
                    status = plan_raw.get("status", "")
                    market = plan_raw.get("market", "")
                    side = "매수" if plan_raw.get("side") == "buy" else "매도"
                    if status and market:
                        # 승인 요청 파일 생성 (Telegram 미발송, 웹 UI 배너용)
                        try:
                            from dotenv import load_dotenv as _lde
                            _lde(str(_ENV_PATH), override=False)
                            from deepsignal.crypto_trading.crypto_order_plan import load_crypto_plan as _lcp
                            from deepsignal.crypto_trading.crypto_telegram_flow import (
                                create_crypto_approval_request as _mk_req,
                                load_crypto_telegram_config_from_env as _tg_cfg,
                            )
                            _cfg = _tg_cfg(output_dir=str(_OUTPUT_DIR))
                            _cfg.send = False  # 웹 UI 수동 분석 시 텔레그램 미발송
                            _plan = _lcp(plan_path)
                            if _plan is not None:
                                _mk_req(_plan, cfg=_cfg, plan_path=plan_path)
                        except Exception as _ae:
                            import logging as _lg
                            _lg.getLogger(__name__).warning("approval request creation failed: %s", _ae)
                        return JSONResponse({"ok": True, "message": f"✅ {label} 분석 완료 — {market} {side} 계획 생성됨", "has_plan": True})
                except Exception:
                    pass
            return JSONResponse({"ok": True, "message": f"✅ {label} 분석 완료 — 추천 없음 (매매 조건 미충족)", "has_plan": False})
        else:
            plan_path = _OUTPUT_DIR / "AI_DAILY_TRADE_PLAN.md"
            if plan_path.exists():
                try:
                    content = plan_path.read_text(encoding="utf-8")
                    if "주문 수: 0개" in content or "NO_ORDERS" in content:
                        return JSONResponse({"ok": True, "message": f"✅ {label} 분석 완료 — 추천 없음 (매매 조건 미충족)", "has_plan": False})
                    return JSONResponse({"ok": True, "message": f"✅ {label} 분석 완료 — 매매계획 생성됨", "has_plan": True})
                except Exception:
                    pass
            return JSONResponse({"ok": True, "message": f"✅ {label} 분석 완료", "has_plan": False})
    except Exception as e:
        return JSONResponse({"ok": False, "message": str(e)})


# ── 설정 ───────────────────────────────────

@app.get("/api/settings")
async def api_get_settings() -> JSONResponse:
    data = read_settings(_ENV_PATH)
    return JSONResponse(data)


class SettingsUpdateRequest(BaseModel):
    updates: dict[str, str]


@app.post("/api/settings")
async def api_save_settings(req: SettingsUpdateRequest) -> JSONResponse:
    ok, msg = write_settings(_ENV_PATH, req.updates)
    return JSONResponse({"ok": ok, "message": msg})


# ── 로그 REST (최근 N줄) ──────────────────

@app.get("/api/logs")
async def api_logs(file: str = "crypto_auto_runner", lines: int = 100) -> JSONResponse:
    allowed = {"crypto_auto_runner", "crypto_auto_runner.error", "binance_stream"}
    if file not in allowed:
        raise HTTPException(400, "허용되지 않은 로그 파일")
    log_dir = Path.home() / ".deepsignal" / "logs"
    log_path = log_dir / f"{file}.log"
    if not log_path.is_file():
        return JSONResponse({"lines": [], "path": str(log_path), "exists": False})
    try:
        all_lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
        return JSONResponse({
            "lines": all_lines[-lines:],
            "path": str(log_path),
            "exists": True,
            "total": len(all_lines),
        })
    except Exception as e:
        return JSONResponse({"lines": [], "error": str(e), "exists": False})


# ── WebSocket 로그 스트리밍 ──────────────

@app.websocket("/ws/logs")
async def ws_logs(ws: WebSocket, file: str = "crypto_auto_runner"):
    await ws.accept()
    allowed = {"crypto_auto_runner", "crypto_auto_runner.error", "binance_stream"}
    if file not in allowed:
        await ws.close(code=1008)
        return

    log_dir = Path.home() / ".deepsignal" / "logs"
    log_path = log_dir / f"{file}.log"

    # 기존 마지막 50줄 전송
    if log_path.is_file():
        lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
        for line in lines[-50:]:
            await ws.send_json({"type": "line", "data": line})

    # tail -f 스타일 실시간 스트리밍
    last_size = log_path.stat().st_size if log_path.is_file() else 0
    try:
        while True:
            await asyncio.sleep(1)
            if not log_path.is_file():
                continue
            cur_size = log_path.stat().st_size
            if cur_size > last_size:
                with log_path.open("r", encoding="utf-8", errors="replace") as f:
                    f.seek(last_size)
                    new_content = f.read()
                for line in new_content.splitlines():
                    if line.strip():
                        await ws.send_json({"type": "line", "data": line})
                last_size = cur_size
            elif cur_size < last_size:
                # 로그 로테이션
                last_size = 0
    except WebSocketDisconnect:
        pass


# ── WebSocket 상태 푸시 (레거시 폴링 유지) ─
@app.websocket("/ws/status")
async def ws_status(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            runner = get_runner_status(_OUTPUT_DIR)
            await ws.send_json({"type": "status", "data": runner})
            await asyncio.sleep(5)
    except WebSocketDisconnect:
        pass


# ── WebSocket 이벤트 스트림 (실시간 연동) ──

@app.websocket("/ws/events")
async def ws_events(ws: WebSocket):
    """EventBus 구독 → 상태 변화 즉시 푸시."""
    await ws.accept()
    q = _event_bus.subscribe()
    # 연결 직후 현재 상태 스냅샷 전송
    try:
        runner = await asyncio.to_thread(get_runner_status, _OUTPUT_DIR)
        await ws.send_json({"type": "snapshot", "data": {"runner": runner}})
    except Exception:
        pass
    try:
        while True:
            try:
                event = await asyncio.wait_for(q.get(), timeout=30)
                await ws.send_json(event)
            except asyncio.TimeoutError:
                # heartbeat — 브라우저 연결 유지
                await ws.send_json({"type": "ping"})
    except (WebSocketDisconnect, Exception):
        pass
    finally:
        _event_bus.unsubscribe(q)


# ── 정적 파일 / SPA 폴백 ──────────────────

_NO_CACHE = {"Cache-Control": "no-store, no-cache, must-revalidate", "Pragma": "no-cache"}


@app.get("/static/{filename:path}")
async def static_files(filename: str):
    """정적 파일 — no-cache 헤더 포함."""
    path = _STATIC / filename
    if not path.is_file():
        from fastapi import HTTPException
        raise HTTPException(404)
    return FileResponse(str(path), headers=_NO_CACHE)


@app.get("/")
async def root():
    return FileResponse(str(_STATIC / "index.html"), headers=_NO_CACHE)


@app.get("/{full_path:path}")
async def spa_fallback(full_path: str):
    # API 경로는 위에서 처리됨
    return FileResponse(str(_STATIC / "index.html"), headers=_NO_CACHE)


# ──────────────────────────────────────────
# 진입점
# ──────────────────────────────────────────

def run_web_ui(
    *,
    host: str = "127.0.0.1",
    port: int = 8765,
    output_dir: str = "outputs",
    project_root: str = ".",
    env_path: str = ".env",
    no_browser: bool = False,
) -> None:
    global _OUTPUT_DIR, _PROJECT_ROOT, _ENV_PATH
    _OUTPUT_DIR = Path(output_dir).resolve()
    _PROJECT_ROOT = Path(project_root).resolve()
    _ENV_PATH = Path(env_path).resolve()

    url = f"http://{host}:{port}"
    print(f"\n  DeepSignal Web UI → {url}\n  Ctrl+C 로 종료\n", flush=True)

    if not no_browser:
        import threading
        import webbrowser
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()

    import uvicorn
    uvicorn.run(app, host=host, port=port, log_level="warning")
