/* ══════════════════════════════════════════════
   DeepSignal Web UI — Single-Page App
   ══════════════════════════════════════════════ */

// ── 세션 관리 ─────────────────────────────────
let _sessionToken = localStorage.getItem('ds_session') || null;

// ── API 헬퍼 ─────────────────────────────────
async function api(method, path, body) {
  const headers = { 'Content-Type': 'application/json' };
  if (_sessionToken) headers['X-Session-Token'] = _sessionToken;
  const opts = { method, headers };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(path, opts);
  if (res.status === 401) {
    // 세션 만료 → 재인증
    _sessionToken = null;
    localStorage.removeItem('ds_session');
    initTelegramAuth();
    throw new Error('unauthorized');
  }
  return res.json();
}
const GET  = (p)    => api('GET', p);
const POST = (p, b) => api('POST', p, b);

// ── 토스트 ───────────────────────────────────
function toast(msg, type = 'info', ms = 4000) {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  document.getElementById('toast-container').appendChild(el);
  setTimeout(() => el.remove(), ms);
}

function toastLoading(msg) {
  const el = document.createElement('div');
  el.className = 'toast loading';
  el.innerHTML = `<span class="toast-spinner"></span>${msg}`;
  document.getElementById('toast-container').appendChild(el);
  return {
    update(newMsg, type = 'success', ms = 8000) {
      el.className = `toast ${type}`;
      el.textContent = newMsg;
      setTimeout(() => el.remove(), ms);
    },
    remove() { el.remove(); }
  };
}

// ── 유틸 ─────────────────────────────────────
function escHtml(s) {
  return (s || '').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function fmt_krw(v) {
  if (v == null) return '-';
  const str = Number(v).toLocaleString('ko-KR', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  const dot = str.indexOf('.');
  if (dot === -1) return str + '원';
  return str.slice(0, dot) + `<span class="krw-dec">${str.slice(dot)}</span>원`;
}
function fmt_pct(v)   { if (v == null) return '-'; const n = Number(v); return (n >= 0 ? '+' : '') + n.toFixed(2) + '%'; }
function fmt_bps(v)   { if (v == null) return '-'; return Number(v).toFixed(1) + 'bps'; }
function fmt_time(v)  { if (!v) return '-'; try { return new Date(v).toLocaleString('ko-KR'); } catch { return v; } }
function fmt_uptime(sec) {
  if (!sec) return '-';
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = Math.floor(sec % 60);
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}
function pct_class(v) { return v > 0 ? 'text-up' : v < 0 ? 'text-down' : ''; }

function score_bar(val, max) {
  if (val == null) return '<span class="text-muted">-</span>';
  const pct = Math.min(100, Math.max(0, ((Number(val) + max) / (max * 2)) * 100));
  const cls = val > 20 ? 'bar-positive' : val < -20 ? 'bar-negative' : 'bar-neutral';
  return `<div class="score-bar-wrap">
    <div class="score-bar ${cls}" style="width:${pct.toFixed(0)}%"></div>
    <span class="score-bar-label">${Number(val).toFixed(1)}</span>
  </div>`;
}

// ── 마크다운 렌더러 ───────────────────────────
function md2html(text) {
  if (!text) return '';
  const lines = text.split('\n');
  let html = '';
  let inCode = false;
  let inList = false;

  for (const line of lines) {
    if (line.startsWith('```')) {
      if (inList) { html += '</ul>'; inList = false; }
      inCode = !inCode;
      html += inCode ? '<pre class="md-pre"><code>' : '</code></pre>';
      continue;
    }
    if (inCode) { html += escHtml(line) + '\n'; continue; }

    let p = escHtml(line)
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/`(.+?)`/g, '<code class="md-inline">$1</code>');

    if (/^### /.test(line)) {
      if (inList) { html += '</ul>'; inList = false; }
      html += `<h3 class="md-h3">${p.slice(4)}</h3>`;
    } else if (/^## /.test(line)) {
      if (inList) { html += '</ul>'; inList = false; }
      html += `<h2 class="md-h2">${p.slice(3)}</h2>`;
    } else if (/^# /.test(line)) {
      if (inList) { html += '</ul>'; inList = false; }
      html += `<h1 class="md-h1">${p.slice(2)}</h1>`;
    } else if (/^[|\-]{2,}/.test(line) && line.includes('|')) {
      if (inList) { html += '</ul>'; inList = false; }
      // table row — basic support
      const cells = line.split('|').filter((_, i, a) => i > 0 && i < a.length - 1);
      const isHeader = cells.some(c => c.trim() === '' || /^[-:]+$/.test(c.trim()));
      if (!isHeader) {
        html += '<tr>' + cells.map(c => `<td>${c.trim()}</td>`).join('') + '</tr>';
      }
    } else if (/^[-•] /.test(line)) {
      if (!inList) { html += '<ul class="md-ul">'; inList = true; }
      html += `<li>${p.slice(2)}</li>`;
    } else if (/^---+$/.test(line)) {
      if (inList) { html += '</ul>'; inList = false; }
      html += '<hr class="md-hr">';
    } else if (line.trim() === '') {
      if (inList) { html += '</ul>'; inList = false; }
      html += '<br>';
    } else {
      if (inList) { html += '</ul>'; inList = false; }
      html += `<p class="md-p">${p}</p>`;
    }
  }
  if (inList) html += '</ul>';
  if (inCode) html += '</code></pre>';
  return html;
}

// ══════════════════════════════════════════════
// Telegram WebApp 인증 & 모바일 UI
// ══════════════════════════════════════════════
const _tg = window.Telegram?.WebApp;
const _isTelegramWebApp = !!((_tg && _tg.initData && _tg.initData.length > 0));

async function initTelegramAuth() {
  if (_isTelegramWebApp) {
    // Telegram WebApp 환경
    _tg.ready();
    _tg.expand();
    applyTelegramTheme();
    setupMobileNav();

    // 기존 세션 유효성 확인
    const stored = localStorage.getItem('ds_session');
    if (stored) {
      try {
        const r = await fetch('/auth/status', {
          headers: { 'X-Session-Token': stored }
        });
        const data = await r.json();
        if (data.ok) {
          _sessionToken = stored;
          hideAuthOverlay();
          return;
        }
      } catch (_e) { /* 네트워크 오류 → 재인증 */ }
    }

    // initData로 신규 인증
    showAuthOverlay('인증 중...');
    try {
      const r = await fetch('/auth/telegram', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ init_data: _tg.initData }),
      });
      const data = await r.json();
      if (data.ok && data.token) {
        _sessionToken = data.token;
        localStorage.setItem('ds_session', data.token);
        hideAuthOverlay();
      } else {
        showAuthError(data.error || '인증 실패');
      }
    } catch (_e) {
      showAuthError('서버 연결 실패 — 잠시 후 다시 시도해주세요.');
    }
  } else {
    // 일반 브라우저 (로컬 or 인증 불필요)
    hideAuthOverlay();
  }
}

function showAuthOverlay(msg) {
  const el      = document.getElementById('auth-overlay');
  const msgEl   = document.getElementById('auth-message');
  const spinner = document.getElementById('auth-spinner');
  const error   = document.getElementById('auth-error');
  if (el)      el.classList.remove('hidden');
  if (msgEl)   msgEl.textContent = msg;
  if (spinner) spinner.style.display = 'block';
  if (error)   error.classList.add('hidden');
}

function showAuthError(msg) {
  const msgEl   = document.getElementById('auth-message');
  const spinner = document.getElementById('auth-spinner');
  const error   = document.getElementById('auth-error');
  if (msgEl)   msgEl.textContent = '';
  if (spinner) spinner.style.display = 'none';
  if (error)   { error.classList.remove('hidden'); error.textContent = msg; }
}

function hideAuthOverlay() {
  const el = document.getElementById('auth-overlay');
  if (el) el.classList.add('hidden');
}

function applyTelegramTheme() {
  if (!_tg?.themeParams) return;
  const p    = _tg.themeParams;
  const root = document.documentElement;
  if (p.bg_color)           root.style.setProperty('--bg-body',    p.bg_color);
  if (p.secondary_bg_color) root.style.setProperty('--bg-card',    p.secondary_bg_color);
  if (p.text_color)         root.style.setProperty('--text-primary', p.text_color);
  if (p.hint_color)         root.style.setProperty('--text-muted',  p.hint_color);
  if (p.button_color)       root.style.setProperty('--accent',      p.button_color);
  if (p.button_text_color)  root.style.setProperty('--text-sidebar-active', p.button_text_color);
}

function setupMobileNav() {
  // 하단 탭바 표시
  const bottomNav = document.getElementById('bottom-nav');
  if (bottomNav) bottomNav.classList.remove('hidden');

  // 탭 클릭 핸들러
  document.querySelectorAll('.bnav-item').forEach(el => {
    el.addEventListener('click', () => {
      const page = el.dataset.page;
      navigate(page);
    });
  });
}

function syncBottomNav(page) {
  document.querySelectorAll('.bnav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.page === page);
  });
}

// ── 라우터 ───────────────────────────────────
const PAGES = ['dashboard', 'runner', 'settings', 'logs', 'analysis', 'reports'];
let currentPage = 'dashboard';

function navigate(page) {
  if (!PAGES.includes(page)) page = 'dashboard';
  currentPage = page;
  PAGES.forEach(p => {
    document.getElementById(`page-${p}`).classList.toggle('hidden', p !== page);
  });
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.page === page);
  });
  syncBottomNav(page);
  if (page === 'dashboard') renderDashboard();
  if (page === 'runner')    renderRunner();
  if (page === 'settings')  renderSettings();
  if (page === 'logs')      renderLogs();
  if (page === 'analysis')  renderAnalysis();
  if (page === 'reports')   renderReports();
  window.location.hash = page;
}

document.querySelectorAll('.nav-item').forEach(el => {
  el.addEventListener('click', e => { e.preventDefault(); navigate(el.dataset.page); });
});

// ══════════════════════════════════════════════
// 대시보드
// ══════════════════════════════════════════════
let dashInterval = null;
let dashAnalyzing = false;

async function renderDashboard() {
  clearInterval(dashInterval);
  const el = document.getElementById('page-dashboard');
  el.innerHTML = '<div class="page-header"><h1 class="page-title">대시보드</h1></div><div class="text-muted">데이터 로딩 중...</div>';
  await loadDashboard();
  dashInterval = setInterval(loadDashboard, 8000);
}

async function loadDashboard() {
  if (currentPage !== 'dashboard') { clearInterval(dashInterval); return; }
  if (dashAnalyzing) return;

  const [d, approval] = await Promise.all([
    GET('/api/status'),
    GET('/api/approval').catch(() => ({ crypto: {}, stock: {} })),
  ]);

  const r = d.runner || {};
  const holdings      = d.holdings || [];
  const stockHoldings = d.stock_holdings || [];
  const plan = d.last_plan || {};
  const thr  = d.thresholds || {};

  updateRunnerBadge(r);

  // 총 자산 계산
  const coinVal  = holdings.reduce((s, h) => s + (h.valuation_krw || 0), 0);
  const stockVal = stockHoldings.reduce((s, h) => s + (h.market_value || 0), 0);
  const krwTotal = d.balance_krw_total ?? d.balance_krw ?? 0;
  const totalAsset = coinVal + stockVal + krwTotal + (d.stock_balance_krw || 0);

  const runColor = r.running ? (r.paused ? 'warning' : 'ok') : 'danger';
  const runLabel = r.running ? (r.paused ? '⏸ 일시정지' : '🟢 실행 중') : '🔴 중지됨';
  const cryptoPnl = holdings.reduce((s, h) => s + (h.pnl_pct || 0), 0);
  const stockPnl  = stockHoldings.reduce((s, h) => s + (h.pnl_pct || 0), 0);

  // 리스크 알림 감지
  const riskAlerts = [];
  holdings.forEach(h => {
    if (h.pnl_pct != null && thr.stop_loss_pct != null && h.pnl_pct <= thr.stop_loss_pct * 0.8) {
      riskAlerts.push({ market: h.market, pnl_pct: h.pnl_pct, sl_pct: thr.stop_loss_pct });
    }
  });

  const holdingTable = (rows, cols) => rows.length === 0
    ? '<div class="text-muted" style="padding:12px 0">보유 없음</div>'
    : `<div class="table-wrap"><table>
        <thead><tr>${cols.map(c => `<th>${c}</th>`).join('')}</tr></thead>
        <tbody>${rows}</tbody>
      </table></div>`;

  const cryptoRows = holdings.map(h => `<tr>
    <td><strong>${h.market}</strong></td>
    <td>${h.quantity}</td>
    <td>${fmt_krw(h.avg_buy_price)}</td>
    <td>${fmt_krw(h.current_price)}</td>
    <td>${fmt_krw(h.valuation_krw)}</td>
    <td class="${pct_class(h.pnl_pct)}">${fmt_pct(h.pnl_pct)}</td>
  </tr>`).join('');

  const stockRows = stockHoldings.map(h => `<tr>
    <td><strong>${h.name}</strong><br><span style="font-size:11px;color:var(--text-muted)">${h.symbol}</span></td>
    <td>${h.quantity}주</td>
    <td>${fmt_krw(h.avg_price)}</td>
    <td>${fmt_krw(h.current_price)}</td>
    <td>${fmt_krw(h.market_value)}</td>
    <td class="${pct_class(h.pnl_pct)}">${fmt_pct(h.pnl_pct)}</td>
  </tr>`).join('');

  // 승인 배너
  const approvalBanners = buildApprovalBanners(approval);

  // 리스크 배너
  const riskBanner = riskAlerts.length > 0 ? `
    <div class="alert-banner alert-danger">
      <div class="alert-banner-body">
        ${riskAlerts.map(a => `<div>⚠️ <strong>${a.market}</strong> 손절선 ${fmt_pct(a.sl_pct)} 근접 &nbsp;현재 <span class="text-down">${fmt_pct(a.pnl_pct)}</span></div>`).join('')}
      </div>
      <div class="alert-banner-actions">
        <button class="btn btn-danger btn-sm" onclick="triggerStopLoss()">🔴 손절 분석 실행</button>
        <span class="alert-action-hint">분석 후 승인 배너에서 확인·거부 가능</span>
      </div>
    </div>` : '';

  document.getElementById('page-dashboard').innerHTML = `
    <div class="page-header">
      <h1 class="page-title">대시보드</h1>
      <div class="page-subtitle">마지막 갱신: ${fmt_time(d.server_time)}</div>
    </div>

    ${approvalBanners}
    ${riskBanner}

    <div class="dash-quick-bar">
      <div class="quick-pause-group">
        <label class="toggle" title="${r.paused ? '매매 일시정지 중' : '매매 활성'}">
          <input type="checkbox" id="dash-toggle-pause" ${r.paused ? 'checked' : ''}
            onchange="togglePauseDash(this.checked)" ${!r.running ? 'disabled' : ''}>
          <span class="toggle-slider"></span>
        </label>
        <span class="quick-bar-label ${r.paused ? 'text-warning' : ''}">${r.paused ? '⏸ 전체 일시정지 중' : '전체 일시정지'}</span>
      </div>
      <div class="quick-analyze-group">
        <button class="btn btn-sm btn-primary" onclick="triggerRecommendDash('crypto')">🪙 코인 분석</button>
        <button class="btn btn-sm btn-primary" onclick="triggerRecommendDash('stock')">📈 주식 분석</button>
        <span id="dash-recommend-status" class="quick-bar-status"></span>
      </div>
    </div>

    <div class="cards">
      <div class="card info">
        <div class="card-label">총 자산</div>
        <div class="card-value" style="font-size:17px">${fmt_krw(Math.round(totalAsset))}</div>
        <div class="card-sub">코인 ${fmt_krw(Math.round(coinVal))} + 주식 ${fmt_krw(Math.round(stockVal))}</div>
      </div>
      <div class="card ${runColor}">
        <div class="card-label">러너 상태</div>
        <div class="card-value" style="font-size:17px">${runLabel}</div>
        <div class="card-sub">업타임: ${fmt_uptime(r.uptime_sec)}</div>
      </div>
      <div class="card info">
        <div class="card-label">코인 자산</div>
        <div class="card-value" style="font-size:15px">${fmt_krw(Math.round(coinVal + krwTotal))}</div>
        <div class="card-sub2">KRW잔고 &nbsp;<strong>${fmt_krw(krwTotal)}</strong></div>
        <div class="card-sub2">오늘 매수 &nbsp;<strong>${fmt_krw(r.buy_krw_today || 0)}</strong></div>
      </div>
      <div class="card info">
        <div class="card-label">주식 자산</div>
        <div class="card-value" style="font-size:15px">${fmt_krw(Math.round(stockVal + (d.stock_balance_krw || 0)))}</div>
        <div class="card-sub2">주식예수금 &nbsp;<strong>${fmt_krw(d.stock_balance_krw)}</strong></div>
        <div class="card-sub2">출금가능 &nbsp;<strong>${fmt_krw(d.stock_withdrawable_krw)}</strong></div>
      </div>
      <div class="card ${holdings.length > 0 ? 'ok' : ''}">
        <div class="card-label">보유 코인</div>
        <div class="card-value">${holdings.length}개 <span class="card-value-sub">${holdings.length ? fmt_krw(Math.round(coinVal)) : ''}</span></div>
        <div class="card-sub">수익률: <span class="${pct_class(cryptoPnl)}">${fmt_pct(holdings.length ? cryptoPnl / holdings.length : null)}</span></div>
      </div>
      <div class="card ${stockHoldings.length > 0 ? 'ok' : ''}">
        <div class="card-label">보유 주식</div>
        <div class="card-value">${stockHoldings.length}종목 <span class="card-value-sub">${stockHoldings.length ? fmt_krw(Math.round(stockVal)) : ''}</span></div>
        <div class="card-sub">수익률: <span class="${pct_class(stockPnl)}">${fmt_pct(stockHoldings.length ? stockPnl / stockHoldings.length : null)}</span></div>
      </div>
      <div class="card">
        <div class="card-label">TP / SL</div>
        <div class="card-value" style="font-size:15px">${thr.take_profit_pct != null ? '+' + thr.take_profit_pct + '%' : '-'} / ${thr.stop_loss_pct != null ? thr.stop_loss_pct + '%' : '-'}</div>
        <div class="card-sub">Vol ratio: ${thr.min_volume_ratio ?? '-'}</div>
      </div>
      <div class="card">
        <div class="card-label">오늘 주문</div>
        <div class="card-value">${r.orders_today ?? 0}건</div>
        <div class="card-sub">마지막: ${r.last_market || '-'}</div>
      </div>
    </div>

    <div class="dash-grid">
      <div class="section-box">
        <div class="section-title">🪙 코인 포지션 (Upbit)</div>
        ${holdingTable(cryptoRows, ['종목', '수량', '평균단가', '현재가', '평가금액', '수익률'])}
      </div>
      <div class="section-box">
        <div class="section-title">📈 국내주식 포지션 (KIS)</div>
        ${holdingTable(stockRows, ['종목', '수량', '평균단가', '현재가', '평가금액', '수익률'])}
      </div>
    </div>

    ${plan.market ? `
    <div class="section-box">
      <div class="section-title">📄 마지막 플랜</div>
      <div class="flex-row" style="flex-wrap:wrap; gap:12px; margin-bottom:10px">
        <span><strong>${plan.market}</strong></span>
        <span class="badge ${plan.side === 'buy' ? 'badge-success' : 'badge-danger'}">${(plan.side || '').toUpperCase()}</span>
        <span class="badge badge-neutral">${plan.status || ''}</span>
        ${plan.sell_trigger ? `<span class="badge badge-warning">${plan.sell_trigger}</span>` : ''}
        ${plan.pnl_pct != null ? `<span class="${pct_class(plan.pnl_pct)}">${fmt_pct(plan.pnl_pct)}</span>` : ''}
        ${plan.macro_regime ? `<span class="badge badge-info">레짐: ${plan.macro_regime}</span>` : ''}
      </div>
      ${plan.technical_score != null || plan.macro_score != null || plan.final_score != null ? `
      <div class="score-row">
        <div class="score-item"><span class="score-label">기술적</span>${score_bar(plan.technical_score, 100)}</div>
        <div class="score-item"><span class="score-label">거시</span>${score_bar(plan.macro_score, 100)}</div>
        <div class="score-item"><span class="score-label">최종</span>${score_bar(plan.final_score, 100)}</div>
      </div>` : ''}
      <div class="text-muted mt-8" style="font-size:12px">${escHtml(plan.reason || '')}</div>
      <div class="text-muted mt-4" style="font-size:11px">${fmt_time(plan.created_at)}</div>
    </div>` : ''}
  `;
}

function buildApprovalBanners(approval) {
  let html = '';
  const ca = approval.crypto || {};
  const sa = approval.stock || {};

  if (ca.show_banner || ca.pending) {
    const expired = !ca.pending && ca.status === 'EXPIRED';
    html += `
    <div class="approval-banner approval-crypto ${expired ? 'approval-expired' : ''}">
      <div class="approval-header">
        <span class="approval-badge">🪙 ${expired ? '코인 승인 만료' : '코인 승인 대기'}</span>
        <span class="approval-expires">${expired ? '⌛ 만료됨' : '만료: ' + fmt_time(ca.expires_at)}</span>
      </div>
      <div class="approval-body">
        <div class="approval-info">
          <strong>${escHtml(ca.display_name || ca.market)}</strong>
          <span class="badge ${ca.side === 'sell' ? 'badge-danger' : 'badge-success'}">${ca.side === 'sell' ? '매도' : '매수'}</span>
          <span>${fmt_krw(ca.krw_amount)}</span>
          <span class="text-muted">현재가 ${fmt_krw(ca.current_price)}</span>
        </div>
        <div class="approval-reason text-muted">${escHtml((ca.reason || '').slice(0, 200))}</div>
      </div>
      <div class="approval-actions">
        ${expired
          ? `<button class="btn btn-primary btn-sm" onclick="triggerRecommendDash('crypto')">🔄 재분석</button>
             <button class="btn btn-ghost btn-sm" onclick="doApproval('crypto','reject','${escHtml(ca.token)}')">✕ 닫기</button>`
          : `<button class="btn btn-success btn-sm" onclick="doApproval('crypto','approve','${escHtml(ca.token)}')">✅ 승인</button>
             <button class="btn btn-danger btn-sm"  onclick="doApproval('crypto','reject','${escHtml(ca.token)}')">❌ 거부</button>`
        }
      </div>
    </div>`;
  }

  if (sa.pending) {
    html += `
    <div class="approval-banner approval-stock">
      <div class="approval-header">
        <span class="approval-badge">📈 주식 승인 대기</span>
        <span class="approval-expires">만료: ${fmt_time(sa.expires_at)}</span>
      </div>
      <div class="approval-body">
        <div class="approval-info">
          <strong>주문 ${sa.order_count}건</strong>
          <span>${fmt_krw(sa.total_order_value)}</span>
          ${sa.plan_warnings && sa.plan_warnings.length > 0
            ? `<span class="badge badge-warning">경고 ${sa.plan_warnings.length}개</span>` : ''}
        </div>
        ${sa.manual_live_approve_command ? `<div class="approval-cmd"><code>${escHtml(sa.manual_live_approve_command)}</code></div>` : ''}
      </div>
      <div class="approval-actions">
        <button class="btn btn-success btn-sm" onclick="doApproval('stock','approve','${escHtml(sa.token)}')">✅ 승인</button>
        <button class="btn btn-danger btn-sm"  onclick="doApproval('stock','reject','${escHtml(sa.token)}')">❌ 거부</button>
        <button class="btn btn-ghost btn-sm"   onclick="doApproval('stock','halt','${escHtml(sa.token)}')">🚫 오늘 중단</button>
      </div>
    </div>`;
  }
  return html;
}

async function doApproval(type, action, token) {
  const labels = { approve: '승인', reject: '거부', halt: '오늘 중단' };
  if (!confirm(`${labels[action] || action}하시겠습니까?`)) return;
  try {
    const res = await POST('/api/approval/action', { type, action, token });
    toast(res.message, res.ok ? 'success' : 'error');
    if (res.ok) await loadDashboard();
  } catch (e) {
    toast('요청 실패: ' + e.message, 'error');
  }
}

// ══════════════════════════════════════════════
// 러너 제어
// ══════════════════════════════════════════════
let runnerInterval = null;

async function renderRunner() {
  clearInterval(runnerInterval);
  const el = document.getElementById('page-runner');
  el.innerHTML = '<div class="page-header"><h1 class="page-title">러너 제어</h1></div><div class="text-muted">상태 로딩 중...</div>';
  await loadRunner();
  runnerInterval = setInterval(loadRunner, 5000);
}

async function loadRunner() {
  if (currentPage !== 'runner') { clearInterval(runnerInterval); return; }
  const d = await GET('/api/status');
  const r = d.runner || {};
  updateRunnerBadge(r);

  const runState = r.running ? (r.paused ? 'paused' : 'running') : 'stopped';
  const stateLabel = { running: '🟢 실행 중', stopped: '🔴 중지됨', paused: '⏸ 일시정지' }[runState];

  document.getElementById('page-runner').innerHTML = `
    <div class="page-header">
      <h1 class="page-title">러너 제어</h1>
      <div class="page-subtitle">crypto-auto-runner 프로세스 관리 (${r.source || 'unknown'})</div>
    </div>

    <div class="status-row">
      <div class="status-indicator">
        <div class="status-dot ${runState}"></div>
        <span class="status-label">${stateLabel}</span>
      </div>
      ${r.pid ? `<span class="status-meta">PID ${r.pid}</span>` : ''}
      ${r.uptime_sec ? `<span class="status-meta">업타임 ${fmt_uptime(r.uptime_sec)}</span>` : ''}
      ${r.paused && r.pause_reason ? `<span class="badge badge-warning">${r.pause_reason}</span>` : ''}
    </div>

    <div class="control-card">
      <div class="control-card-title">프로세스 제어</div>
      <div class="btn-group">
        <button class="btn btn-success" onclick="runnerAction('start')"   ${r.running ? 'disabled' : ''}>▶ 시작</button>
        <button class="btn btn-danger"  onclick="runnerAction('stop')"    ${!r.running ? 'disabled' : ''}>⏹ 중지</button>
        <button class="btn btn-warning" onclick="runnerAction('restart')">↺ 재시작</button>
      </div>
    </div>

    <div class="control-card">
      <div class="control-card-title">일시정지 (프로세스 유지, 매매만 중단)</div>
      <div class="form-row-inline">
        <div class="label-group">
          <div class="main-label">전체 일시정지</div>
          <div style="font-size:12px;color:var(--text-muted)">다음 틱부터 BUY/SELL 모두 건너뜀</div>
        </div>
        <label class="toggle">
          <input type="checkbox" id="toggle-pause" ${r.paused ? 'checked' : ''}
            onchange="togglePause(this.checked)" ${!r.running ? 'disabled' : ''}>
          <span class="toggle-slider"></span>
        </label>
      </div>
    </div>

    <div class="control-card">
      <div class="control-card-title">분석 요청 (텔레그램 메뉴 기능)</div>
      <div class="btn-group">
        <button class="btn btn-primary" onclick="triggerRecommend('crypto')">🪙 코인 분석 실행</button>
        <button class="btn btn-primary" onclick="triggerRecommend('stock')">📈 주식 분석 실행</button>
      </div>
      <div id="recommend-status" class="text-muted mt-8" style="font-size:12px"></div>
    </div>

    <div class="section-box">
      <div class="section-title">📊 오늘 통계</div>
      <div class="cards" style="margin-bottom:0">
        <div class="card"><div class="card-label">주문 수</div><div class="card-value">${r.orders_today ?? 0}</div></div>
        <div class="card"><div class="card-label">매수 금액</div><div class="card-value" style="font-size:15px">${fmt_krw(r.buy_krw_today)}</div></div>
        <div class="card"><div class="card-label">마지막 종목</div><div class="card-value" style="font-size:14px">${r.last_market || '-'}</div></div>
        <div class="card"><div class="card-label">일자 키</div><div class="card-value" style="font-size:13px">${r.daily_key || '-'}</div></div>
      </div>
    </div>
  `;
}

async function runnerAction(action) {
  const btn = event.target;
  btn.disabled = true;
  const labels = { start: '시작', stop: '중지', restart: '재시작' };
  btn.textContent = labels[action] + '...';
  try {
    const res = await POST(`/api/runner/${action}`);
    toast(res.message, res.ok ? 'success' : 'error');
    await loadRunner();
  } catch (e) {
    toast('요청 실패: ' + e.message, 'error');
  }
}

async function togglePause(paused) {
  const res = await POST('/api/runner/pause', { paused, reason: paused ? '웹UI 일시정지' : '' });
  toast(res.message, res.ok ? 'success' : 'error');
  await loadRunner();
}

async function togglePauseDash(paused) {
  const res = await POST('/api/runner/pause', { paused, reason: paused ? '웹UI 일시정지' : '' });
  toast(res.message, res.ok ? 'success' : 'error');
  await loadDashboard();
}

async function triggerRecommend(type) {
  const statusEl = document.getElementById('recommend-status');
  if (statusEl) statusEl.textContent = '분석 요청 중...';
  try {
    const res = await POST('/api/runner/recommend', { type });
    toast(res.message, res.ok ? 'success' : 'error');
    if (statusEl) statusEl.textContent = res.ok ? '✅ 완료 — 대시보드에서 승인/거부하세요' : res.message;
  } catch (e) {
    if (statusEl) statusEl.textContent = '오류: ' + e.message;
    toast('요청 실패', 'error');
  }
}

async function triggerStopLoss() {
  if (!confirm('손절 분석을 실행합니다.\n분석 결과는 승인 배너에서 확인 후 직접 승인/거부할 수 있습니다.\n계속하시겠습니까?')) return;
  await triggerRecommendDash('crypto');
}

async function triggerRecommendDash(type) {
  const label = type === 'crypto' ? '코인' : '주식';
  dashAnalyzing = true;
  document.querySelectorAll('.quick-analyze-group .btn').forEach(b => b.disabled = true);
  const s0 = document.getElementById('dash-recommend-status');
  if (s0) { s0.textContent = `⏳ ${label} 분석 중...`; s0.className = 'quick-bar-status'; }
  const loadingToast = toastLoading(`⏳ ${label} 분석 중... (최대 3분 소요)`);
  let msg = '', cls = '';
  try {
    const res = await POST('/api/runner/recommend', { type });
    msg = res.message || (res.ok ? '분석 완료' : '분석 실패');
    cls = 'quick-bar-status ' + (res.ok ? (res.has_plan ? 'text-ok' : '') : 'text-danger');
    loadingToast.update(msg, res.ok ? 'success' : 'error', 8000);
    dashAnalyzing = false;
    await loadDashboard();
  } catch (e) {
    msg = '오류: ' + e.message;
    cls = 'quick-bar-status text-danger';
    loadingToast.update('요청 실패: ' + e.message, 'error', 8000);
  } finally {
    dashAnalyzing = false;
    document.querySelectorAll('.quick-analyze-group .btn').forEach(b => b.disabled = false);
    const s = document.getElementById('dash-recommend-status');
    if (s && msg) { s.textContent = msg; s.className = cls; }
  }
}

// ══════════════════════════════════════════════
// 환경설정
// ══════════════════════════════════════════════
let settingsData = null;
let activeSettingsTab = null;

async function renderSettings() {
  const el = document.getElementById('page-settings');
  el.innerHTML = '<div class="page-header"><h1 class="page-title">환경설정</h1></div><div class="text-muted">로딩 중...</div>';
  try {
    const data = await GET('/api/settings');
    settingsData = data;
    const firstTab = Object.keys(data.sections)[0];
    if (!activeSettingsTab) activeSettingsTab = firstTab;
    renderSettingsPage(data);
  } catch (e) {
    el.innerHTML = `<div class="page-header"><h1 class="page-title">환경설정</h1></div>
      <div class="section-box" style="color:var(--danger)">⚠️ 오류: ${e.message}</div>`;
  }
}

function renderSettingsPage(data) {
  try {
    const sections = data.sections;
    const labels   = data.section_labels;
    const el = document.getElementById('page-settings');

    const tabsHtml = Object.entries(labels).map(([key, label]) =>
      `<button class="tab-btn ${key === activeSettingsTab ? 'active' : ''} ${key === 'private' ? 'private-tab' : ''}"
        onclick="switchSettingsTab('${key}')">${label}</button>`
    ).join('');

    const panelsHtml = Object.entries(sections).map(([key, items]) => `
      <div class="tab-panel ${key === activeSettingsTab ? 'active' : ''}" id="settings-tab-${key}">
        ${renderSettingsSection(items, key)}
      </div>
    `).join('');

    el.innerHTML = `
      <div class="page-header">
        <h1 class="page-title">환경설정</h1>
        <div class="page-subtitle">.env 파일 설정 — 저장 시 자동 적용</div>
      </div>
      <div class="section-box">
        <div class="tabs">${tabsHtml}</div>
        ${panelsHtml}
        <hr class="divider">
        <div class="flex-row">
          <div class="spacer"></div>
          <button class="btn btn-ghost" onclick="renderSettings()">↺ 초기화</button>
          <button class="btn btn-primary" onclick="saveSettings()">💾 저장</button>
        </div>
      </div>
    `;
  } catch(e) {
    document.getElementById('page-settings').innerHTML =
      `<div class="page-header"><h1 class="page-title">환경설정</h1></div>
       <div class="section-box" style="color:var(--danger)">⚠️ 렌더링 오류: ${e.message}</div>`;
  }
}

const _PRIVATE_GROUPS = ["Upbit API", "KIS API", "Telegram", "알림 서비스"];

function renderSettingsSection(items, sectionKey) {
  if (sectionKey === 'private') return renderPrivateSection(items);
  return renderItemList(items);
}

function renderPrivateSection(items) {
  const warning = `
    <div class="privacy-warning">
      <span class="warn-icon">🔒</span>
      <div>
        <strong>개인정보 보호</strong> — API 키·토큰은 절대 타인과 공유하지 마세요.<br>
        테스터에게 공유 시 이 탭을 비워두거나 별도 계정·키를 발급하세요.
      </div>
    </div>`;
  const grouped = {};
  for (const item of items) {
    const g = item.group || '기타';
    (grouped[g] = grouped[g] || []).push(item);
  }
  const order = [..._PRIVATE_GROUPS, ...Object.keys(grouped).filter(g => !_PRIVATE_GROUPS.includes(g))];
  const groupsHtml = order.filter(g => grouped[g]).map(g => `
    <div class="settings-group">
      <div class="settings-group-title">${g}</div>
      ${renderItemList(grouped[g])}
    </div>`).join('');
  return warning + groupsHtml;
}

function helpIcon(desc) {
  if (!desc) return '';
  return `<span class="help-icon" data-tip="${escHtml(desc)}">?</span>`;
}

function renderItemList(items) {
  return items.map(item => {
    const key = item.key;
    const tip = helpIcon(item.desc);

    if (item.type === 'bool') {
      const checked = ['true', '1', 'yes'].includes((item.value || '').toLowerCase());
      return `<div class="form-row-inline">
        <div class="label-group">
          <div class="main-label">${item.label} ${tip}</div>
        </div>
        <label class="toggle">
          <input type="checkbox" data-key="${key}" ${checked ? 'checked' : ''}>
          <span class="toggle-slider"></span>
        </label>
      </div>`;
    }
    if (item.type === 'select') {
      const opts = (item.options || []).map(o =>
        `<option value="${o}" ${o === item.value ? 'selected' : ''}>${o}</option>`
      ).join('');
      return `<div class="form-row">
        <label class="form-label">${item.label} ${tip}</label>
        <select class="form-input form-select" data-key="${key}">${opts}</select>
      </div>`;
    }
    const inputType = item.type === 'secret' ? 'password' : 'text';
    const setHint = item.set ? '<span class="set-dot" title="설정됨">●</span>' : '';
    return `<div class="form-row">
      <label class="form-label">${item.label} ${setHint} ${tip}</label>
      <input type="${inputType}" class="form-input" data-key="${key}"
        value="${item.value || ''}" placeholder="${item.set ? '(설정됨)' : '미설정'}">
    </div>`;
  }).join('');
}

function switchSettingsTab(key) {
  activeSettingsTab = key;
  document.querySelectorAll('.tab-btn').forEach((b, i) => {
    const keys = Object.keys(settingsData.sections);
    b.classList.toggle('active', keys[i] === key);
  });
  document.querySelectorAll('.tab-panel').forEach(p => {
    p.classList.toggle('active', p.id === `settings-tab-${key}`);
  });
}

async function saveSettings() {
  const updates = {};
  document.querySelectorAll('[data-key]').forEach(el => {
    const key = el.dataset.key;
    if (el.type === 'checkbox') updates[key] = el.checked ? 'true' : 'false';
    else updates[key] = el.value;
  });
  const res = await POST('/api/settings', { updates });
  toast(res.message, res.ok ? 'success' : 'error');
}

// ══════════════════════════════════════════════
// 로그 뷰어
// ══════════════════════════════════════════════
let logWs = null;
let logAutoScroll = true;
let logFile = 'crypto_auto_runner';

async function renderLogs() {
  if (logWs) { logWs.close(); logWs = null; }
  const el = document.getElementById('page-logs');
  el.innerHTML = `
    <div class="page-header">
      <h1 class="page-title">로그 뷰어</h1>
    </div>
    <div class="section-box">
      <div class="log-controls">
        <select class="form-input form-select" id="log-file-select" style="width:240px" onchange="changeLogFile(this.value)">
          <option value="crypto_auto_runner">crypto_auto_runner</option>
          <option value="crypto_auto_runner.error">crypto_auto_runner (에러)</option>
          <option value="binance_stream">binance_stream</option>
        </select>
        <label class="toggle-wrap">
          <label class="toggle">
            <input type="checkbox" id="autoscroll-toggle" checked onchange="logAutoScroll=this.checked">
            <span class="toggle-slider"></span>
          </label>
          <span style="font-size:13px;color:var(--text-muted)">자동 스크롤</span>
        </label>
        <button class="btn btn-ghost" onclick="clearLogView()">🗑 지우기</button>
        <button class="btn btn-ghost" id="ws-status-btn" style="font-size:12px">● 연결 중...</button>
      </div>
      <div class="log-container" id="log-container"></div>
    </div>
  `;
  connectLogWs(logFile);
}

function changeLogFile(file) {
  logFile = file;
  if (logWs) { logWs.close(); logWs = null; }
  document.getElementById('log-container').innerHTML = '';
  connectLogWs(file);
}

function connectLogWs(file) {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  logWs = new WebSocket(`${proto}://${location.host}/ws/logs?file=${file}`);
  const btn = document.getElementById('ws-status-btn');
  logWs.onopen  = () => { if (btn) btn.textContent = '🟢 실시간 연결됨'; };
  logWs.onclose = () => { if (btn) btn.textContent = '🔴 연결 끊김'; };
  logWs.onerror = () => { if (btn) btn.textContent = '🔴 오류'; };
  logWs.onmessage = (e) => {
    const msg = JSON.parse(e.data);
    if (msg.type === 'line') appendLogLine(msg.data);
  };
}

function appendLogLine(line) {
  const container = document.getElementById('log-container');
  if (!container) return;
  const el = document.createElement('div');
  el.className = 'log-line';
  const lower = line.toLowerCase();
  if (lower.includes('error') || lower.includes('traceback') || lower.includes('exception')) el.classList.add('error');
  else if (lower.includes('warn')) el.classList.add('warn');
  else if (lower.includes('[gate]') || lower.includes('[tick]') || lower.includes('[scan]')) el.classList.add('tick');
  else if (lower.includes('[info]') || lower.includes('startup') || lower.includes('started')) el.classList.add('info');
  el.textContent = line;
  container.appendChild(el);
  if (logAutoScroll) container.scrollTop = container.scrollHeight;
  while (container.children.length > 500) container.removeChild(container.firstChild);
}

function clearLogView() {
  const c = document.getElementById('log-container');
  if (c) c.innerHTML = '';
}

// ══════════════════════════════════════════════
// 신호 분석
// ══════════════════════════════════════════════
let analysisInterval = null;

async function renderAnalysis() {
  clearInterval(analysisInterval);
  const el = document.getElementById('page-analysis');
  el.innerHTML = '<div class="page-header"><h1 class="page-title">신호 분석</h1></div><div class="text-muted">데이터 로딩 중...</div>';
  await loadAnalysis();
  analysisInterval = setInterval(loadAnalysis, 15000);
}

async function loadAnalysis() {
  if (currentPage !== 'analysis') { clearInterval(analysisInterval); return; }

  const [plan, sizing, universe, slippage, reconcile] = await Promise.all([
    GET('/api/plan/detail').catch(() => ({})),
    GET('/api/sizing').catch(() => ({})),
    GET('/api/universe').catch(() => ({})),
    GET('/api/slippage?limit=30').catch(() => ({ entries: [] })),
    GET('/api/reconcile').catch(() => ({})),
  ]);

  // 스코어 패널
  const sb = plan.score_breakdown || {};
  const gates = plan.quality_gates || {};
  const gateHtml = Object.entries(gates).map(([k, v]) => {
    const ok = v === 'ok' || v === 'pass' || v === true;
    const cls = ok ? 'gate-ok' : 'gate-fail';
    return `<div class="gate-item ${cls}">
      <span class="gate-icon">${ok ? '✅' : '⚠️'}</span>
      <span class="gate-key">${k}</span>
      <span class="gate-val">${v}</span>
    </div>`;
  }).join('') || '<div class="text-muted">게이트 정보 없음</div>';

  // 유니버스 테이블
  const markets = universe.markets || [];
  const displayNames = universe.display_names || {};
  const universeRows = markets.map(m => `<tr>
    <td><strong>${m}</strong></td>
    <td>${escHtml(displayNames[m] || '-')}</td>
  </tr>`).join('');

  // 사이징 노트
  const sizingNotes = (sizing.notes || []).map(n => `<li>${escHtml(n)}</li>`).join('');

  // 슬리피지 테이블
  const slipRows = (slippage.entries || []).map(e => `<tr>
    <td><strong>${e.market || '-'}</strong></td>
    <td><span class="badge ${e.side === 'buy' ? 'badge-success' : 'badge-danger'}">${e.side || '-'}</span></td>
    <td>${fmt_krw(e.order_krw)}</td>
    <td>${e.limit_price != null ? e.limit_price : '-'}</td>
    <td>${e.fill_price  != null ? e.fill_price  : '-'}</td>
    <td class="${(e.slippage_bps || 0) > 5 ? 'text-danger' : ''}">${fmt_bps(e.slippage_bps)}</td>
  </tr>`).join('');

  // 리콘사일 상태
  const recOk = reconcile.success;
  const recMissDb = (reconcile.missing_in_db || []).join(', ') || '없음';
  const recMissBr = (reconcile.missing_in_broker || []).join(', ') || '없음';
  const recWarns  = (reconcile.warnings || []).join(', ') || '없음';

  document.getElementById('page-analysis').innerHTML = `
    <div class="page-header">
      <h1 class="page-title">신호 분석</h1>
      <div class="page-subtitle">마지막 플랜 기준 — ${fmt_time(plan.generated_at || plan.created_at)}</div>
    </div>

    ${plan.market ? `
    <div class="section-box">
      <div class="section-title">📊 신호 점수 — ${escHtml(plan.display_name || plan.market || '')}</div>
      <div class="score-grid">
        <div class="score-col">
          <div class="score-row-full">
            <span class="score-label">기술적 점수</span>
            ${score_bar(plan.technical_score, 100)}
          </div>
          <div class="score-row-full">
            <span class="score-label">거시경제 점수</span>
            ${score_bar(plan.macro_score, 100)}
          </div>
          <div class="score-row-full">
            <span class="score-label">최종 점수</span>
            ${score_bar(plan.final_score, 100)}
          </div>
          ${plan.macro_regime ? `<div class="score-meta">레짐: <strong>${plan.macro_regime}</strong></div>` : ''}
          ${plan.side ? `<div class="score-meta">방향: <span class="badge ${plan.side === 'buy' ? 'badge-success' : 'badge-danger'}">${plan.side.toUpperCase()}</span></div>` : ''}
          ${plan.sell_trigger ? `<div class="score-meta">SELL 트리거: <span class="badge badge-warning">${plan.sell_trigger}</span></div>` : ''}
        </div>
        <div class="score-col">
          <div class="gates-title">품질 게이트</div>
          ${gateHtml}
        </div>
      </div>
      ${plan.reason ? `<div class="text-muted mt-8" style="font-size:12px;border-top:1px solid var(--border);padding-top:10px">${escHtml(plan.reason)}</div>` : ''}
    </div>` : `<div class="section-box"><div class="text-muted">플랜 데이터 없음</div></div>`}

    <div class="dash-grid">
      <div class="section-box">
        <div class="section-title">🔭 코인 유니버스 (${markets.length}개 스캔)</div>
        ${markets.length > 0 ? `<div class="table-wrap"><table>
          <thead><tr><th>마켓</th><th>이름</th></tr></thead>
          <tbody>${universeRows}</tbody>
        </table></div>` : '<div class="text-muted">유니버스 정보 없음</div>'}
        ${universe.min_acc_trade_price_24h ? `<div class="text-muted mt-8" style="font-size:11px">24h 거래대금 최소: ${(universe.min_acc_trade_price_24h / 1e8).toFixed(0)}억원</div>` : ''}
      </div>

      <div class="section-box">
        <div class="section-title">⚖️ 활성 포지션 사이징</div>
        ${Object.keys(sizing).length > 0 ? `
        <div class="sizing-grid">
          <div class="sizing-item"><span class="sizing-key">가용 KRW</span><span class="sizing-val">${fmt_krw(sizing.available_krw)}</span></div>
          <div class="sizing-item"><span class="sizing-key">총 포트폴리오</span><span class="sizing-val">${fmt_krw(sizing.total_portfolio_krw)}</span></div>
          <div class="sizing-item"><span class="sizing-key">주문 한도</span><span class="sizing-val">${fmt_krw(sizing.max_order_krw)}</span></div>
          <div class="sizing-item"><span class="sizing-key">일일 최대 주문</span><span class="sizing-val">${sizing.max_orders_per_day}회</span></div>
          <div class="sizing-item"><span class="sizing-key">ATR</span><span class="sizing-val">${sizing.atr_pct != null ? Number(sizing.atr_pct).toFixed(2) + '%' : '-'}</span></div>
          <div class="sizing-item"><span class="sizing-key">레짐</span><span class="sizing-val">${sizing.macro_regime || '-'}</span></div>
          <div class="sizing-item"><span class="sizing-key">TP / SL</span><span class="sizing-val">+${sizing.take_profit_pct}% / ${sizing.stop_loss_pct}%</span></div>
          <div class="sizing-item"><span class="sizing-key">스코어 팩터</span><span class="sizing-val">${sizing.score_factor || '-'}</span></div>
        </div>
        ${sizingNotes ? `<ul class="sizing-notes">${sizingNotes}</ul>` : ''}
        ` : '<div class="text-muted">사이징 정보 없음</div>'}
      </div>
    </div>

    <div class="section-box">
      <div class="section-title">📉 체결 슬리피지 기록</div>
      ${slipRows ? `<div class="table-wrap"><table>
        <thead><tr><th>마켓</th><th>방향</th><th>주문금액</th><th>계획가</th><th>체결가</th><th>슬리피지</th></tr></thead>
        <tbody>${slipRows}</tbody>
      </table></div>
      <div class="text-muted mt-8" style="font-size:11px">최근 ${(slippage.entries || []).length}건 (전체 ${slippage.total || 0}건)</div>`
      : '<div class="text-muted">슬리피지 기록 없음</div>'}
    </div>

    <div class="section-box">
      <div class="section-title">🔄 리콘사일 (계좌 대사)</div>
      <div class="cards" style="margin-bottom:12px">
        <div class="card ${recOk ? 'ok' : 'danger'}">
          <div class="card-label">상태</div>
          <div class="card-value" style="font-size:16px">${recOk ? '✅ 정상' : '⚠️ 불일치'}</div>
          <div class="card-sub">${fmt_time(reconcile.timestamp)}</div>
        </div>
        <div class="card ${(reconcile.matched || []).length > 0 ? 'ok' : ''}">
          <div class="card-label">일치 종목</div>
          <div class="card-value">${(reconcile.matched || []).length}개</div>
          <div class="card-sub">${(reconcile.matched || []).join(', ') || '-'}</div>
        </div>
      </div>
      <div style="font-size:12px;color:var(--text-muted)">
        DB 누락: ${recMissDb} &nbsp;|&nbsp; 브로커 누락: ${recMissBr} &nbsp;|&nbsp; 경고: ${recWarns}
      </div>
    </div>
  `;
}

// ══════════════════════════════════════════════
// 리포트 뷰어
// ══════════════════════════════════════════════
let activeReport = null;

// 파일명 → 사람이 읽을 수 있는 한국어 라벨 + 갱신 주기
const REPORT_META = {
  'AI_DAILY_TRADE_PLAN.md':              { icon: '📋', label: '오늘의 매매계획 (주식)',     category: '매매', refresh: '매일 자동\n시간: 약 11:55 KST\n주식 러너 daily-ai-trade-plan 실행 시' },
  'CRYPTO_DAILY_TRADE_PLAN.md':          { icon: '📋', label: '오늘의 매매계획 (코인)',     category: '매매', refresh: '자동 갱신 (약 1분마다)\n코인 러너 틱마다 최신 코인 계획 덮어씀' },
  'AI_LIVE_TRADE_RECOMMENDATION.md':     { icon: '🎯', label: '실시간 매매 추천',           category: '매매', refresh: '매일 자동\n시간: 약 11:55 KST\n주식 AI 추천 생성 시' },
  'SELL_PLAN.md':                        { icon: '📤', label: '매도 계획',                  category: '매매', refresh: '매일 자동\n시간: 약 19:00 KST\n일일 운영 요약 실행 시' },
  'TELEGRAM_APPROVAL_REQUEST.md':        { icon: '📱', label: '승인 요청 내역',             category: '매매', refresh: '승인 요청 생성 시마다\n자동/수동 분석 후 텔레그램 발송 시' },

  'AI_DAILY_TRADE_REPORT.md':            { icon: '📊', label: '오늘의 매매 결과',           category: '성과', refresh: '매일 자동\n시간: 약 15:40 KST\ndaily-ai-trade-report 실행 시' },
  'RECOMMENDATION_PERFORMANCE.md':       { icon: '📈', label: '추천 적중률 분석 (주식)',    category: '성과', refresh: '매일 자동\n시간: 약 19:55 KST\n주간 점검 또는 ops-summary 실행 시' },
  'CRYPTO_RECOMMENDATION_PERFORMANCE.md':{ icon: '📈', label: '추천 적중률 분석 (코인)',    category: '성과', refresh: '매일 자동\n시간: 약 19:55 KST\n주간 점검 실행 시' },
  'AI_RECOMMENDATION_VALIDATION.md':     { icon: '✅', label: '추천 신뢰도 검증',           category: '성과', refresh: '매일 자동\nAI 추천 실행 시마다 생성' },

  'LIVE_ACCOUNT_SNAPSHOT.md':            { icon: '💰', label: '실시간 계좌 현황',           category: '계좌', refresh: '매일 자동\n시간: 약 09:00, 11:55, 19:00 KST\n계좌 동기화 시' },
  'RECONCILE_LIVE_ACCOUNT.md':           { icon: '🔄', label: '계좌 잔고 대사',             category: '계좌', refresh: '매일 자동\n시간: 약 11:55 KST\n잔고 대사 실행 시' },
  'EXECUTE_APPROVED_AUDIT.md':           { icon: '🧾', label: '주문 실행 이력',             category: '계좌', refresh: '주문 실행 시마다\n승인 후 실제 주문이 들어갈 때마다 갱신' },

  'RISK_ALERT.md':                       { icon: '🚨', label: '위험 경보',                  category: '점검', refresh: '매일 자동\n시간: 약 19:00 KST\n위험 점검 실행 시' },
  'SAFETY_AUDIT.md':                     { icon: '🛡️', label: '안전 점검 기록',            category: '점검', refresh: '매일 자동\n시간: 약 11:55 KST\ndaily-ai-trade-plan 실행 시 포함' },
  'REPORT_HEALTH.md':                    { icon: '🏥', label: '리포트 시스템 상태',         category: '점검', refresh: '수동 / 주 1회\nweekly-maintenance 명령 실행 시\n또는 report-health-check 직접 실행 시' },
  'AI_DAILY_STATUS.md':                  { icon: '🤖', label: 'AI 시스템 상태',             category: '점검', refresh: '매일 자동\n시간: 약 11:55 KST' },
  'WEEKLY_MAINTENANCE.md':               { icon: '🔧', label: '주간 시스템 점검',           category: '점검', refresh: '수동 / 주 1회\nweekly-maintenance 명령 실행 시\n자동 스케줄 없음' },

  'CRYPTO_THRESHOLD_TUNING.md':          { icon: '⚙️', label: '코인 임계값 조정 내역',     category: '설정', refresh: '수동\ncrypto-threshold-tune 명령 실행 시' },
  'OUTCOME_THRESHOLD_TUNING.md':         { icon: '⚙️', label: '성과 임계값 조정 내역',     category: '설정', refresh: '수동\noutcome-threshold-tune 명령 실행 시' },
  'ANALYSIS_CONDITIONS.md':              { icon: '🔍', label: '분석 조건 설정',             category: '설정', refresh: '수동\n설정 변경 시 수동 실행 필요' },

  'DAILY_OPS_SUMMARY.md':                { icon: '📅', label: '일일 운영 요약',             category: '기타', refresh: '매일 자동\n시간: 약 19:55 KST\ndaily-ops-summary 실행 시' },
  'ARCHIVE_VIEWER_SUMMARY.md':           { icon: '📦', label: '과거 데이터 요약',           category: '기타', refresh: '수동\narchive-viewer 명령 실행 시' },
  'REPORT_INDEX.md':                     { icon: '📑', label: '전체 리포트 목록',           category: '기타', refresh: '수동 / 주 1회\nweekly-maintenance 또는 report-index 실행 시' },
};

const REPORT_CATEGORY_ORDER = ['매매', '성과', '계좌', '점검', '설정', '기타'];

function reportDisplayName(name) {
  const m = REPORT_META[name];
  if (m) return `${m.icon} ${m.label}`;
  return name.replace(/\.md$/i, '').replace(/_/g, ' ').toLowerCase()
    .replace(/\b\w/g, c => c.toUpperCase());
}

function reportRefreshTooltip(name) {
  const m = REPORT_META[name];
  return m?.refresh ?? '갱신 주기 정보 없음';
}

function reportCategory(name) {
  return REPORT_META[name]?.category ?? '기타';
}

async function renderReports() {
  const el = document.getElementById('page-reports');
  el.innerHTML = '<div class="page-header"><h1 class="page-title">리포트</h1></div><div class="text-muted">목록 로딩 중...</div>';
  try {
    const data = await GET('/api/reports');
    const reports = data.reports || [];
    renderReportsPage(reports);
  } catch (e) {
    el.innerHTML = `<div class="page-header"><h1 class="page-title">리포트</h1></div>
      <div class="section-box" style="color:var(--danger)">⚠️ 오류: ${e.message}</div>`;
  }
}

function renderReportsPage(reports) {
  const el = document.getElementById('page-reports');

  // 카테고리별로 그룹핑
  const groups = {};
  reports.forEach(r => {
    const cat = reportCategory(r.name);
    if (!groups[cat]) groups[cat] = [];
    groups[cat].push(r);
  });

  const listHtml = reports.length === 0
    ? '<div class="text-muted" style="padding:12px">리포트 없음</div>'
    : REPORT_CATEGORY_ORDER.filter(c => groups[c]).map(cat => `
      <div class="report-category-header">${cat}</div>
      ${groups[cat].map(r => `
        <div class="report-item ${activeReport === r.name ? 'active' : ''}" data-name="${escHtml(r.name)}" onclick="loadReport('${escHtml(r.name)}')">
          <div class="report-item-row">
            <div class="report-label">${reportDisplayName(r.name)}</div>
            <span class="report-refresh-btn" title="${escHtml(reportRefreshTooltip(r.name))}" onclick="event.stopPropagation()">?</span>
          </div>
          <div class="report-meta">${fmt_time(r.modified)}</div>
        </div>`).join('')}
    `).join('');

  el.innerHTML = `
    <div class="page-header">
      <h1 class="page-title">리포트 뷰어</h1>
      <div class="page-subtitle">분석·매매·점검 리포트 — ${reports.length}개</div>
    </div>
    <div class="reports-layout">
      <div class="reports-sidebar">
        <div class="reports-sidebar-header">리포트 목록</div>
        ${listHtml}
      </div>
      <div class="reports-content" id="report-content">
        <div class="text-muted report-placeholder">왼쪽에서 리포트를 선택하세요</div>
      </div>
    </div>
  `;

  if (activeReport) loadReport(activeReport);
}

async function loadReport(name) {
  activeReport = name;
  const contentEl = document.getElementById('report-content');
  if (!contentEl) return;
  contentEl.innerHTML = '<div class="text-muted">로딩 중...</div>';

  document.querySelectorAll('.report-item').forEach(el => {
    el.classList.toggle('active', el.dataset.name === name);
  });

  try {
    const data = await GET(`/api/reports/${encodeURIComponent(name)}`);
    const displayName = reportDisplayName(name);
    contentEl.innerHTML = `
      <div class="report-toolbar">
        <span class="report-display-name">${escHtml(displayName)}</span>
        <span class="report-filename-small">${escHtml(name)}</span>
        <button class="btn btn-ghost btn-sm" onclick="loadReport('${escHtml(name)}')">↺ 새로고침</button>
      </div>
      <div class="report-body">${md2html(data.content || '')}</div>
    `;
  } catch (e) {
    contentEl.innerHTML = `<div class="text-danger">오류: ${e.message}</div>`;
  }
}

// ══════════════════════════════════════════════
// 공통
// ══════════════════════════════════════════════
function updateRunnerBadge(r) {
  const dot  = document.querySelector('.badge-dot');
  const text = document.querySelector('.badge-text');
  if (!dot || !text) return;
  dot.className = 'badge-dot';
  if (r.running && !r.paused) {
    dot.classList.add('running');
    text.textContent = '실행 중';
  } else if (r.running && r.paused) {
    dot.classList.add('paused');
    text.textContent = '일시정지';
  } else {
    dot.classList.add('stopped');
    text.textContent = '중지됨';
  }
}

// ══════════════════════════════════════════════
// 실시간 이벤트 WebSocket (/ws/events)
// ══════════════════════════════════════════════
let eventsWs = null;
let eventsReconnectTimer = null;

function connectEventsWs() {
  if (eventsWs && eventsWs.readyState <= 1) return;
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  eventsWs = new WebSocket(`${proto}://${location.host}/ws/events`);

  eventsWs.onopen = () => {
    clearTimeout(eventsReconnectTimer);
  };

  eventsWs.onclose = () => {
    eventsReconnectTimer = setTimeout(connectEventsWs, 3000);
  };

  eventsWs.onerror = () => {
    eventsWs.close();
  };

  eventsWs.onmessage = (e) => {
    let msg;
    try { msg = JSON.parse(e.data); } catch { return; }
    handleRealtimeEvent(msg);
  };
}

function handleRealtimeEvent(msg) {
  const { type, data } = msg;
  if (!type || type === 'ping') return;

  switch (type) {
    // ── 초기 스냅샷 ──────────────────────────
    case 'snapshot':
      if (data.runner) updateRunnerBadge(data.runner);
      break;

    // ── 러너 상태 변화 ──────────────────────
    case 'runner_state':
    case 'runner_pid':
    case 'runner_control': {
      // 사이드바 배지 즉시 갱신
      const running = !data._deleted && (data.running !== false);
      updateRunnerBadge({ running, paused: data.runner_paused || false });
      // 대시보드 / 러너 페이지면 전체 새로고침
      if (currentPage === 'dashboard') loadDashboard();
      if (currentPage === 'runner')    loadRunner();
      // 토스트
      if (type === 'runner_control') {
        const labels = { started: '▶️ 러너 시작됨', stopped: '⏹ 러너 중지됨', restarted: '🔄 러너 재시작됨' };
        const src = data.source === 'web_ui' ? '' : ' (텔레그램)';
        toast((labels[data.action] || data.action) + src, 'info');
      }
      break;
    }

    // ── 코인 승인 요청 ──────────────────────
    case 'crypto_approval_request':
      if (!data._deleted && data.status === 'PENDING') {
        toast(`🔔 코인 매수 승인 요청: ${data.market || ''}`, 'warning', 8000);
        if (currentPage === 'dashboard') loadDashboard();
      }
      break;

    // ── 코인 승인 결과 ──────────────────────
    case 'crypto_approval_update': {
      const icon = data.action === 'approved' ? '✅' : '❌';
      const src  = data.source === 'web_ui' ? '[웹UI]' : '[텔레그램]';
      toast(`${icon} ${src} ${data.market || ''} ${data.action === 'approved' ? '승인' : '거부'}됨`, 'success', 6000);
      if (currentPage === 'dashboard') loadDashboard();
      break;
    }

    // ── 주식 승인 변화 ──────────────────────
    case 'stock_approval_update': {
      const icon = data.action === 'approved' ? '✅' : data.action === 'halt' ? '⏹' : '❌';
      const src  = data.source === 'web_ui' ? '[웹UI]' : '[텔레그램]';
      toast(`${icon} ${src} ${data.symbol || '주식'} ${data.action}`, 'info', 6000);
      if (currentPage === 'dashboard') loadDashboard();
      break;
    }

    // ── 새 주문 플랜 ────────────────────────
    case 'order_plan':
      if (!data._deleted && data.market) {
        toast(`📊 새 신호: ${data.market} (${data.side || '매수'} 검토 중)`, 'info', 6000);
        if (currentPage === 'dashboard') loadDashboard();
        if (currentPage === 'analysis') loadAnalysis();
      }
      break;
  }
}

// ══════════════════════════════════════════════
// 초기화
// ══════════════════════════════════════════════

// 1) Telegram WebApp 인증 처리 (비동기, 화면 뒤에서 실행)
initTelegramAuth();

// 2) 초기 페이지 라우팅
const hash = window.location.hash.replace('#', '') || 'dashboard';
navigate(hash);

// 3) 실시간 이벤트 WebSocket 연결
connectEventsWs();

window.addEventListener('beforeunload', () => {
  clearInterval(dashInterval);
  clearInterval(runnerInterval);
  clearInterval(analysisInterval);
  if (logWs) logWs.close();
  if (eventsWs) eventsWs.close();
});
