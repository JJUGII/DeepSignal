"""Crypto SELL trigger classification (take-profit / stop-loss buffers)."""

from __future__ import annotations

from typing import Literal

from deepsignal.scoring.analysis_conditions import DEFAULT_ANALYSIS_CONDITIONS

_CRYPTO = DEFAULT_ANALYSIS_CONDITIONS.crypto

SellTrigger = Literal[
    "take_profit",
    "near_take_profit",
    "stop_loss",
    "near_stop_loss",
    "overweight_reduce",
]

_TRIGGER_PRIORITY: dict[str, int] = {
    "take_profit": 4,
    "near_take_profit": 3,
    "stop_loss": 2,
    "near_stop_loss": 1,
    "overweight_reduce": 0,
}


def sell_trigger_priority(trigger: str) -> int:
    return _TRIGGER_PRIORITY.get(trigger, 0)


def classify_crypto_sell_trigger(
    pnl_pct: float,
    *,
    take_profit_pct: float = _CRYPTO.take_profit_pct,
    stop_loss_pct: float = _CRYPTO.stop_loss_pct,
    take_profit_buffer_pct: float = _CRYPTO.take_profit_buffer_pct,
    stop_loss_buffer_pct: float = _CRYPTO.stop_loss_buffer_pct,
) -> SellTrigger | None:
    """Classify holding PnL into SELL trigger (or None = hold)."""
    pnl = float(pnl_pct)
    tp = float(take_profit_pct)
    sl = float(stop_loss_pct)
    tp_buf = float(take_profit_buffer_pct)
    sl_buf = float(stop_loss_buffer_pct)

    if pnl >= tp:
        return "take_profit"
    if pnl >= tp - tp_buf:
        return "near_take_profit"
    if pnl <= sl:
        return "stop_loss"
    if pnl <= sl + sl_buf:
        return "near_stop_loss"
    entry_review = float(_CRYPTO.entry_drawdown_review_pct)
    if pnl <= entry_review:
        return "near_stop_loss"
    warn_loss = float(_CRYPTO.warn_loss_pct)
    if pnl <= warn_loss:
        return "near_stop_loss"
    return None
