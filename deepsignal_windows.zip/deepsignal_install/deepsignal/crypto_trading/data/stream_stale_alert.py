"""Telegram alert when Binance live_state stops updating."""

from __future__ import annotations

import os
from typing import Any

from deepsignal.crypto_trading.crypto_live_data import check_binance_live_state
from deepsignal.crypto_trading.crypto_telegram_flow import (
    load_crypto_telegram_config_from_env,
    telegram_send_plain,
)
from deepsignal.live_trading.time_utils import now_kst_iso


def stream_stale_threshold_seconds() -> float:
    raw = (
        os.environ.get("CRYPTO_STREAM_STALE_SECONDS")
        or os.environ.get("DEEPSIGNAL_CRYPTO_STREAM_STALE_SECONDS")
        or "180"
    ).strip()
    try:
        return max(60.0, float(raw))
    except ValueError:
        return 180.0


def stale_alert_message(*, age_seconds: float, threshold_seconds: float) -> str:
    age_min = int(age_seconds // 60)
    thr_min = int(threshold_seconds // 60)
    return f"⚠️ [DeepSignal] BTC 스트림 stale {thr_min}분 초과 (마지막 갱신 약 {age_min}분 전)"


def maybe_alert_binance_stream_stale(
    output_dir: str,
    *,
    runner_state: dict[str, Any] | None = None,
    send_telegram: bool = True,
) -> dict[str, Any]:
    """
    Check live_state freshness; send Telegram once per stale episode (until recovered).
    Returns status dict for runner tick JSON.
    """
    threshold = stream_stale_threshold_seconds()
    status = check_binance_live_state(output_dir, max_age_seconds=threshold)
    out: dict[str, Any] = {
        "checked_at": now_kst_iso(),
        "threshold_seconds": threshold,
        "stale": status.stale,
        "age_seconds": status.age_seconds,
        "message": status.message,
        "alert_sent": False,
    }

    state = runner_state if runner_state is not None else {}
    prev_stale = bool(state.get("binance_stream_stale_active"))
    alert_sent_for = str(state.get("binance_stream_stale_alert_sent_for") or "")

    if not status.stale:
        state["binance_stream_stale_active"] = False
        state["binance_stream_stale_alert_sent_for"] = ""
        out["recovered"] = prev_stale
        return out

    state["binance_stream_stale_active"] = True
    episode_key = f"stale:{int(status.age_seconds // 60)}"
    already_sent = prev_stale and alert_sent_for == episode_key

    if send_telegram and not already_sent:
        text = stale_alert_message(age_seconds=status.age_seconds, threshold_seconds=threshold)
        tg = load_crypto_telegram_config_from_env(output_dir=output_dir)
        tg.send = True
        resp = telegram_send_plain(tg, text)
        out["alert_sent"] = bool(resp.get("ok"))
        out["telegram"] = {"ok": resp.get("ok"), "error": resp.get("error")}
        if out["alert_sent"]:
            state["binance_stream_stale_alert_sent_for"] = episode_key
            state["binance_stream_stale_last_alert_at"] = now_kst_iso()
    else:
        out["alert_sent"] = False

    return out
