# data/ — 시장 데이터 레이어

바이낸스 스트림·업비트 실시간 데이터 접근 레이어.

## 포함 모듈

| 파일 | 설명 |
|------|------|
| `live_data.py` | 바이낸스 스트림 상태 |
| `live_universe.py` | 실시간 유니버스 관리 |
| `market_data.py` | 시장 데이터 조회 |
| `stream_stale_alert.py` | 스트림 신선도 경보 |

## 주요 공개 API

```python
from deepsignal.crypto_trading.data import MarketDataFetcher
```
