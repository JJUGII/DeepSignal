"""Binance live_state freshness for crypto runner."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from deepsignal.live_trading.time_utils import now_kst, parse_datetime_with_default_tz


@dataclass
class LiveStateStatus:
    available: bool
    stale: bool
    age_seconds: float
    path: str
    symbol_count: int
    message: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "available": self.available,
            "stale": self.stale,
            "age_seconds": self.age_seconds,
            "path": self.path,
            "symbol_count": self.symbol_count,
            "message": self.message,
        }


def check_binance_live_state(
    output_dir: str | Path = "outputs",
    *,
    max_age_seconds: float = 120.0,
) -> LiveStateStatus:
    path = Path(output_dir) / "binance_stream" / "live_state.json"
    if not path.is_file():
        return LiveStateStatus(
            available=False,
            stale=True,
            age_seconds=-1.0,
            path=path.as_posix(),
            symbol_count=0,
            message="live_state.json 없음 — binance-stream 실행 필요",
        )
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return LiveStateStatus(
            available=False,
            stale=True,
            age_seconds=-1.0,
            path=path.as_posix(),
            symbol_count=0,
            message=f"live_state 읽기 실패: {exc}",
        )

    updated = str(payload.get("updated_at") or payload.get("generated_at") or "")
    age = 9999.0
    if updated:
        try:
            dt = parse_datetime_with_default_tz(updated)
            age = max(0.0, (now_kst() - dt).total_seconds())
        except Exception:
            age = 0.0
    else:
        age = max(0.0, now_kst().timestamp() - path.stat().st_mtime)

    symbols = payload.get("symbols") or []
    stale = age > float(max_age_seconds)
    msg = f"age={age:.0f}s symbols={len(symbols)}"
    if stale:
        msg += f" (stale > {max_age_seconds:.0f}s)"
    return LiveStateStatus(
        available=True,
        stale=stale,
        age_seconds=age,
        path=path.as_posix(),
        symbol_count=len(symbols),
        message=msg,
    )
