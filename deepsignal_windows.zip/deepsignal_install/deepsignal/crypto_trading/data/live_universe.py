"""BUY scan universe from Binance live_state (minimize Upbit REST)."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from deepsignal.crypto_trading.crypto_live_data import check_binance_live_state
from deepsignal.crypto_trading.crypto_ml_gate import upbit_market_to_binance_symbol
from deepsignal.crypto_trading.crypto_universe import (
    CORE_CRYPTO_MARKETS,
    CryptoUniverseConfig,
    CryptoUniverseResult,
    market_display_name,
    select_markets_for_buy_scan,
)
from deepsignal.crypto_trading.upbit_broker import UpbitTicker


def live_state_scan_enabled() -> bool:
    raw = (
        os.environ.get("CRYPTO_USE_LIVE_STATE_SCAN", "true")
        or os.environ.get("DEEPSIGNAL_CRYPTO_USE_LIVE_STATE_SCAN", "true")
    ).strip().lower()
    return raw not in ("0", "false", "no", "off")


def binance_symbol_to_upbit_market(symbol: str) -> str | None:
    s = str(symbol or "").upper()
    if s.endswith("USDT"):
        base = s[:-4]
        if base:
            return f"KRW-{base}"
    return None


def tickers_from_live_state(
    output_dir: str | Path,
    *,
    max_markets: int = 30,
    valid_upbit_markets: frozenset[str] | None = None,
) -> dict[str, UpbitTicker]:
    """Build UpbitTicker map from live_state orderbooks / open bars."""
    path = Path(output_dir) / "binance_stream" / "live_state.json"
    if not path.is_file():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}

    out: dict[str, UpbitTicker] = {}
    orderbooks = payload.get("orderbooks") or {}
    for bsym, ob in orderbooks.items():
        if not isinstance(ob, dict):
            continue
        market = binance_symbol_to_upbit_market(str(bsym))
        if not market:
            continue
        if valid_upbit_markets is not None and market not in valid_upbit_markets:
            continue
        bids = ob.get("bids") or []
        asks = ob.get("asks") or []
        px = 0.0
        if bids and asks:
            try:
                bb = float(bids[0][0])
                ba = float(asks[0][0])
                px = (bb + ba) / 2.0
            except (TypeError, ValueError, IndexError):
                px = 0.0
        if px <= 0:
            continue
        out[market] = UpbitTicker(
            market=market,
            trade_price=px,
            signed_change_rate=0.0,
            acc_trade_price_24h=1_000_000_000.0,
        )

    symbols = payload.get("symbols") or []
    for bsym in symbols:
        market = binance_symbol_to_upbit_market(str(bsym))
        if valid_upbit_markets is not None and market and market not in valid_upbit_markets:
            continue
        if market and market not in out:
            out[market] = UpbitTicker(
                market=market,
                trade_price=0.0,
                signed_change_rate=0.0,
                acc_trade_price_24h=500_000_000.0,
            )

    if len(out) > max_markets:
        ranked = sorted(out.items(), key=lambda kv: kv[1].acc_trade_price_24h, reverse=True)
        out = dict(ranked[: int(max_markets)])
    return out


def resolve_crypto_markets_live_first(
    broker: Any,
    *,
    config: CryptoUniverseConfig | None = None,
    holdings_markets: tuple[str, ...] | None = None,
    output_dir: str | Path = "outputs",
    max_age_seconds: float = 120.0,
) -> tuple[CryptoUniverseResult | None, str]:
    """
    Returns (result, mode) where mode is 'live_state' or 'rest_fallback'.
    """
    cfg = config or CryptoUniverseConfig()
    if getattr(broker, "config", None) and broker.config.dry_run and broker.config.access_key == "dry-run-key":
        return None, "rest_fallback"
    if not live_state_scan_enabled():
        return None, "rest_fallback"

    status = check_binance_live_state(output_dir, max_age_seconds=max_age_seconds)
    if not status.available or status.stale:
        return None, "rest_fallback"

    from deepsignal.crypto_trading.crypto_universe import get_upbit_krw_market_set

    valid_upbit = get_upbit_krw_market_set(broker, output_dir=output_dir)
    ticker_map = tickers_from_live_state(
        output_dir,
        max_markets=max(int(cfg.max_buy_scan_markets) * 3, 50),
        valid_upbit_markets=valid_upbit,
    )
    if not ticker_map:
        return None, "rest_fallback"

    hold = tuple(
        h.strip().upper()
        for h in (holdings_markets or ())
        if h and h.strip() and h.strip().upper() in valid_upbit
    )
    always = tuple(
        m
        for m in dict.fromkeys((*CORE_CRYPTO_MARKETS, *cfg.extra_markets, *hold))
        if m in valid_upbit
    )
    selected = select_markets_for_buy_scan(
        ticker_map,
        min_acc_trade_price_24h=float(cfg.min_acc_trade_price_24h),
        max_markets=int(cfg.max_buy_scan_markets),
        always_include=always,
    )
    display = {m: market_display_name(m) for m in selected}
    return (
        CryptoUniverseResult(
            markets=tuple(selected),
            universe="live_state",
            total_krw_markets=len(ticker_map),
            scanned_for_buy=len(selected),
            display_names=display,
            min_acc_trade_price_24h=float(cfg.min_acc_trade_price_24h),
        ),
        "live_state",
    )
