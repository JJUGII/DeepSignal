"""Upbit market snapshots — live or mock."""

from __future__ import annotations

from typing import Any

from deepsignal.crypto_trading.upbit_broker import UpbitTicker

DEFAULT_CRYPTO_MARKETS = ("KRW-BTC", "KRW-ETH", "KRW-XRP")

_MOCK_TICKERS: dict[str, dict[str, float]] = {
    "KRW-BTC": {"trade_price": 95_000_000.0, "signed_change_rate": 0.012, "acc_trade_price_24h": 800_000_000_000.0},
    "KRW-ETH": {"trade_price": 3_500_000.0, "signed_change_rate": 0.008, "acc_trade_price_24h": 200_000_000_000.0},
    "KRW-XRP": {"trade_price": 2_050.0, "signed_change_rate": 0.015, "acc_trade_price_24h": 50_000_000_000.0},
}


def _generate_mock_candles(
    *,
    base: float,
    n: int,
    drift: float,
    base_volume: float,
) -> list[dict[str, float]]:
    rows: list[dict[str, float]] = []
    price = base
    for i in range(n):
        step = drift if i % 2 == 0 else -drift * 0.85
        price = max(price * (1.0 + step), base * 0.5)
        high = price * 1.01
        low = price * 0.99
        rows.append(
            {
                "trade_price": price,
                "opening_price": price * 0.998,
                "high_price": high,
                "low_price": low,
                "candle_acc_trade_volume": base_volume * (0.9 + 0.02 * i),
            }
        )
    return rows


_MOCK_DAILY_CANDLES: dict[str, list[dict[str, float]]] = {
    "KRW-XRP": _generate_mock_candles(base=2000.0, n=30, drift=0.0005, base_volume=5e10),
    "KRW-BTC": _generate_mock_candles(base=94_000_000.0, n=30, drift=0.0005, base_volume=8e11),
    "KRW-ETH": _generate_mock_candles(base=3_400_000.0, n=30, drift=0.0005, base_volume=2e11),
}


def mock_daily_candles(market: str, count: int = 20) -> list[dict[str, float]]:
    m = market.upper()
    rows = list(_MOCK_DAILY_CANDLES.get(m, _generate_mock_candles(base=1000.0, n=20, drift=0.0, base_volume=1e9)))
    return rows[-count:]


def mock_ticker(market: str) -> UpbitTicker:
    m = market.upper()
    row = _MOCK_TICKERS.get(m, {"trade_price": 1_000.0, "signed_change_rate": 0.0, "acc_trade_price_24h": 0.0})
    candles = _MOCK_DAILY_CANDLES.get(m, [])
    acc = float(row["acc_trade_price_24h"])
    if candles:
        values = [
            float(c.get("candle_acc_trade_volume") or 0) * float(c.get("trade_price") or 0)
            for c in candles
            if float(c.get("candle_acc_trade_volume") or 0) > 0
        ]
        if values:
            acc = (sum(values) / len(values)) * 1.02
    return UpbitTicker(
        market=m,
        trade_price=row["trade_price"],
        signed_change_rate=row["signed_change_rate"],
        acc_trade_price_24h=acc,
    )


def mock_tickers(markets: tuple[str, ...] = DEFAULT_CRYPTO_MARKETS) -> dict[str, UpbitTicker]:
    return {m: mock_ticker(m) for m in markets}


def ticker_to_dict(t: UpbitTicker) -> dict[str, Any]:
    return {
        "market": t.market,
        "trade_price": t.trade_price,
        "signed_change_rate": t.signed_change_rate,
        "acc_trade_price_24h": t.acc_trade_price_24h,
    }
