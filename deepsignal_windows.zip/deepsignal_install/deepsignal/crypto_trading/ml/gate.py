"""LightGBM P(win) gate for crypto BUY recommendations."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import numpy as np

from deepsignal.market_data.feature_engine.spec import FEATURE_NAMES


def ml_buy_gate_enabled() -> bool:
    raw = (
        os.environ.get("CRYPTO_ML_BUY_GATE", "true")
        or os.environ.get("DEEPSIGNAL_CRYPTO_ML_BUY_GATE", "true")
    ).strip().lower()
    return raw not in ("0", "false", "no", "off")


def ml_buy_gate_strict() -> bool:
    """If true, block BUY when model file is missing."""
    raw = (
        os.environ.get("CRYPTO_ML_BUY_GATE_STRICT", "false")
        or os.environ.get("DEEPSIGNAL_CRYPTO_ML_BUY_GATE_STRICT", "false")
    ).strip().lower()
    return raw in ("1", "true", "yes", "on")


def default_buy_threshold() -> float:
    try:
        return float(os.environ.get("CRYPTO_ML_BUY_THRESHOLD", "0.55") or 0.55)
    except ValueError:
        return 0.55


def upbit_market_to_binance_symbol(market: str) -> str:
    m = str(market or "").strip().upper()
    if m.startswith("KRW-"):
        return f"{m.split('-', 1)[1]}USDT"
    if m.endswith("USDT"):
        return m
    return f"{m}USDT"


@dataclass
class MlGateResult:
    allowed: bool
    win_probability: float | None
    threshold: float
    model_path: str | None
    binance_symbol: str
    status: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "allowed": self.allowed,
            "win_probability": self.win_probability,
            "threshold": self.threshold,
            "model_path": self.model_path,
            "binance_symbol": self.binance_symbol,
            "status": self.status,
            "reason": self.reason,
        }


class CryptoMlBuyGate:
    """Load LightGBM once; predict P(win) from FeatureEngine + live_state."""

    def __init__(
        self,
        output_dir: str | Path = "outputs",
        *,
        horizon_minutes: int = 5,
        threshold: float | None = None,
    ) -> None:
        self.output_dir = Path(output_dir)
        self.horizon_minutes = int(horizon_minutes)
        self.threshold = float(threshold if threshold is not None else default_buy_threshold())
        self._model: Any = None
        self._model_path: Path | None = None
        self._engine: Any = None
        self._predict_fn: Callable[[str], float] | None = None

    def _resolve_model_path(self) -> Path | None:
        model_dir = self.output_dir / "models"
        active = model_dir / "crypto_scalp_lgbm_active.json"
        if active.is_file():
            try:
                meta = json.loads(active.read_text(encoding="utf-8"))
                rel = str(meta.get("model_path") or meta.get("deployed_model") or "")
                if rel:
                    p = Path(rel)
                    if not p.is_file():
                        p = model_dir / p.name
                    if p.is_file():
                        return p
            except (OSError, json.JSONDecodeError, TypeError):
                pass
        for name in (
            f"crypto_scalp_lgbm_{self.horizon_minutes}m.txt",
            "crypto_scalp_lgbm_5m.txt",
            "crypto_scalp_lgbm_10m.txt",
        ):
            p = model_dir / name
            if p.is_file():
                return p
        return None

    def _ensure_loaded(self) -> bool:
        if self._predict_fn is not None:
            return True
        path = self._resolve_model_path()
        if path is None:
            return False
        try:
            from deepsignal.market_data.feature_engine import FeatureEngine
            from deepsignal.ml.crypto_scalp_lgbm import load_lgbm_model, predict_proba

            self._model = load_lgbm_model(path)
            self._model_path = path
            live = self.output_dir / "binance_stream" / "live_state.json"
            self._engine = FeatureEngine()
            if live.is_file():
                self._engine.ingest_live_state(json.loads(live.read_text(encoding="utf-8")))

            model = self._model
            eng = self._engine

            def _pred(binance_sym: str) -> float:
                vec = eng.compute(binance_sym.upper())
                return float(predict_proba(model, np.asarray(vec).reshape(1, -1))[0])

            self._predict_fn = _pred
            return True
        except Exception:
            self._predict_fn = None
            self._model = None
            return False

    def refresh_live_state(self) -> None:
        """Reload binance live_state into FeatureEngine."""
        if self._engine is None:
            return
        live = self.output_dir / "binance_stream" / "live_state.json"
        if live.is_file():
            try:
                self._engine.ingest_live_state(json.loads(live.read_text(encoding="utf-8")))
            except (OSError, json.JSONDecodeError):
                pass

    def predict_for_upbit_market(self, market: str) -> MlGateResult:
        bsym = upbit_market_to_binance_symbol(market)
        if not ml_buy_gate_enabled():
            return MlGateResult(
                allowed=True,
                win_probability=None,
                threshold=self.threshold,
                model_path=None,
                binance_symbol=bsym,
                status="disabled",
                reason="CRYPTO_ML_BUY_GATE=off",
            )
        if not self._ensure_loaded():
            if ml_buy_gate_strict():
                return MlGateResult(
                    allowed=False,
                    win_probability=None,
                    threshold=self.threshold,
                    model_path=None,
                    binance_symbol=bsym,
                    status="no_model",
                    reason="LightGBM model missing (strict gate)",
                )
            return MlGateResult(
                allowed=True,
                win_probability=None,
                threshold=self.threshold,
                model_path=None,
                binance_symbol=bsym,
                status="skipped",
                reason="no model file — gate skipped",
            )
        try:
            p = float(self._predict_fn(bsym))  # type: ignore[misc]
        except Exception as exc:
            return MlGateResult(
                allowed=not ml_buy_gate_strict(),
                win_probability=None,
                threshold=self.threshold,
                model_path=str(self._model_path) if self._model_path else None,
                binance_symbol=bsym,
                status="error",
                reason=str(exc),
            )
        ok = p >= self.threshold
        return MlGateResult(
            allowed=ok,
            win_probability=p,
            threshold=self.threshold,
            model_path=str(self._model_path) if self._model_path else None,
            binance_symbol=bsym,
            status="pass" if ok else "below_threshold",
            reason=f"P(win)={p:.3f} {'≥' if ok else '<'} {self.threshold}",
        )

    def feature_snapshot_for_market(self, market: str) -> dict[str, float] | None:
        bsym = upbit_market_to_binance_symbol(market)
        if self._engine is None and not self._ensure_loaded():
            try:
                from deepsignal.market_data.feature_engine import FeatureEngine

                live = self.output_dir / "binance_stream" / "live_state.json"
                if not live.is_file():
                    return None
                eng = FeatureEngine()
                eng.ingest_live_state(json.loads(live.read_text(encoding="utf-8")))
                return eng.feature_dict(bsym)
            except Exception:
                return None
        if self._engine is None:
            return None
        try:
            return self._engine.feature_dict(bsym)
        except Exception:
            return None
