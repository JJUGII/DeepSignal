"""Upbit order fill polling and Telegram follow-up reports."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Literal

from deepsignal.crypto_trading.crypto_order_plan import CryptoOrderPlan
from deepsignal.crypto_trading.upbit_broker import UpbitBroker, UpbitOrderResult
from deepsignal.live_trading.time_utils import now_kst

CRYPTO_ORDER_STATUS_PREFIX = "crypto_order_status_"

FillOutcome = Literal["done", "partial", "wait", "cancel", "timeout", "skipped"]


def market_currency(market: str) -> str:
    parts = market.upper().split("-")
    return parts[-1] if parts else market


def normalize_order_status(raw: dict[str, Any]) -> dict[str, Any]:
    return {
        "uuid": str(raw.get("uuid", "")),
        "market": str(raw.get("market", "")),
        "state": str(raw.get("state", "")),
        "side": str(raw.get("side", "")),
        "price": float(raw.get("price", 0) or 0),
        "volume": float(raw.get("volume", 0) or 0),
        "executed_volume": float(raw.get("executed_volume", 0) or 0),
        "remaining_volume": float(raw.get("remaining_volume", 0) or 0),
        "paid_fee": float(raw.get("paid_fee", 0) or 0),
        "remaining_fee": float(raw.get("remaining_fee", 0) or 0),
        "trades_count": int(raw.get("trades_count", 0) or 0),
        "raw": raw,
    }


def is_partial_fill(status: dict[str, Any]) -> bool:
    executed = float(status.get("executed_volume", 0) or 0)
    remaining = float(status.get("remaining_volume", 0) or 0)
    state = str(status.get("state", ""))
    return executed > 0 and remaining > 0 and state not in ("done", "cancel")


def classify_fill_outcome(status: dict[str, Any], *, timed_out: bool) -> FillOutcome:
    state = str(status.get("state", ""))
    if state == "done":
        return "done"
    if state == "cancel":
        return "cancel"
    if is_partial_fill(status):
        return "partial"
    if timed_out:
        return "wait" if float(status.get("executed_volume", 0) or 0) <= 0 else "partial"
    return "wait"


def format_fill_message_done(plan: CryptoOrderPlan, status: dict[str, Any]) -> str:
    cur = market_currency(plan.market)
    order_krw = float(status.get("executed_volume", 0) or 0) * float(status.get("price", 0) or plan.limit_price)
    return "\n".join(
        [
            "[DeepSignal 코인 체결 완료]",
            plan.display_name,
            f"• 체결수량: {status.get('executed_volume')} {cur}",
            f"• 평균가격: {float(status.get('price', 0) or plan.limit_price):,.0f}원",
            f"• 주문금액: {order_krw:,.0f}원",
            f"• 수수료: {float(status.get('paid_fee', 0) or 0):,.4f}",
            f"• 주문번호: {status.get('uuid')}",
        ]
    )


def format_fill_message_wait(plan: CryptoOrderPlan, status: dict[str, Any]) -> str:
    cur = market_currency(plan.market)
    return "\n".join(
        [
            "[DeepSignal 코인 주문 대기]",
            plan.display_name,
            "• 아직 체결되지 않았습니다",
            f"• 남은수량: {status.get('remaining_volume')} {cur}",
            f"• 지정가: {float(status.get('price', 0) or plan.limit_price):,.0f}원",
            f"• 주문번호: {status.get('uuid')}",
        ]
    )


def format_fill_message_partial(plan: CryptoOrderPlan, status: dict[str, Any]) -> str:
    cur = market_currency(plan.market)
    return "\n".join(
        [
            "[DeepSignal 코인 부분 체결]",
            plan.display_name,
            f"• 체결수량: {status.get('executed_volume')} {cur}",
            f"• 남은수량: {status.get('remaining_volume')} {cur}",
            f"• 지정가: {float(status.get('price', 0) or plan.limit_price):,.0f}원",
            f"• 주문번호: {status.get('uuid')}",
        ]
    )


def format_fill_message_cancel(plan: CryptoOrderPlan, status: dict[str, Any]) -> str:
    return "\n".join(
        [
            "[DeepSignal 코인 주문 취소]",
            plan.display_name,
            "• 주문이 취소되었습니다",
            f"• 주문번호: {status.get('uuid')}",
        ]
    )


def format_fill_message_for_outcome(plan: CryptoOrderPlan, status: dict[str, Any], outcome: FillOutcome) -> str:
    if outcome == "done":
        return format_fill_message_done(plan, status)
    if outcome == "cancel":
        return format_fill_message_cancel(plan, status)
    if outcome == "partial":
        return format_fill_message_partial(plan, status)
    return format_fill_message_wait(plan, status)


def write_order_status_audit(output_dir: str | Path, payload: dict[str, Any]) -> Path:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    ts = now_kst().strftime("%Y%m%d_%H%M%S")
    path = out / f"{CRYPTO_ORDER_STATUS_PREFIX}{ts}.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path


def poll_order_fill(
    broker: UpbitBroker,
    uuid: str,
    *,
    wait_fill_seconds: float,
    fill_poll_interval: float,
) -> tuple[dict[str, Any], FillOutcome]:
    if not uuid or wait_fill_seconds <= 0:
        return {}, "skipped"

    deadline = time.time() + max(wait_fill_seconds, 0.0)
    last: dict[str, Any] = {}
    interval = max(fill_poll_interval, 0.5)

    while time.time() < deadline:
        raw = broker.get_order(uuid)
        last = normalize_order_status(raw)
        state = str(last.get("state", ""))
        if state == "done":
            return last, "done"
        if state == "cancel":
            return last, "cancel"
        if is_partial_fill(last):
            # keep polling until deadline unless terminal
            pass
        time.sleep(interval)

    outcome = classify_fill_outcome(last, timed_out=True)
    return last, outcome


def build_fill_audit(
    plan: CryptoOrderPlan,
    result: UpbitOrderResult,
    status: dict[str, Any],
    outcome: FillOutcome,
    *,
    output_dir: str | Path | None = None,
) -> dict[str, Any]:
    if output_dir and outcome in ("done", "partial") and float(status.get("price", 0) or 0) > 0:
        try:
            from deepsignal.crypto_trading.crypto_execution_quality import record_fill_slippage_feedback

            fill_px = float(status.get("price", 0) or plan.limit_price)
            order_krw = float(plan.krw_amount or 0) or fill_px * float(status.get("executed_volume", 0) or 0)
            record_fill_slippage_feedback(
                output_dir,
                market=plan.market,
                side=plan.side,
                limit_price=float(plan.limit_price or fill_px),
                fill_price=fill_px,
                order_krw=order_krw,
            )
        except Exception:
            pass
    return {
        "uuid": status.get("uuid") or result.uuid,
        "market": status.get("market") or plan.market,
        "state": status.get("state"),
        "executed_volume": status.get("executed_volume"),
        "remaining_volume": status.get("remaining_volume"),
        "paid_fee": status.get("paid_fee"),
        "trades_count": status.get("trades_count"),
        "fill_outcome": outcome,
        "plan": plan.to_dict(),
        "order_result": {
            "status": result.status,
            "uuid": result.uuid,
            "krw_amount": result.krw_amount,
            "price": result.price,
            "volume": result.volume,
        },
        "raw": status.get("raw"),
    }
