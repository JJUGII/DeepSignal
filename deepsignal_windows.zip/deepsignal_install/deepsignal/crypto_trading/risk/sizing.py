"""Dynamic crypto order size, daily limits, and fund-manager-aligned TP/SL."""

from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from deepsignal.crypto_trading.crypto_outcome_threshold_tuning import (
    CryptoTunedThresholds,
    load_active_crypto_thresholds,
)
from deepsignal.crypto_trading.crypto_quality import compute_atr_pct_from_candles
from deepsignal.crypto_trading.crypto_execution_quality import effective_min_order_krw
from deepsignal.crypto_trading.upbit_broker import MIN_ORDER_KRW, UpbitBroker
from deepsignal.scoring.analysis_conditions import DEFAULT_ANALYSIS_CONDITIONS

_CRYPTO = DEFAULT_ANALYSIS_CONDITIONS.crypto
ACTIVE_SIZING_JSON = "CRYPTO_ACTIVE_SIZING.json"
ATR_PROXY_MARKET = "KRW-BTC"


@dataclass
class CryptoRuntimeSizing:
    available_krw: float
    total_portfolio_krw: float
    max_order_krw: float
    max_orders_per_day: int
    take_profit_pct: float
    stop_loss_pct: float
    take_profit_buffer_pct: float
    stop_loss_buffer_pct: float
    min_volume_ratio: float
    macro_regime: str
    score_factor: float
    size_multiplier_hint: float = 1.0
    atr_pct: float | None = None
    tp_source: str = "fund_manager"
    order_source: str = "dynamic"
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def portfolio_totals(broker: UpbitBroker) -> tuple[float, float, float]:
    """total_krw, available_krw, holdings_valuation_krw."""
    try:
        available = float(broker.get_krw_available())
    except Exception:
        available = 0.0
    hold_val = 0.0
    try:
        hold_val = sum(float(h.valuation_krw or 0) for h in broker.get_crypto_holdings())
    except Exception:
        pass
    return available + hold_val, available, hold_val


def _score_factor(final_score: float | None) -> float:
    ref = float(_CRYPTO.score_reference)
    floor = float(_CRYPTO.score_factor_floor)
    if final_score is None or not math.isfinite(float(final_score)):
        return max(floor, 0.65)
    fs = float(final_score)
    if ref <= 0:
        return 1.0
    return _clamp(fs / ref, floor, 1.25)


def merge_tp_sl(
    tuned: CryptoTunedThresholds | None,
    atr_pct: float | None,
    *,
    min_sell_samples: int = 3,
) -> tuple[float, float, float, float, float, str]:
    """Crypto default TP/SL; outcomes and ATR adjust within configured band."""
    tp = float(_CRYPTO.take_profit_pct)
    sl = float(_CRYPTO.stop_loss_pct)
    tp_buf = float(_CRYPTO.take_profit_buffer_pct)
    sl_buf = float(_CRYPTO.stop_loss_buffer_pct)
    mvr = float(_CRYPTO.min_volume_ratio)
    source = "crypto_default"

    if tuned is not None:
        tp_buf = float(tuned.take_profit_buffer_pct)
        sl_buf = float(tuned.stop_loss_buffer_pct)
        mvr_cap = float(getattr(_CRYPTO, "outcome_tune_max_volume_ratio", 0.45))
        mvr = min(float(tuned.min_volume_ratio), mvr_cap)
        scalping = bool(getattr(_CRYPTO, "scalping_mode", True)) and not bool(_CRYPTO.prefer_fund_manager_tp_sl)
        apply_tuned_tp_sl = bool(getattr(_CRYPTO, "outcome_tune_apply_tp_sl", False))
        if scalping:
            source = "scalping_default"
            if apply_tuned_tp_sl and int(tuned.sample_sell_closed) >= min_sell_samples:
                tp = _clamp(
                    float(tuned.take_profit_pct),
                    float(_CRYPTO.tp_pct_min),
                    float(_CRYPTO.tp_pct_max),
                )
                sl = _clamp(
                    float(tuned.stop_loss_pct),
                    float(_CRYPTO.sl_pct_min),
                    float(_CRYPTO.sl_pct_max),
                )
                source = "outcomes"
        elif apply_tuned_tp_sl and int(tuned.sample_sell_closed) >= min_sell_samples:
            tp = _clamp(
                float(tuned.take_profit_pct),
                float(_CRYPTO.tp_pct_min),
                float(_CRYPTO.tp_pct_max),
            )
            sl = _clamp(
                float(tuned.stop_loss_pct),
                float(_CRYPTO.sl_pct_min),
                float(_CRYPTO.sl_pct_max),
            )
            source = "outcomes"
        elif not bool(_CRYPTO.prefer_fund_manager_tp_sl) and atr_pct and atr_pct > 0:
            tp_atr, sl_atr, _ = _tp_sl_from_atr(atr_pct)
            tp, sl = tp_atr, sl_atr
            source = "atr"

    return tp, sl, tp_buf, sl_buf, mvr, source


def tp_sl_from_atr(atr_pct: float) -> tuple[float, float, str]:
    """Public ATR-based TP/SL (clamped to fund-manager bands)."""
    return _tp_sl_from_atr(atr_pct)


def _tp_sl_from_atr(atr_pct: float) -> tuple[float, float, str]:
    tp = _clamp(
        float(atr_pct) * float(_CRYPTO.atr_tp_multiplier),
        float(_CRYPTO.tp_pct_min),
        float(_CRYPTO.tp_pct_max),
    )
    sl = -_clamp(
        float(atr_pct) * float(_CRYPTO.atr_sl_multiplier),
        abs(float(_CRYPTO.sl_pct_min)),
        abs(float(_CRYPTO.sl_pct_max)),
    )
    return round(tp, 3), round(sl, 3), "atr"


def compute_max_order_krw(
    available_krw: float,
    *,
    total_portfolio_krw: float | None = None,
    final_score: float | None = None,
    size_multiplier: float = 1.0,
    hard_cap_krw: float = 0.0,
) -> tuple[float, float, list[str]]:
    notes: list[str] = []
    avail = max(0.0, float(available_krw))
    total = max(avail, float(total_portfolio_krw or avail))
    policy_min = effective_min_order_krw()
    if avail < policy_min:
        notes.append(f"가용 KRW {avail:,.0f} < 최소주문 {policy_min:,.0f}")
        return 0.0, 0.0, notes

    sf = _score_factor(final_score)
    mult = _clamp(float(size_multiplier), 0.25, 1.0)
    pct = float(_CRYPTO.order_pct_of_available) * sf * mult
    raw = avail * pct
    cap_pct = avail * float(_CRYPTO.max_order_pct_of_available)
    cap_single = total * float(_CRYPTO.max_single_position_pct)
    cap_order_pct = total * float(_CRYPTO.max_single_order_pct_of_total)
    dyn_floor = max(policy_min, float(_CRYPTO.dynamic_cap_floor_krw))
    dyn_target = max(dyn_floor, total * float(_CRYPTO.dynamic_cap_target_pct_total) * sf * mult)
    dyn_ceil = max(dyn_floor, total * float(_CRYPTO.dynamic_cap_ceiling_pct_total))
    dyn_cap = _clamp(dyn_target, dyn_floor, dyn_ceil)
    static_cap = float(_CRYPTO.max_order_cap_krw)
    effective_cap = min(dyn_cap, static_cap) if static_cap > 0 else dyn_cap
    order_krw = min(raw, cap_pct, cap_single, cap_order_pct, effective_cap)
    if hard_cap_krw > 0:
        order_krw = min(order_krw, float(hard_cap_krw))
        notes.append(f"CLI 상한 {hard_cap_krw:,.0f}원 적용")
    order_krw = max(policy_min, math.floor(order_krw))
    if order_krw > avail:
        order_krw = max(policy_min, math.floor(avail * 0.95))
        notes.append("가용 잔고 대비 주문액 조정")
    notes.append(
        f"주문액 {order_krw:,.0f}원 (가용×{pct*100:.1f}%, 단일종목≤{cap_single:,.0f}=총자산×{float(_CRYPTO.max_single_position_pct)*100:.0f}%, score×{sf:.2f})"
    )
    notes.append(
        f"유동 상한 {effective_cap:,.0f}원 (target {dyn_target:,.0f}, floor {dyn_floor:,.0f}, ceil {dyn_ceil:,.0f})"
    )
    return order_krw, sf, notes


def compute_max_orders_per_day(
    available_krw: float,
    *,
    holdings_count: int = 0,
    macro_regime: str = "neutral",
    block_buy_risk_off: bool | None = None,
) -> tuple[int, list[str]]:
    notes: list[str] = []
    regime = str(macro_regime or "neutral").lower()
    block = bool(_CRYPTO.block_buy_on_risk_off) if block_buy_risk_off is None else block_buy_risk_off
    if block and regime in ("risk_off", "risk-off", "bear", "defensive"):
        notes.append(f"macro {regime} — BUY 일일 횟수 0 (SELL만)")
        return 0, notes

    avail = max(0.0, float(available_krw))
    slot = max(float(_CRYPTO.min_krw_per_order_slot), effective_min_order_krw())
    afford = max(0, int(avail // slot))
    hi = int(_CRYPTO.max_orders_per_day_max)
    lo = int(_CRYPTO.max_orders_per_day_min)
    n = _clamp(float(afford), float(lo), float(hi))
    if holdings_count >= int(_CRYPTO.max_buy_scan_markets):
        n = max(lo, n - 1)
        notes.append(f"보유 {holdings_count}종 — 일일 BUY 횟수 완화")
    n = int(n)
    notes.append(f"일일 BUY 최대 {n}회 (펀드형 슬롯 {slot:,.0f}원)")
    return n, notes


def _fetch_atr_proxy(broker: UpbitBroker, market: str = ATR_PROXY_MARKET) -> float | None:
    try:
        candles = broker.get_daily_candles(market, count=30)
        return compute_atr_pct_from_candles(candles)
    except Exception:
        return None


def resolve_crypto_runtime_sizing(
    broker: UpbitBroker,
    *,
    output_dir: str | Path,
    macro_regime: str = "neutral",
    final_score: float | None = None,
    size_multiplier: float = 1.0,
    hard_cap_order_krw: float = 0.0,
    hard_cap_orders_per_day: int = 0,
) -> CryptoRuntimeSizing:
    notes: list[str] = []
    total, available, hold_val = portfolio_totals(broker)
    if hold_val > 0:
        notes.append(f"총자산 {total:,.0f}원 (코인평가 {hold_val:,.0f})")

    tuned = load_active_crypto_thresholds(output_dir)
    atr_pct = _fetch_atr_proxy(broker)
    tp, sl, tp_buf, sl_buf, mvr, tp_src = merge_tp_sl(tuned, atr_pct)

    order_krw, sf, order_notes = compute_max_order_krw(
        available,
        total_portfolio_krw=total,
        final_score=final_score,
        size_multiplier=size_multiplier,
        hard_cap_krw=hard_cap_order_krw,
    )
    notes.extend(order_notes)

    max_day, day_notes = compute_max_orders_per_day(
        available,
        holdings_count=len(broker.get_crypto_holdings()),
        macro_regime=macro_regime,
    )
    notes.extend(day_notes)
    if hard_cap_orders_per_day > 0:
        max_day = min(max_day, int(hard_cap_orders_per_day)) if max_day > 0 else 0
        notes.append(f"CLI 일일 횟수 상한 {hard_cap_orders_per_day}")

    return CryptoRuntimeSizing(
        available_krw=available,
        total_portfolio_krw=total,
        max_order_krw=order_krw,
        max_orders_per_day=max_day,
        take_profit_pct=tp,
        stop_loss_pct=sl,
        take_profit_buffer_pct=tp_buf,
        stop_loss_buffer_pct=sl_buf,
        min_volume_ratio=mvr,
        macro_regime=str(macro_regime),
        score_factor=sf,
        size_multiplier_hint=float(size_multiplier),
        atr_pct=atr_pct,
        tp_source=tp_src,
        order_source="dynamic" if hard_cap_order_krw <= 0 else "dynamic_capped",
        notes=notes,
    )


def apply_runtime_sizing_to_runner(cfg: Any, sizing: CryptoRuntimeSizing) -> None:
    if float(sizing.max_order_krw) > 0:
        cfg.max_order_value = float(sizing.max_order_krw)
    cfg.max_orders_per_day = int(sizing.max_orders_per_day)
    cfg.take_profit_pct = float(sizing.take_profit_pct)
    cfg.stop_loss_pct = float(sizing.stop_loss_pct)
    cfg.take_profit_buffer_pct = float(sizing.take_profit_buffer_pct)
    cfg.stop_loss_buffer_pct = float(sizing.stop_loss_buffer_pct)
    cfg.min_volume_ratio = float(sizing.min_volume_ratio)


def save_active_sizing_snapshot(output_dir: str | Path, sizing: CryptoRuntimeSizing) -> Path:
    path = Path(output_dir) / ACTIVE_SIZING_JSON
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(sizing.to_dict(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path
