"""
crypto_ws_runner.py — WebSocket 이벤트 드리븐 + 4-스레드 단타 엔진.

구조:
  Thread 1 (ws)        : Upbit WebSocket 실시간 가격 수신 → SELL 임계값 체크 → 큐 적재
  Thread 2 (analysis)  : 주기적 분석 (60s+), BUY 시그널 생성, Telegram 메뉴 폴
  Thread 3 (execution) : signal_queue 소비 → 즉시 주문 실행
  Thread 4 (order_mgmt): 10초 주기 미체결 매도 추적·재접수 / 미체결 매수 취소

분석이 실행을 블로킹하지 않고, 가격 이벤트(TP/SL)는 WebSocket 수신
즉시 처리된다.
"""
from __future__ import annotations

import asyncio
import json
import logging
import queue
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from deepsignal.crypto_trading.runner.auto_runner import (
    CryptoAutoRunnerConfig,
    _persist_trade_state,
    _today_key,
    load_runner_state,
    save_runner_state,
)
from deepsignal.crypto_trading.upbit_broker import CryptoHolding, UpbitBroker
from deepsignal.live_trading.time_utils import now_kst_iso

logger = logging.getLogger(__name__)

# ────────────────────────────────────────────
# 공유 데이터 구조
# ────────────────────────────────────────────

@dataclass
class SellThreshold:
    """단일 보유 코인의 실시간 매도 임계값."""
    market: str
    avg_buy_price: float
    take_profit_price: float    # avg × (1 + tp%)
    stop_loss_price: float      # avg × (1 + sl%)  ← sl%는 음수
    trailing_stop_pct: float    # 고점 대비 X% 하락 시 청산
    volume: float               # 보유 수량 (total_quantity)
    peak_price: float = 0.0
    triggered: bool = False     # 중복 시그널 방지

    def check(self, price: float) -> str | None:
        if self.triggered:
            return None
        if price >= self.take_profit_price:
            return "take_profit"
        if price <= self.stop_loss_price:
            return "stop_loss"
        if self.peak_price > 0 and price < self.peak_price * (1.0 - self.trailing_stop_pct / 100.0):
            return "trailing_stop"
        return None

    def update_peak(self, price: float) -> None:
        if price > self.peak_price:
            self.peak_price = price


@dataclass
class PriceSignal:
    """WebSocket 스레드가 execution 스레드로 전달하는 시그널."""
    signal_type: str        # "sell" | "buy"
    market: str
    trigger_price: float
    reason: str
    plan: Any = None        # CryptoOrderPlan (buy 시그널 전용)
    volume: float = 0.0     # sell 시그널 전용


class SharedRunnerState:
    """4개 스레드가 공유하는 상태. 내부 Lock으로 thread-safe."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.price_cache: dict[str, float] = {}
        self.sell_thresholds: dict[str, SellThreshold] = {}
        self._markets_to_watch: set[str] = set()
        self.signal_queue: queue.Queue[PriceSignal] = queue.Queue()
        self.stop_event = threading.Event()
        self._markets_version: int = 0  # 변경 시 ws 재연결 트리거

    # ── 가격 캐시 + 임계값 체크 (ws 스레드 호출) ──

    def on_price(self, market: str, price: float) -> None:
        with self._lock:
            self.price_cache[market] = price
            thresh = self.sell_thresholds.get(market)
            if thresh is None:
                return
            thresh.update_peak(price)
            reason = thresh.check(price)
            if reason is None:
                return
            thresh.triggered = True
            sig = PriceSignal(
                signal_type="sell",
                market=market,
                trigger_price=price,
                reason=reason,
                volume=thresh.volume,
            )
        # Lock 해제 후 큐에 추가
        self.signal_queue.put(sig)
        logger.info("ws→exec: %s %s @ %.2f", market, reason, price)

    # ── 임계값 갱신 (analysis 스레드 호출) ──

    def update_sell_thresholds(self, thresholds: dict[str, SellThreshold]) -> None:
        with self._lock:
            for market, new_t in thresholds.items():
                old = self.sell_thresholds.get(market)
                if old:
                    new_t.peak_price = max(old.peak_price, new_t.peak_price)
                    if old.triggered and old.avg_buy_price == new_t.avg_buy_price:
                        new_t.triggered = True  # 아직 청산 안 된 경우 유지
            self.sell_thresholds = thresholds

    def clear_sell_threshold(self, market: str) -> None:
        with self._lock:
            self.sell_thresholds.pop(market, None)

    # ── 마켓 구독 목록 (ws 스레드가 읽음, analysis 스레드가 씀) ──

    def update_markets(self, markets: set[str]) -> None:
        with self._lock:
            if markets != self._markets_to_watch:
                self._markets_to_watch = set(markets)
                self._markets_version += 1

    def get_markets(self) -> list[str]:
        with self._lock:
            return sorted(self._markets_to_watch)

    def get_markets_version(self) -> int:
        with self._lock:
            return self._markets_version

    # ── BUY 시그널 적재 (analysis 스레드) ──

    def push_buy_signal(self, plan: Any, price: float) -> None:
        sig = PriceSignal(
            signal_type="buy",
            market=plan.market,
            trigger_price=price,
            reason="analysis_buy",
            plan=plan,
        )
        self.signal_queue.put(sig)


# ────────────────────────────────────────────
# Thread 1: WebSocket
# ────────────────────────────────────────────

def _ws_thread_main(shared: SharedRunnerState) -> None:
    """Upbit WebSocket 수신 루프. asyncio 이벤트 루프를 이 스레드에서 운영."""
    from deepsignal.crypto_trading.crypto_ws_price_stream import stream_upbit_prices

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    async def _run() -> None:
        stop = asyncio.Event()

        def _check_stop() -> None:
            if shared.stop_event.is_set():
                stop.set()

        # 1초 주기로 파이썬 threading stop_event 확인
        async def _watch_stop() -> None:
            while not stop.is_set():
                _check_stop()
                await asyncio.sleep(1.0)

        async def _on_price(market: str, price: float) -> None:
            shared.on_price(market, price)

        watcher = loop.create_task(_watch_stop())
        try:
            await stream_upbit_prices(
                shared.get_markets,
                _on_price,
                stop,
            )
        finally:
            watcher.cancel()

    try:
        loop.run_until_complete(_run())
    finally:
        loop.close()
    logger.info("ws thread: 종료")


# ────────────────────────────────────────────
# Thread 2: Analysis
# ────────────────────────────────────────────

def _build_sell_thresholds(
    broker: UpbitBroker,
    cfg: CryptoAutoRunnerConfig,
    runner_state: dict[str, Any],
) -> dict[str, SellThreshold]:
    """현재 보유 코인에서 SELL 임계값 계산."""
    from deepsignal.crypto_trading.crypto_execution_engine import load_execution_positions

    thresholds: dict[str, SellThreshold] = {}
    try:
        holdings: list[CryptoHolding] = broker.get_crypto_holdings()
    except Exception as exc:
        logger.warning("analysis: holdings 조회 실패: %s", exc)
        return thresholds

    positions = load_execution_positions(runner_state)

    for h in holdings:
        market = h.market.upper()
        avg = float(h.avg_buy_price or 0)
        if avg <= 0:
            continue
        tp_pct = float(cfg.take_profit_pct)
        sl_pct = float(cfg.stop_loss_pct)        # 음수 값 (예: -2.0)
        trail_pct = 0.8  # ExecutionEngineConfig.trailing_stop_pct 기본값

        pos = positions.get(market)
        peak = float(pos.peak_price if pos else 0)
        cur = float(h.current_price or avg)
        peak = max(peak, cur)

        thresholds[market] = SellThreshold(
            market=market,
            avg_buy_price=avg,
            take_profit_price=avg * (1.0 + tp_pct / 100.0),
            stop_loss_price=avg * (1.0 + sl_pct / 100.0),
            trailing_stop_pct=trail_pct,
            volume=float(h.total_quantity),
            peak_price=peak,
        )
    return thresholds


def _universe_markets(broker: UpbitBroker, cfg: CryptoAutoRunnerConfig) -> set[str]:
    """구독 대상 마켓 = universe 상위 N종목 (WebSocket 사전 구독용)."""
    from deepsignal.crypto_trading.crypto_universe import CryptoUniverseConfig, resolve_crypto_markets

    try:
        uni_cfg = CryptoUniverseConfig(
            universe=str(cfg.crypto_universe),
            max_buy_scan_markets=int(cfg.max_buy_scan_markets),
        )
        result = resolve_crypto_markets(broker, config=uni_cfg)
        return {m.upper() for m in result.markets if m.startswith("KRW-")}
    except Exception as exc:
        logger.warning("analysis: universe 조회 실패: %s", exc)
        return set()


def _analysis_thread_main(
    broker: UpbitBroker,
    shared: SharedRunnerState,
    cfg: CryptoAutoRunnerConfig,
    *,
    execute: bool,
) -> None:
    """주기적 분석 스레드. BUY 추천 생성 + SELL 임계값 갱신 + Telegram 메뉴 폴."""
    from deepsignal.crypto_trading.runner.auto_runner import (
        run_crypto_auto_tick,
        poll_telegram_menu_fast,
        _today_key,
    )
    from deepsignal.crypto_trading.crypto_auto_execute_policy import should_auto_execute_crypto_on_runner_tick

    interval_sec = max(cfg.interval_minutes * 60.0, 60.0)
    menu_sleep = max(float(cfg.menu_poll_seconds), 1.0)
    last_analysis_at = 0.0

    while not shared.stop_event.is_set():
        state = load_runner_state(cfg.output_dir)

        # 임계값 + 구독 마켓 갱신
        thresholds = _build_sell_thresholds(broker, cfg, state)
        shared.update_sell_thresholds(thresholds)

        holding_markets = set(thresholds.keys())
        universe = _universe_markets(broker, cfg)
        shared.update_markets(holding_markets | universe)

        # Telegram 메뉴 폴 (빠른 주기)
        try:
            poll_telegram_menu_fast(broker, cfg, state=state)
            save_runner_state(cfg.output_dir, state)
        except Exception as exc:
            logger.warning("analysis: menu poll error: %s", exc)

        # 분석 틱 (interval_sec 마다)
        now = time.time()
        if now - last_analysis_at >= interval_sec:
            logger.info("analysis: 분석 틱 시작")
            try:
                tick = run_crypto_auto_tick(broker, cfg)
                action = tick.get("action", "")
                print(json.dumps({"analysis_tick": tick}, ensure_ascii=False))

                # BUY 추천이 나왔고 자동실행 모드면 execution 큐에 적재
                if action in ("auto_executed_no_approval", "approved"):
                    # 이미 run_crypto_auto_tick 내부에서 실행 완료
                    pass
                elif action == "approval_sent" and should_auto_execute_crypto_on_runner_tick():
                    plan_json = tick.get("plan_json")
                    if plan_json:
                        try:
                            from deepsignal.crypto_trading.crypto_order_plan import load_crypto_plan
                            plan = load_crypto_plan(plan_json)
                            if plan.side.lower() == "buy":
                                try:
                                    tickers = broker.get_tickers([plan.market])
                                    cur_price = float(tickers[plan.market].trade_price) if plan.market in tickers else 0.0
                                except Exception:
                                    cur_price = float(plan.limit_price or 0)
                                shared.push_buy_signal(plan, cur_price)
                        except Exception as exc:
                            logger.warning("analysis: buy signal push 실패: %s", exc)

            except Exception as exc:
                logger.error("analysis: tick error: %s", exc, exc_info=True)
            last_analysis_at = now

        shared.stop_event.wait(timeout=menu_sleep)

    logger.info("analysis thread: 종료")


# ────────────────────────────────────────────
# Thread 3: Execution
# ────────────────────────────────────────────

def _execute_sell_signal(
    broker: UpbitBroker,
    sig: PriceSignal,
    shared: SharedRunnerState,
    cfg: CryptoAutoRunnerConfig,
    *,
    execute: bool,
) -> None:
    """SELL 시그널 실행 (WebSocket 트리거)."""
    from deepsignal.crypto_trading.crypto_order_plan import CryptoOrderPlan
    from deepsignal.crypto_trading.crypto_execution_engine import CryptoExecutionEngine, ExecutionEngineConfig
    from deepsignal.crypto_trading.crypto_sell_pricing import round_crypto_limit_price

    market = sig.market
    price = sig.trigger_price
    logger.info("exec: SELL %s reason=%s price=%.2f", market, sig.reason, price)

    try:
        holdings = broker.get_crypto_holdings()
        holding = next((h for h in holdings if h.market.upper() == market), None)
        if holding is None:
            logger.warning("exec: %s 보유 없음, SELL 스킵", market)
            shared.clear_sell_threshold(market)
            return

        vol = float(holding.total_quantity)
        if vol <= 0:
            shared.clear_sell_threshold(market)
            return

        limit_px = round_crypto_limit_price(price)
        eng_cfg = ExecutionEngineConfig(
            take_profit_pct=cfg.take_profit_pct,
            stop_loss_pct=cfg.stop_loss_pct,
        )
        plan = CryptoOrderPlan(
            market=market,
            side="sell",
            limit_price=limit_px,
            volume=vol,
            krw_amount=vol * limit_px,
            take_profit_pct=cfg.take_profit_pct,
            stop_loss_pct=cfg.stop_loss_pct,
        )
        eng = CryptoExecutionEngine(broker, cfg=eng_cfg, output_dir=cfg.output_dir)
        order = eng.execute_sell(plan, execute=execute)

        state = load_runner_state(cfg.output_dir)
        state["last_order_date"] = _today_key()
        state["orders_today"] = int(state.get("orders_today", 0) or 0) + 1
        save_runner_state(cfg.output_dir, state)

        print(json.dumps({
            "ws_sell": {
                "market": market,
                "reason": sig.reason,
                "trigger_price": price,
                "limit_price": limit_px,
                "volume": vol,
                "order_status": order.status,
                "order_uuid": order.uuid,
                "execute": execute,
                "ts": now_kst_iso(),
            }
        }, ensure_ascii=False))

        shared.clear_sell_threshold(market)

    except Exception as exc:
        logger.error("exec: SELL 실패 %s: %s", market, exc, exc_info=True)


def _execute_buy_signal(
    broker: UpbitBroker,
    sig: PriceSignal,
    shared: SharedRunnerState,
    cfg: CryptoAutoRunnerConfig,
    *,
    execute: bool,
) -> None:
    """BUY 시그널 실행 (analysis 스레드 추천)."""
    from deepsignal.crypto_trading.crypto_execution_engine import CryptoExecutionEngine, ExecutionEngineConfig

    plan = sig.plan
    if plan is None:
        return
    logger.info("exec: BUY %s @ ~%.2f", sig.market, sig.trigger_price)

    try:
        eng_cfg = ExecutionEngineConfig(
            take_profit_pct=cfg.take_profit_pct,
            stop_loss_pct=cfg.stop_loss_pct,
        )
        eng = CryptoExecutionEngine(broker, cfg=eng_cfg, output_dir=cfg.output_dir)
        state = load_runner_state(cfg.output_dir)
        result = eng.execute_buy(plan, execute=execute, runner_state=state)

        if result.success:
            state["last_order_date"] = _today_key()
            state["orders_today"] = int(state.get("orders_today", 0) or 0) + 1
            _persist_trade_state(cfg.output_dir, plan)

        save_runner_state(cfg.output_dir, state)
        print(json.dumps({
            "ws_buy": {
                "market": sig.market,
                "success": result.success,
                "limit_price": result.limit_price,
                "krw_amount": result.krw_amount,
                "win_probability": result.win_probability,
                "reasons": result.reasons,
                "execute": execute,
                "ts": now_kst_iso(),
            }
        }, ensure_ascii=False))

    except Exception as exc:
        logger.error("exec: BUY 실패 %s: %s", sig.market, exc, exc_info=True)


def _execution_thread_main(
    broker: UpbitBroker,
    shared: SharedRunnerState,
    cfg: CryptoAutoRunnerConfig,
    *,
    execute: bool,
) -> None:
    """signal_queue 소비 스레드. SELL/BUY 즉시 처리."""
    while not shared.stop_event.is_set():
        try:
            sig = shared.signal_queue.get(timeout=1.0)
        except queue.Empty:
            continue

        try:
            if sig.signal_type == "sell":
                _execute_sell_signal(broker, sig, shared, cfg, execute=execute)
            elif sig.signal_type == "buy":
                _execute_buy_signal(broker, sig, shared, cfg, execute=execute)
        finally:
            shared.signal_queue.task_done()

    logger.info("execution thread: 종료")


# ────────────────────────────────────────────
# Thread 4: Order Management
# ────────────────────────────────────────────

def _order_mgmt_thread_main(
    broker: UpbitBroker,
    shared: SharedRunnerState,
    cfg: CryptoAutoRunnerConfig,
    *,
    execute: bool,
    interval: float = 10.0,
) -> None:
    """미체결 주문 관리 (10초 주기): 매도 재접수 + 매수 취소."""
    from deepsignal.crypto_trading.crypto_order_manager import (
        manage_open_buy_orders,
        manage_open_sell_orders,
    )

    while not shared.stop_event.is_set():
        try:
            sell_actions = manage_open_sell_orders(broker, cfg.output_dir, execute=execute)
            if sell_actions:
                print(json.dumps({"order_manager": sell_actions}, ensure_ascii=False))
        except Exception as exc:
            logger.warning("order_mgmt(sell): 오류: %s", exc)

        try:
            buy_actions = manage_open_buy_orders(broker, cfg.output_dir, execute=execute)
            if buy_actions:
                print(json.dumps({"order_manager_buy": buy_actions}, ensure_ascii=False))
        except Exception as exc:
            logger.warning("order_mgmt(buy): 오류: %s", exc)

        shared.stop_event.wait(timeout=interval)

    logger.info("order_mgmt thread: 종료")


# ────────────────────────────────────────────
# 진입점
# ────────────────────────────────────────────

def run_crypto_ws_runner_loop(
    broker: UpbitBroker,
    cfg: CryptoAutoRunnerConfig,
    *,
    execute: bool = False,
) -> None:
    """
    WebSocket + 4-Thread 단타 엔진 메인 루프.

    Ctrl-C(KeyboardInterrupt) 또는 SIGTERM으로 모든 스레드 정상 종료.
    """
    from deepsignal.crypto_trading.crypto_env import emit_crypto_runner_startup_log, ensure_crypto_runtime_env

    env_result = ensure_crypto_runtime_env()
    emit_crypto_runner_startup_log(execute=execute, env_result=env_result)
    logger.info("ws-runner: 시작 (execute=%s)", execute)

    shared = SharedRunnerState()

    threads = [
        threading.Thread(
            target=_ws_thread_main,
            args=(shared,),
            name="ws-price-stream",
            daemon=True,
        ),
        threading.Thread(
            target=_analysis_thread_main,
            args=(broker, shared, cfg),
            kwargs={"execute": execute},
            name="analysis",
            daemon=True,
        ),
        threading.Thread(
            target=_execution_thread_main,
            args=(broker, shared, cfg),
            kwargs={"execute": execute},
            name="execution",
            daemon=True,
        ),
        threading.Thread(
            target=_order_mgmt_thread_main,
            args=(broker, shared, cfg),
            kwargs={"execute": execute},
            name="order-mgmt",
            daemon=True,
        ),
    ]

    for t in threads:
        t.start()
        logger.info("ws-runner: 스레드 시작 → %s", t.name)

    try:
        while True:
            alive = [t for t in threads if t.is_alive()]
            if not alive:
                logger.error("ws-runner: 모든 스레드 종료됨, 루프 탈출")
                break
            time.sleep(5.0)
    except KeyboardInterrupt:
        logger.info("ws-runner: KeyboardInterrupt → 종료 중...")
    finally:
        shared.stop_event.set()
        for t in threads:
            t.join(timeout=10.0)
        logger.info("ws-runner: 완전 종료")
