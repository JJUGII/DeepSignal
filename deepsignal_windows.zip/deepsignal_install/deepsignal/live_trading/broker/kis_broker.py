"""한국투자증권 KIS Open API 브로커 어댑터 (OAuth·국내 현금 LIMIT BUY·[실전-4] 선택 실주문)."""

from __future__ import annotations

import json
import re
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Mapping

import requests

from deepsignal.live_trading.broker_interface import (
    BrokerCashBalance,
    BrokerInterface,
    BrokerOrderRequest,
    BrokerOrderResult,
    BrokerOrderStatus,
    BrokerPosition,
)
from deepsignal.live_trading.kis_config import KISConfig
from deepsignal.live_trading.kis_token_cache import (
    get_default_token_cache_path,
    load_cached_token,
    save_cached_token,
)


class BrokerError(ValueError):
    """주문·페이로드 관련 오류."""


def post_kis_order_cash_request(
    session: requests.Session,
    base_url: str,
    *,
    headers: dict[str, str],
    body: dict[str, Any],
) -> requests.Response:
    """
    국내주식 **현금주문** API HTTP POST.

    경로·TR 분기: KIS Developers / `koreainvestment/open-trading-api` 국내주식 현금주문
    (`/uapi/domestic-stock/v1/trading/order-cash`). 실전·모의는 `KISConfig.env`·`tr_id`로 구분한다.
    """
    url = f"{base_url.rstrip('/')}/uapi/domestic-stock/v1/trading/order-cash"
    merged = {"content-type": "application/json; charset=utf-8"}
    merged.update(headers)
    return session.post(url, headers=merged, data=json.dumps(body), timeout=60)


def kis_get_request(
    session: requests.Session,
    base_url: str,
    path: str,
    *,
    headers: dict[str, str],
    params: dict[str, Any],
) -> requests.Response:
    """KIS Open API GET (조회 전용). 경로는 공식 domestic-stock v1."""
    url = f"{base_url.rstrip('/')}{path}"
    merged = {"content-type": "application/json; charset=utf-8"}
    merged.update(headers)
    return session.get(url, headers=merged, params=params, timeout=60)


class KISBroker(BrokerInterface):
    """KIS OAuth·주문. `safe_mode=True` 또는 `execute=False` 이면 주문 POST 금지(가드 외부에서 `execute` 제어)."""

    def __init__(
        self,
        config: KISConfig,
        *,
        safe_mode: bool = True,
        session: requests.Session | None = None,
        token_cache_path: str | Path | None = None,
    ) -> None:
        self._config = config
        self._safe_mode = bool(safe_mode)
        self._session = session if session is not None else requests.Session()
        self._token_cache_path = Path(token_cache_path) if token_cache_path is not None else get_default_token_cache_path()
        self._access_token: str | None = None
        self._access_token_expires_at: float = 0.0
        self._last_balance_response_body: dict[str, Any] | None = None

    @property
    def config(self) -> KISConfig:
        return self._config

    @property
    def safe_mode(self) -> bool:
        return self._safe_mode

    @property
    def last_balance_response_body(self) -> dict[str, Any] | None:
        return self._last_balance_response_body

    def connect(self) -> None:
        self.get_access_token()

    def submit_order(self, order: Mapping[str, Any]) -> Mapping[str, Any]:
        return {
            "status": "KIS_LEGACY_SUBMIT_NOT_USED",
            "message": "Use place_order(BrokerOrderRequest).",
            "order": dict(order),
        }

    def get_positions(self) -> list[BrokerPosition]:
        """국내주식 잔고조회 (`/uapi/domestic-stock/v1/trading/inquire-balance`). TR: 실전 TTTC8434R / 모의 VTTC8434R."""
        tr = "VTTC8434R" if not self._config.is_live else "TTTC8434R"
        cano = self._config.account_no.strip()
        acnt = self._config.account_product_code.strip()
        params: dict[str, Any] = {
            "CANO": cano,
            "ACNT_PRDT_CD": acnt,
            "AFHR_FLPR_YN": "N",
            "OFL_YN": "N",
            "INQR_DVSN": "02",
            "UNPR_DVSN": "01",
            "FUND_STTL_ICLD_YN": "N",
            "FNCG_AMT_AUTO_RDPT_YN": "N",
            "PRCS_DVSN": "01",
            "CTX_AREA_FK100": "",
            "CTX_AREA_NK100": "",
        }
        hdr = self._inquire_headers(tr)
        path = "/uapi/domestic-stock/v1/trading/inquire-balance"
        resp = kis_get_request(self._session, self._config.base_url, path, headers=hdr, params=params)
        raw: dict[str, Any] = {"http_status": resp.status_code, "tr_id": tr, "endpoint": path}
        try:
            body = resp.json()
        except json.JSONDecodeError:
            body = {"_non_json_body": resp.text}
        self._last_balance_response_body = body if isinstance(body, dict) else {"_non_json_body": str(body)}
        raw["response_body"] = body
        if not isinstance(body, dict):
            return []
        out1 = body.get("output1") or body.get("Output1")
        rows: list[Any]
        if isinstance(out1, list):
            rows = out1
        elif isinstance(out1, dict):
            rows = [out1]
        else:
            rows = []
        positions: list[BrokerPosition] = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            sym = self._pick_str(row, ("pdno", "PDNO"))
            if not sym or not re.fullmatch(r"\d{6}", str(sym).strip()):
                continue
            qty = self._pick_int(row, ("hldg_qty", "HLDG_QTY", "hltg_qty"))
            if qty is None:
                qty = self._pick_int(row, ("ord_psbl_qty", "ORD_PSBL_QTY"))
            if qty is None or int(qty) <= 0:
                continue
            if not sym:
                continue
            positions.append(
                BrokerPosition(
                    symbol=str(sym).zfill(6) if str(sym).isdigit() else str(sym),
                    quantity=int(qty or 0),
                    avg_price=self._pick_float(row, ("pchs_avg_pric", "PCHS_AVG_PRIC", "avg_prc")),
                    current_price=self._pick_float(row, ("prpr", "PRPR", "stck_prpr")),
                    market_value=self._pick_float(row, ("evlu_amt", "EVLU_AMT", "evlu_pfls_amt")),
                    raw=dict(row),
                )
            )
        return positions

    def get_cash_balance(self) -> BrokerCashBalance:
        """잔고조회 응답 `output2`에서 현금 요약 (필드명은 버전별 상이할 수 있음)."""
        tr = "VTTC8434R" if not self._config.is_live else "TTTC8434R"
        cano = self._config.account_no.strip()
        acnt = self._config.account_product_code.strip()
        params: dict[str, Any] = {
            "CANO": cano,
            "ACNT_PRDT_CD": acnt,
            "AFHR_FLPR_YN": "N",
            "OFL_YN": "N",
            "INQR_DVSN": "02",
            "UNPR_DVSN": "01",
            "FUND_STTL_ICLD_YN": "N",
            "FNCG_AMT_AUTO_RDPT_YN": "N",
            "PRCS_DVSN": "01",
            "CTX_AREA_FK100": "",
            "CTX_AREA_NK100": "",
        }
        hdr = self._inquire_headers(tr)
        path = "/uapi/domestic-stock/v1/trading/inquire-balance"
        resp = kis_get_request(self._session, self._config.base_url, path, headers=hdr, params=params)
        raw: dict[str, Any] = {"http_status": resp.status_code, "tr_id": tr}
        try:
            body = resp.json()
        except json.JSONDecodeError:
            body = {"_non_json_body": resp.text}
        self._last_balance_response_body = body if isinstance(body, dict) else {"_non_json_body": str(body)}
        raw["response_body"] = body
        if isinstance(body, dict) and str(body.get("rt_cd", "")).strip() != "0":
            raw["kis_warning"] = str(body.get("msg1") or body.get("msg_cd") or "rt_cd not 0")
        out2 = body.get("output2") if isinstance(body, dict) else None
        row: dict[str, Any] = out2[0] if isinstance(out2, list) and out2 and isinstance(out2[0], dict) else (
            out2 if isinstance(out2, dict) else {}
        )
        cash = self._pick_float(row, ("dnca_tot_amt", "DNCa_TOT_AMT", "tot_crdl_loan_amt", "nass_amt"))
        wdr = self._pick_float(row, ("ord_psbl_cash", "ORD_PSBL_CASH", "nxdy_excc_amt"))
        return BrokerCashBalance(
            cash=cash,
            withdrawable_cash=wdr if wdr is not None else cash,
            raw=raw,
        )

    def get_order_status(
        self,
        *,
        order_id: str | None = None,
        symbol: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> list[BrokerOrderStatus]:
        """
        국내주식 일별주문체결조회 (`/uapi/domestic-stock/v1/trading/inquire-daily-ccld`).
        TR: 실전 TTTC0081R / 모의 VTTC0081R. `order_id` 있으면 응답 행에서 해당 ODNO 우선 매칭.
        """
        tr = "VTTC0081R" if not self._config.is_live else "TTTC0081R"
        cano = self._config.account_no.strip()
        acnt = self._config.account_product_code.strip()
        if not start_date or not end_date:
            from datetime import date

            d = date.today().strftime("%Y%m%d")
            start_date = start_date or d
            end_date = end_date or d
        pdno = (symbol or "").strip()
        params: dict[str, Any] = {
            "CANO": cano,
            "ACNT_PRDT_CD": acnt,
            "INQR_STRT_DT": start_date,
            "INQR_END_DT": end_date,
            "SLL_BUY_DVSN_CD": "00",
            "INQR_DVSN": "00",
            "PDNO": pdno,
            "ORD_DVSN": "00",
            "CCLD_DVSN": "00",
            "INQR_DVSN_1": "",
            "INQR_DVSN_3": "",
            "EXC_CBL_CLS": "",
            "CTX_AREA_FK100": "",
            "CTX_AREA_NK100": "",
        }
        if order_id:
            params["ODNO"] = str(order_id).strip()
        hdr = self._inquire_headers(tr)
        path = "/uapi/domestic-stock/v1/trading/inquire-daily-ccld"
        resp = kis_get_request(self._session, self._config.base_url, path, headers=hdr, params=params)
        raw_base: dict[str, Any] = {"http_status": resp.status_code, "tr_id": tr, "endpoint": path}
        try:
            body = resp.json()
        except json.JSONDecodeError:
            body = {"_non_json_body": resp.text}
        raw_base["response_body"] = body
        if not isinstance(body, dict):
            return [
                BrokerOrderStatus(
                    order_id=order_id,
                    symbol=pdno or "",
                    side=None,
                    quantity=None,
                    filled_quantity=None,
                    remaining_quantity=None,
                    order_price=None,
                    avg_fill_price=None,
                    status="KIS_PARSE_ERROR",
                    message="response is not a JSON object",
                    raw=raw_base,
                )
            ]
        if str(body.get("rt_cd", "")).strip() != "0":
            return [
                BrokerOrderStatus(
                    order_id=order_id,
                    symbol=pdno or "",
                    side=None,
                    quantity=None,
                    filled_quantity=None,
                    remaining_quantity=None,
                    order_price=None,
                    avg_fill_price=None,
                    status="KIS_QUERY_ERROR",
                    message=str(body.get("msg1") or body.get("msg_cd") or "rt_cd not 0"),
                    raw=raw_base,
                )
            ]
        out1 = body.get("output1") or body.get("Output1")
        rows: list[Any] = out1 if isinstance(out1, list) else ([] if out1 is None else [out1])
        statuses: list[BrokerOrderStatus] = []
        oid_needle = str(order_id).strip() if order_id else None
        for row in rows:
            if not isinstance(row, dict):
                continue
            roid = self._pick_str(row, ("odno", "ODNO", "ord_no"))
            if oid_needle and roid and str(roid).strip() != oid_needle:
                continue
            sym = self._pick_str(row, ("pdno", "PDNO")) or (pdno or "")
            oqty = self._pick_int(row, ("ord_qty", "ORD_QTY", "ord_qty"))
            fq = self._pick_int(row, ("tot_ccld_qty", "TOT_CCLD_QTY", "ccld_qty"))
            rq = self._pick_int(row, ("rmnd_qty", "RMND_QTY", "nccs_qty"))
            if rq is None and oqty is not None and fq is not None:
                rq = max(0, oqty - fq)
            op = self._pick_float(row, ("ord_unpr", "ORD_UNPR", "ord_unpr"))
            ap = self._pick_float(row, ("avg_prvs", "AVG_PRVS", "avg_ccld_unpr"))
            side_code = self._pick_str(row, ("sll_buy_dvsn_cd", "SLL_BUY_DVSN_CD"))
            side = "BUY" if side_code in ("02", "2") else ("SELL" if side_code in ("01", "1") else side_code)
            st, msg = self._infer_order_row_status(row, oqty, fq)
            one_raw = {**raw_base, "matched_row": dict(row)}
            statuses.append(
                BrokerOrderStatus(
                    order_id=str(roid) if roid else order_id,
                    symbol=str(sym).zfill(6) if sym and str(sym).isdigit() else (sym or ""),
                    side=side,
                    quantity=oqty,
                    filled_quantity=fq,
                    remaining_quantity=rq,
                    order_price=op,
                    avg_fill_price=ap,
                    status=st,
                    message=msg,
                    raw=one_raw,
                )
            )
        if not statuses and order_id:
            statuses.append(
                BrokerOrderStatus(
                    order_id=order_id,
                    symbol=pdno or "",
                    side=None,
                    quantity=None,
                    filled_quantity=None,
                    remaining_quantity=None,
                    order_price=None,
                    avg_fill_price=None,
                    status="NOT_FOUND",
                    message="no matching rows in inquire-daily-ccld output1",
                    raw=raw_base,
                )
            )
        return statuses

    def _inquire_headers(self, tr_id: str) -> dict[str, str]:
        tok = self.get_access_token()
        return {
            "authorization": f"Bearer {tok}",
            "appkey": self._config.app_key,
            "appsecret": self._config.app_secret,
            "tr_id": tr_id,
            "custtype": "P",
        }

    @staticmethod
    def _pick_str(row: dict[str, Any], keys: tuple[str, ...]) -> str | None:
        for k in keys:
            v = row.get(k)
            if v is not None and str(v).strip():
                return str(v).strip()
        return None

    @staticmethod
    def _pick_int(row: dict[str, Any], keys: tuple[str, ...]) -> int | None:
        for k in keys:
            v = row.get(k)
            if v is None or str(v).strip() == "":
                continue
            try:
                return int(float(str(v).replace(",", "")))
            except (TypeError, ValueError):
                continue
        return None

    @staticmethod
    def _pick_float(row: dict[str, Any], keys: tuple[str, ...]) -> float | None:
        for k in keys:
            v = row.get(k)
            if v is None or str(v).strip() == "":
                continue
            try:
                return float(str(v).replace(",", ""))
            except (TypeError, ValueError):
                continue
        return None

    @staticmethod
    def _infer_order_row_status(
        row: dict[str, Any],
        ord_qty: int | None,
        filled: int | None,
    ) -> tuple[str, str]:
        """체결/미체결 코드가 있으면 우선, 없으면 수량으로 추정."""
        for k in ("ord_stts", "ORD_STTS", "prcs_stat_name", "ccld_dvsn_name"):
            v = row.get(k)
            if v is not None and str(v).strip():
                return "REPORTED", str(v).strip()
        if ord_qty is not None and filled is not None:
            if filled >= ord_qty > 0:
                return "FILLED", "filled_qty >= ord_qty"
            if filled > 0:
                return "PARTIALLY_FILLED", "partial fill"
            return "OPEN_OR_UNKNOWN", "no fills in row"
        return "UNKNOWN", "could not infer status from row"

    def _tr_id_cash_buy(self) -> str:
        """모의 `VTTC0802U` / 실전 `TTTC0802U` (KIS 국내 현금 매수 TR)."""
        return "VTTC0802U" if not self._config.is_live else "TTTC0802U"

    def get_access_token(self) -> str:
        now = time.monotonic()
        if self._access_token and now < self._access_token_expires_at:
            return self._access_token

        cached = load_cached_token(
            self._token_cache_path,
            env=self._config.env,
            app_key=self._config.app_key,
        )
        if cached is not None:
            self._access_token = cached.access_token
            try:
                expires_at = datetime.fromisoformat(cached.expires_at).astimezone(UTC)
                remaining = max(60.0, (expires_at - datetime.now(UTC)).total_seconds() - 30.0)
            except ValueError:
                remaining = 60.0
            self._access_token_expires_at = now + remaining
            return cached.access_token

        url = f"{self._config.base_url.rstrip('/')}/oauth2/tokenP"
        body = {
            "grant_type": "client_credentials",
            "appkey": self._config.app_key,
            "appsecret": self._config.app_secret,
        }
        headers = {"content-type": "application/json; charset=utf-8"}
        resp = self._session.post(url, headers=headers, data=json.dumps(body), timeout=30)
        resp.raise_for_status()
        data = resp.json()
        token = data.get("access_token")
        if not token or not isinstance(token, str):
            raise BrokerError(f"KIS token response missing access_token: {data!r}")
        try:
            expires_in = int(data.get("expires_in", 86400))
        except (TypeError, ValueError):
            expires_in = 86400
        self._access_token = token
        self._access_token_expires_at = now + max(60, expires_in - 120)
        save_cached_token(
            self._token_cache_path,
            token,
            max(60, expires_in - 120),
            env=self._config.env,
            app_key=self._config.app_key,
            token_type=data.get("token_type") if isinstance(data.get("token_type"), str) else None,
        )
        return token

    def check_connection(self) -> bool:
        self.get_access_token()
        return True

    def build_order_payload(self, request: BrokerOrderRequest) -> dict[str, Any]:
        side = (request.side or "").strip().upper()
        if side != "BUY":
            raise BrokerError(f"KIS domestic cash path supports BUY only, got {request.side!r}")
        ot = (request.order_type or "").strip().upper()
        if ot != "LIMIT":
            raise BrokerError(f"only LIMIT orders supported, got {request.order_type!r}")
        if request.quantity is None or int(request.quantity) <= 0:
            raise BrokerError("quantity must be a positive integer")
        if request.limit_price is None:
            raise BrokerError("limit_price is required for LIMIT orders")
        lim = float(request.limit_price)
        if lim <= 0:
            raise BrokerError("limit_price must be > 0")

        sym = (request.symbol or "").strip()
        pdno = sym.zfill(6) if re.fullmatch(r"\d{1,6}", sym) else sym
        if not re.fullmatch(r"\d{6}", pdno):
            raise BrokerError(
                f"KIS domestic PDNO must be 6 digits, got symbol={request.symbol!r} → {pdno!r}"
            )

        cano = self._config.account_no.strip()
        acnt = self._config.account_product_code.strip()
        if len(cano) != 8 or not cano.isdigit():
            raise BrokerError("KIS_ACCOUNT_NO must be 8-digit CANO for order payload")
        if len(acnt) != 2 or not acnt.isdigit():
            raise BrokerError("KIS_ACCOUNT_PRODUCT_CODE must be 2-digit ACNT_PRDT_CD")

        return {
            "CANO": cano,
            "ACNT_PRDT_CD": acnt,
            "PDNO": pdno,
            "ORD_DVSN": "00",
            "ORD_QTY": str(int(request.quantity)),
            "ORD_UNPR": str(int(round(lim))),
        }

    def _order_headers(self) -> dict[str, str]:
        tok = self.get_access_token()
        return {
            "authorization": f"Bearer {tok}",
            "appkey": self._config.app_key,
            "appsecret": self._config.app_secret,
            "tr_id": self._tr_id_cash_buy(),
            "custtype": "P",
        }

    def place_order(
        self,
        request: BrokerOrderRequest,
        *,
        execute: bool = False,
    ) -> BrokerOrderResult:
        try:
            payload = self.build_order_payload(request)
        except BrokerError as e:
            return BrokerOrderResult(
                symbol=request.symbol,
                side=request.side,
                quantity=int(request.quantity),
                order_type=request.order_type,
                status="KIS_ORDER_BUILD_FAILED",
                broker_order_id=None,
                submitted_price=request.limit_price,
                message=str(e),
                raw={
                    "error": str(e),
                    "실제_주문_없음": True,
                },
            )

        preview: dict[str, Any] = {
            "kis_payload": payload,
            "tr_id": self._tr_id_cash_buy(),
            "endpoint": "/uapi/domestic-stock/v1/trading/order-cash",
            "kis_env": self._config.env,
        }

        if self._safe_mode:
            preview["실제_주문_없음"] = True
            return BrokerOrderResult(
                symbol=request.symbol,
                side=request.side,
                quantity=int(request.quantity),
                order_type=request.order_type,
                status="KIS_SAFE_MODE_BLOCKED",
                broker_order_id=None,
                submitted_price=request.limit_price,
                message="safe_mode=True: no KIS order HTTP.",
                raw=preview,
            )

        if not execute:
            preview["note"] = "execute=False: order POST not sent (preview only)."
            preview["실제_주문_없음"] = True
            return BrokerOrderResult(
                symbol=request.symbol,
                side=request.side,
                quantity=int(request.quantity),
                order_type=request.order_type,
                status="KIS_ORDER_SEND_BLOCKED_PHASE3",
                broker_order_id=None,
                submitted_price=request.limit_price,
                message="execute=False: no HTTP order (guard or dry path).",
                raw=preview,
            )

        headers = self._order_headers()
        resp = post_kis_order_cash_request(
            self._session,
            self._config.base_url,
            headers=headers,
            body=payload,
        )
        raw_text = resp.text
        try:
            body_json: Any = resp.json()
        except json.JSONDecodeError:
            body_json = {"_non_json_body": raw_text}

        oid: str | None = None
        if isinstance(body_json, dict):
            out = body_json.get("output") or body_json.get("Output")
            if isinstance(out, dict):
                oid = out.get("ODNO") or out.get("ORD_NO") or out.get("KRX_FWDG_ORD_ORGNO")
                if oid is not None:
                    oid = str(oid)

        ok_http = resp.status_code == 200
        rt_ok = isinstance(body_json, dict) and str(body_json.get("rt_cd", "")).strip() == "0"
        success = ok_http and rt_ok

        raw_out: dict[str, Any] = {
            "http_status": resp.status_code,
            "response_body": body_json if isinstance(body_json, dict) else str(body_json),
            "kis_payload": payload,
            "tr_id": headers.get("tr_id"),
            "실제_주문_없음": not success,
        }

        if success:
            return BrokerOrderResult(
                symbol=request.symbol,
                side=request.side,
                quantity=int(request.quantity),
                order_type=request.order_type,
                status="KIS_ORDER_SUBMITTED",
                broker_order_id=oid,
                submitted_price=request.limit_price,
                message="KIS order-cash POST completed (rt_cd=0).",
                raw=raw_out,
            )

        msg = raw_text[:500] if raw_text else str(resp.status_code)
        if isinstance(body_json, dict) and body_json.get("msg1"):
            msg = str(body_json.get("msg1"))
        return BrokerOrderResult(
            symbol=request.symbol,
            side=request.side,
            quantity=int(request.quantity),
            order_type=request.order_type,
            status="KIS_ORDER_REJECTED",
            broker_order_id=oid,
            submitted_price=request.limit_price,
            message=msg,
            raw=raw_out,
        )
