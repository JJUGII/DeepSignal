"""승인형 실매수 1회 실행 전 안전 검증 ([실전-4])."""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING

from deepsignal.live_trading.broker_interface import BrokerOrderRequest

if TYPE_CHECKING:
    from deepsignal.live_trading.trading_session import TradingSessionPolicy, TradingSessionResult
from deepsignal.live_trading.kis_config import KISConfig
from deepsignal.live_trading.live_order_plan import LiveOrderPlan


class LiveExecutionBlocked(Exception):
    """가드 실패. 메시지는 `args[0]` 또는 `errors` 리스트로 전달."""

    def __init__(self, message: str | None = None, *, errors: list[str] | None = None) -> None:
        self.errors = list(errors or ([] if message is None else [message]))
        msg = "; ".join(self.errors) if self.errors else "live execution blocked"
        super().__init__(msg)


@dataclass
class LiveExecutionPolicy:
    """단발 실매수 한도·허용 조건 (기본은 소액·1건)."""

    max_total_order_value: float = 100_000.0
    max_single_order_value: float = 50_000.0
    max_orders: int = 1
    allow_live_env: bool = False
    require_final_confirm_text: str = "I_UNDERSTAND_REAL_ORDER"
    allow_symbols: list[str] | None = None
    require_trading_session: bool = True


def _order_value(req: BrokerOrderRequest) -> float:
    if req.estimated_value is not None and float(req.estimated_value) > 0:
        return float(req.estimated_value)
    if req.limit_price is not None:
        return float(req.limit_price) * int(req.quantity)
    return 0.0


def validate_live_execution(
    plan: LiveOrderPlan,
    requests: list[BrokerOrderRequest],
    policy: LiveExecutionPolicy,
    config: KISConfig,
    *,
    approved: bool,
    execute: bool,
    final_confirm: str | None,
    session_now: datetime | None = None,
    session_policy: "TradingSessionPolicy | None" = None,
) -> tuple[bool, list[str]]:
    """
    실매수 직전 검증. (True, []) 이면 통과.

    - `KIS_ENV=live` 및 `policy.allow_live_env` 필수.
    - 주문 수·금액·BUY/LIMIT·6자리 종목·allow_symbols 화이트리스트.
    """
    errs: list[str] = []

    if policy.require_trading_session and execute:
        from deepsignal.live_trading.trading_session import (
            is_trading_session_open,
            load_trading_session_policy_from_env,
        )

        sp = session_policy or load_trading_session_policy_from_env()
        sr = is_trading_session_open(now=session_now, policy=sp)
        if not sr.is_open:
            errs.append(f"trading session closed: {sr.reason}")

    if not approved:
        errs.append("approved must be True")
    if not execute:
        errs.append("execute must be True for live path")
    fc = (final_confirm or "").strip()
    if fc != policy.require_final_confirm_text:
        errs.append(
            f"final_confirm must be exactly {policy.require_final_confirm_text!r}, "
            f"got {final_confirm!r}"
        )
    if not policy.allow_live_env:
        errs.append("allow_live_env policy flag must be True (--allow-live-env)")
    if (config.env or "").strip().lower() != "live":
        errs.append("KIS_ENV must be 'live' for real order submission")

    if plan.status != "PENDING_APPROVAL":
        errs.append(f"plan.status must be PENDING_APPROVAL, got {plan.status!r}")
    if not plan.approval_required:
        errs.append("plan.approval_required must be true")

    if len(requests) > int(policy.max_orders):
        errs.append(f"order count {len(requests)} exceeds max_orders={policy.max_orders}")

    allow = policy.allow_symbols
    if allow is not None and len(allow) == 0:
        errs.append("allow_symbols is set but empty (no symbols permitted)")
    if allow is not None:
        allow_set = {s.strip().zfill(6) if s.strip().isdigit() else s.strip() for s in allow}
        for i, r in enumerate(requests):
            sym = (r.symbol or "").strip().zfill(6) if re.fullmatch(r"\d{1,6}", (r.symbol or "").strip()) else (r.symbol or "").strip()
            if sym not in allow_set:
                errs.append(f"requests[{i}] symbol {r.symbol!r} not in allow_symbols whitelist")

    total_val = 0.0
    for i, r in enumerate(requests):
        if (r.side or "").strip().upper() != "BUY":
            errs.append(f"requests[{i}]: only BUY allowed, got {r.side!r}")
        if (r.order_type or "").strip().upper() != "LIMIT":
            errs.append(f"requests[{i}]: only LIMIT allowed, got {r.order_type!r}")
        if int(r.quantity) <= 0:
            errs.append(f"requests[{i}]: quantity must be > 0")
        if r.limit_price is None or float(r.limit_price) <= 0:
            errs.append(f"requests[{i}]: limit_price must be > 0")
        sym = (r.symbol or "").strip()
        pdno = sym.zfill(6) if re.fullmatch(r"\d{1,6}", sym) else sym
        if not re.fullmatch(r"\d{6}", pdno):
            errs.append(f"requests[{i}]: symbol must be domestic 6-digit code, got {r.symbol!r}")
        ov = _order_value(r)
        total_val += ov
        if ov > float(policy.max_single_order_value):
            errs.append(
                f"requests[{i}]: order value {ov} exceeds max_single_order_value="
                f"{policy.max_single_order_value}"
            )

    if total_val > float(policy.max_total_order_value):
        errs.append(
            f"total order value {total_val} exceeds max_total_order_value={policy.max_total_order_value}"
        )

    return (len(errs) == 0, errs)


def session_blocked_errors_only(errors: list[str]) -> bool:
    """오류가 전부 trading session 관련인지."""
    if not errors:
        return False
    return all("trading session closed" in e for e in errors)
