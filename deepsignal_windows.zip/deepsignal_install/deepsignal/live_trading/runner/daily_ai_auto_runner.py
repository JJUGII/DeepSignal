"""Daily AI auto trading loop — plan, Telegram approval, execute, report."""

from __future__ import annotations

import json
import signal
import sys
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, time as dt_time
from pathlib import Path
from typing import Any, Callable

from deepsignal.live_trading.daily_ai_trading_workflow import (
    build_daily_ai_trade_report,
    run_daily_ai_trade_plan,
)
from deepsignal.live_trading.telegram_approval import (
    APPROVAL_STATUS_PENDING,
    create_telegram_approval_request,
    load_latest_request,
    load_telegram_config_from_env,
    TelegramApprovalConfig,
)
from deepsignal.live_trading.inactive_auto_execute import (
    execute_kis_plan_inactive_auto,
    notify_inactive_kis_execution,
    try_execute_pending_kis_in_inactive_window,
)
from deepsignal.live_trading.kis_stock_auto_execute_policy import (
    should_notify_kis_plan_with_no_orders,
    should_skip_kis_telegram_approval,
)
from deepsignal.live_trading.operator_inactive_window import is_inactive_auto_execute_active
from deepsignal.live_trading.telegram_auto_execute import (
    format_operator_approval_request_text,
    format_operator_daily_report_text,
    format_operator_execution_result_text,
    format_operator_no_orders_text,
    format_operator_plan_blocked_text,
    poll_telegram_approval_once,
    send_runner_telegram,
    try_resume_approved_execution,
)
from deepsignal.live_trading.time_utils import now_kst, now_kst_iso

STATE_FILENAME = "DAILY_AI_AUTO_RUNNER_STATE.json"


@dataclass
class DailyAIAutoRunnerConfig:
    broker: str = "kis"
    network: bool = True
    output_dir: str = "outputs"
    plan_time: str = "09:05"
    report_time: str = "15:40"
    max_order_value: float = 300_000.0
    max_single_order_value: float = 300_000.0
    max_total_order_value: float = 300_000.0
    max_orders: int = 1
    expires_minutes: int = 420
    poll_interval: float = 3.0
    loop_sleep_seconds: float = 15.0
    timeout_seconds: float = 10.0
    allow_test_plan_order: bool = False
    ignore_safety_block_for_test: bool = False
    plan_runner: Callable[..., Any] | None = None
    report_runner: Callable[..., Any] | None = None


@dataclass
class DailyAIAutoRunnerState:
    started_at: str = ""
    last_plan_date: str | None = None
    last_report_date: str | None = None
    last_plan_order_count: int = 0
    pending_token: str | None = None
    telegram_update_offset: int | None = None
    last_event: str = ""
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _root(output_dir: str | Path) -> Path:
    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    return root


def _state_path(output_dir: str | Path) -> Path:
    return _root(output_dir) / STATE_FILENAME


def load_runner_state(output_dir: str | Path) -> DailyAIAutoRunnerState:
    path = _state_path(output_dir)
    if not path.is_file():
        return DailyAIAutoRunnerState(started_at=now_kst_iso())
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return DailyAIAutoRunnerState(started_at=now_kst_iso())
    if not isinstance(data, dict):
        return DailyAIAutoRunnerState(started_at=now_kst_iso())
    return DailyAIAutoRunnerState(
        started_at=str(data.get("started_at") or now_kst_iso()),
        last_plan_date=data.get("last_plan_date"),
        last_report_date=data.get("last_report_date"),
        last_plan_order_count=int(data.get("last_plan_order_count") or 0),
        pending_token=data.get("pending_token"),
        telegram_update_offset=data.get("telegram_update_offset"),
        last_event=str(data.get("last_event") or ""),
        extra=dict(data.get("extra") or {}),
    )


def save_runner_state(output_dir: str | Path, state: DailyAIAutoRunnerState) -> None:
    path = _state_path(output_dir)
    path.write_text(json.dumps(state.to_dict(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _parse_hhmm(value: str) -> dt_time:
    parts = str(value).strip().split(":")
    if len(parts) < 2:
        raise ValueError(f"invalid time {value!r}, expected HH:MM")
    return dt_time(int(parts[0]), int(parts[1]))


def _today_key(now: datetime | None = None) -> str:
    return (now or now_kst()).date().isoformat()


def _due_scheduled(last_date: str | None, hhmm: str, now: datetime | None = None) -> bool:
    current = now or now_kst()
    if last_date == _today_key(current):
        return False
    return current.time() >= _parse_hhmm(hhmm)


def _pending_approval_state(output_dir: str | Path) -> dict[str, Any]:
    state = load_latest_request(output_dir)
    if not state:
        return {}
    if str(state.get("status") or "") != APPROVAL_STATUS_PENDING:
        return {}
    from deepsignal.live_trading.telegram.approval import _state_expired

    if _state_expired(state):
        return {}
    return state


def _telegram_cfg(runner: DailyAIAutoRunnerConfig, *, send: bool = True) -> TelegramApprovalConfig:
    return load_telegram_config_from_env(
        output_dir=runner.output_dir,
        expires_minutes=int(runner.expires_minutes),
        max_total_order_value=float(runner.max_total_order_value),
        max_single_order_value=float(runner.max_single_order_value),
        max_orders=int(runner.max_orders),
        send=bool(send),
        timeout_seconds=float(runner.timeout_seconds),
    )


def run_morning_plan(
    runner: DailyAIAutoRunnerConfig,
    *,
    db_path: str,
    state: DailyAIAutoRunnerState,
) -> DailyAIAutoRunnerState:
    plan_fn = runner.plan_runner or run_daily_ai_trade_plan
    plan = plan_fn(
        db_path,
        broker=runner.broker,
        network=runner.network,
        output_dir=runner.output_dir,
        max_order_value=runner.max_order_value,
        allow_test_plan_order=runner.allow_test_plan_order,
        ignore_safety_block_for_test=runner.ignore_safety_block_for_test,
        debug_plan=False,
    )
    state.last_plan_date = _today_key()
    state.last_plan_order_count = int(plan.order_count)
    state.last_event = f"plan_done orders={plan.order_count}"
    tg = _telegram_cfg(runner)
    if not tg.bot_token or not tg.allowed_chat_id:
        state.last_event = "plan_done telegram_config_missing"
        return state

    if plan.order_count <= 0:
        if should_notify_kis_plan_with_no_orders():
            send_runner_telegram(text=format_operator_no_orders_text(), config=tg)
        state.pending_token = None
        state.last_event = "plan_done_no_orders"
        return state

    plan_path = plan.latest_order_plan_json
    if should_skip_kis_telegram_approval():
        execution = execute_kis_plan_inactive_auto(
            plan_path,
            db_path=db_path,
            output_dir=runner.output_dir,
            tg_config=tg,
            max_single_order_value=runner.max_single_order_value,
            max_total_order_value=runner.max_total_order_value,
            max_orders=runner.max_orders,
        )
        notify_inactive_kis_execution(execution=execution, plan_path=plan_path, tg_config=tg)
        state.pending_token = None
        from deepsignal.live_trading.kis_stock_auto_execute_policy import is_kis_stock_auto_execute_without_approval

        tag = "kis_stock_auto" if is_kis_stock_auto_execute_without_approval() else "inactive_auto"
        state.last_event = f"{tag}_execute success={execution.success}"
        return state

    request, _, _ = create_telegram_approval_request(plan_path, _telegram_cfg(runner, send=False))
    if request.status != APPROVAL_STATUS_PENDING:
        send_runner_telegram(text=format_operator_plan_blocked_text(request.status), config=tg)
        state.pending_token = None
        return state

    text = format_operator_approval_request_text(request, plan_path=plan_path)
    sent = send_runner_telegram(text=text, config=tg, reply_markup=True, token=request.token)
    if not sent.get("ok"):
        state.last_event = "telegram_send_failed"
        return state
    state.pending_token = request.token
    return state


def run_evening_report(
    runner: DailyAIAutoRunnerConfig,
    *,
    state: DailyAIAutoRunnerState,
) -> DailyAIAutoRunnerState:
    report_fn = runner.report_runner or build_daily_ai_trade_report
    report = report_fn(
        output_dir=runner.output_dir,
        broker=runner.broker,
        network=runner.network,
    )
    state.last_report_date = _today_key()
    state.last_event = "report_done"
    tg = _telegram_cfg(runner)
    if tg.bot_token and tg.allowed_chat_id:
        send_runner_telegram(text=format_operator_daily_report_text(report), config=tg)
    return state


def tick_runner(
    runner: DailyAIAutoRunnerConfig,
    *,
    db_path: str,
    state: DailyAIAutoRunnerState,
) -> DailyAIAutoRunnerState:
    if _due_scheduled(state.last_plan_date, runner.plan_time):
        state = run_morning_plan(runner, db_path=db_path, state=state)
        save_runner_state(runner.output_dir, state)

    tg = _telegram_cfg(runner)
    resume = try_resume_approved_execution(
        runner.output_dir,
        db_path=db_path,
        config=tg,
        format_result=format_operator_execution_result_text,
    )
    if resume is not None:
        state.last_event = f"resume_execution success={resume.success}"
        state.pending_token = None
        save_runner_state(runner.output_dir, state)

    inactive_exec = try_execute_pending_kis_in_inactive_window(
        runner.output_dir,
        db_path=db_path,
        tg_config=tg,
        max_single_order_value=runner.max_single_order_value,
        max_total_order_value=runner.max_total_order_value,
        max_orders=runner.max_orders,
    )
    if inactive_exec is not None:
        state.last_event = f"inactive_auto_pending success={inactive_exec.success}"
        state.pending_token = None
        save_runner_state(runner.output_dir, state)
        if _due_scheduled(state.last_report_date, runner.report_time):
            state = run_evening_report(runner, state=state)
        return state

    pending = _pending_approval_state(runner.output_dir)
    if pending and not should_skip_kis_telegram_approval():
        state.pending_token = str(pending.get("token") or "") or state.pending_token
        outcome, new_offset = poll_telegram_approval_once(
            runner.output_dir,
            db_path=db_path,
            config=tg,
            poll_interval=runner.poll_interval,
            update_offset=state.telegram_update_offset,
            format_result=format_operator_execution_result_text,
        )
        if new_offset is not None:
            state.telegram_update_offset = new_offset
        if outcome.outcome in {"executed", "execution_failed", "rejected", "expired", "blocked"}:
            state.last_event = outcome.outcome
            if outcome.outcome in {"executed", "execution_failed", "rejected", "expired"}:
                state.pending_token = None
        elif outcome.outcome != "idle":
            state.last_event = outcome.outcome

    if _due_scheduled(state.last_report_date, runner.report_time):
        state = run_evening_report(runner, state=state)

    return state


def _venv_active() -> bool:
    base = getattr(sys, "base_prefix", sys.prefix)
    if base != sys.prefix:
        return True
    if hasattr(sys, "real_prefix"):
        return True
    return "/.venv/" in sys.executable or sys.prefix.rstrip("/").endswith(".venv")


def emit_runner_startup_check() -> bool:
    """Log python/venv/pandas state; return False if required imports fail."""
    lines = [
        "[runner startup]",
        f"python: {sys.argv[0] if sys.argv else 'unknown'}",
        f"sys.executable: {sys.executable}",
        f"venv: {'true' if _venv_active() else 'false'}",
    ]
    ok = True
    for mod in ("pandas", "numpy"):
        try:
            __import__(mod)
            lines.append(f"{mod} import: OK")
        except Exception as exc:
            lines.append(f"{mod} import: FAIL ({exc})")
            ok = False
    text = "\n".join(lines)
    print(text, flush=True)
    if not ok:
        print("[runner startup] FATAL: startup dependency check failed", file=sys.stderr, flush=True)
    return ok


def run_daily_ai_auto_runner_loop(
    runner: DailyAIAutoRunnerConfig,
    *,
    db_path: str,
    max_iterations: int | None = None,
) -> None:
    if not emit_runner_startup_check():
        raise SystemExit(1)

    state = load_runner_state(runner.output_dir)
    if not state.started_at:
        state.started_at = now_kst_iso()

    stop = False

    def _handle_stop(*_args: object) -> None:
        nonlocal stop
        stop = True

    signal.signal(signal.SIGINT, _handle_stop)
    signal.signal(signal.SIGTERM, _handle_stop)

    iterations = 0
    while not stop:
        state = tick_runner(runner, db_path=db_path, state=state)
        save_runner_state(runner.output_dir, state)
        iterations += 1
        if max_iterations is not None and iterations >= max_iterations:
            break
        time.sleep(max(float(runner.loop_sleep_seconds), 1.0))

    save_runner_state(runner.output_dir, state)
