"""Binance WebSocket realtime pipeline orchestrator."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from pathlib import Path
from typing import Any

from deepsignal.market_data.binance_stream.config import BinanceStreamConfig
from deepsignal.market_data.binance_stream.models import (
    FundingSnapshot,
    OrderBookSnapshot,
    TradeTick,
)
from deepsignal.market_data.binance_stream.ohlcv import OhlcvAggregator
from deepsignal.market_data.binance_stream.parser import (
    parse_combined_message,
    parse_depth_snapshot,
    parse_mark_price,
    parse_trade,
    stream_symbol,
)
from deepsignal.market_data.binance_stream.ob_history import OrderBookHistoryRecorder
from deepsignal.market_data.binance_stream.persistence import StreamPersistence
from deepsignal.market_data.binance_stream.symbols import resolve_stream_symbols

logger = logging.getLogger(__name__)


def build_spot_stream_names(symbols: list[str], *, depth_levels: int) -> list[str]:
    depth = max(5, min(20, int(depth_levels)))
    names: list[str] = []
    for sym in symbols:
        s = sym.lower()
        names.append(f"{s}@trade")
        names.append(f"{s}@depth{depth}@100ms")
    return names


def build_futures_stream_names(symbols: list[str]) -> list[str]:
    return [f"{sym.lower()}@markPrice@1s" for sym in symbols]


def combined_ws_url(base: str, streams: list[str]) -> str:
    joined = "/".join(streams)
    return f"{base.rstrip('/')}/stream?streams={joined}"


class BinanceRealtimePipeline:
    def __init__(self, cfg: BinanceStreamConfig) -> None:
        self.cfg = cfg
        self.symbols: list[str] = []
        self.aggregators: dict[str, OhlcvAggregator] = {}
        self.orderbooks: dict[str, OrderBookSnapshot] = {}
        self.funding: dict[str, FundingSnapshot] = {}
        # GSQS: OI (미결제약정) + Long/Short 비율
        self.open_interest: dict[str, float] = {}       # symbol -> current OI
        self.open_interest_prev: dict[str, float] = {}  # symbol -> previous OI
        self.open_interest_change: dict[str, float] = {}  # symbol -> OI change %
        self.long_short_ratio: dict[str, float] = {}    # symbol -> global L/S ratio
        self.btc_tick: TradeTick | None = None
        self.persistence = StreamPersistence(
            output_dir=Path(self.cfg.output_dir),
            max_recent_trades=self.cfg.max_trades_buffered,
        )
        self.stats: dict[str, Any] = {
            "trades": 0,
            "depth_updates": 0,
            "funding_updates": 0,
            "oi_updates": 0,
            "bars_closed": 0,
            "messages": 0,
            "errors": 0,
        }
        self._last_flush = 0.0
        self._ob_recorder: OrderBookHistoryRecorder | None = None

    def prepare(self) -> list[str]:
        self.symbols = resolve_stream_symbols(self.cfg)
        self.aggregators = {
            sym: OhlcvAggregator(sym, timeframes_minutes=self.cfg.timeframes_minutes)
            for sym in self.symbols
        }
        bars_dir = Path(self.cfg.output_dir) / "bars"
        self._ob_recorder = OrderBookHistoryRecorder(
            bars_dir,
            interval_seconds=float(self.cfg.ob_snapshot_seconds),
        )
        return self.symbols

    def handle_payload(self, raw: dict[str, Any]) -> None:
        self.stats["messages"] = int(self.stats.get("messages", 0)) + 1
        stream, data = parse_combined_message(raw)
        if not stream and "e" in data:
            stream = str(data.get("e") or "")

        if "markPrice" in stream or str(data.get("e") or "") == "markPriceUpdate":
            snap = parse_mark_price(data)
            if snap and snap.symbol:
                self.funding[snap.symbol] = snap
                self.stats["funding_updates"] = int(self.stats.get("funding_updates", 0)) + 1
            return

        sym = stream_symbol(stream) if stream else str(data.get("s") or "").upper()
        if not sym:
            return

        if "@trade" in stream or str(data.get("e") or "") == "trade":
            tick = parse_trade(data)
            if tick is None or tick.price <= 0:
                return
            self.stats["trades"] = int(self.stats.get("trades", 0)) + 1
            self.persistence.record_trade(tick)
            if sym == self.cfg.btc_symbol.upper():
                self.btc_tick = tick
            agg = self.aggregators.get(sym)
            if agg:
                for bar in agg.on_trade(tick):
                    self.persistence.append_closed_bar(bar)
                    self.stats["bars_closed"] = int(self.stats.get("bars_closed", 0)) + 1
            return

        if "depth" in stream or "bids" in data or "asks" in data:
            book = parse_depth_snapshot(sym, data, ts_ms=int(data.get("E") or time.time() * 1000))
            self.orderbooks[sym] = book
            self.stats["depth_updates"] = int(self.stats.get("depth_updates", 0)) + 1
            if self._ob_recorder is not None:
                self._ob_recorder.maybe_record(book)

    def _write_feature_snapshot(self) -> None:
        try:
            from deepsignal.market_data.feature_engine.engine import FeatureEngine

            try:
                from deepsignal.market_data.feature_engine.fear_greed import update_fear_greed_cache

                update_fear_greed_cache(
                    Path(self.cfg.output_dir).parent / "fear_greed_cache.json",
                    force=False,
                )
            except Exception:
                pass
            eng = FeatureEngine(
                btc_symbol=self.cfg.btc_symbol,
                output_dir=Path(self.cfg.output_dir).parent,
            )
            if self.btc_tick is not None:
                eng.on_trade(self.btc_tick)
            for sym, book in self.orderbooks.items():
                eng.on_orderbook(book)
            for sym, agg in self.aggregators.items():
                for bar in agg.snapshot_open_bars():
                    eng.on_bar(bar)
            vectors = eng.compute_all(self.symbols)
            out = {
                sym: vec.tolist() for sym, vec in vectors.items()
            }
            path = Path(self.cfg.output_dir) / "feature_vectors.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            meta = {
                "feature_names": list(
                    __import__(
                        "deepsignal.market_data.feature_engine.spec",
                        fromlist=["FEATURE_NAMES"],
                    ).FEATURE_NAMES
                ),
                "vectors": out,
            }
            path.write_text(
                json.dumps(meta, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
        except Exception as exc:
            logger.debug("feature snapshot skip: %s", exc)

    def maybe_flush_state(self, *, force: bool = False) -> None:
        now = time.monotonic()
        if not force and (now - self._last_flush) < float(self.cfg.state_flush_seconds):
            return
        open_bars: list = []
        for agg in self.aggregators.values():
            open_bars.extend(agg.snapshot_open_bars())
        # GSQS: OI + L/S 데이터를 live_state에 포함
        oi_payload = {
            sym: {
                "oi": self.open_interest.get(sym, 0),
                "oi_change_pct": self.open_interest_change.get(sym, None),
                "long_short_ratio": self.long_short_ratio.get(sym, None),
            }
            for sym in self.symbols
        }
        self.persistence.write_live_state(
            symbols=self.symbols,
            orderbooks=self.orderbooks,
            funding=self.funding,
            open_interest=oi_payload,
            open_bars=open_bars,
            btc=self.btc_tick,
            stats=dict(self.stats),
        )
        self._last_flush = now

    async def _consume_ws(
        self,
        url: str,
        *,
        label: str,
        stop: asyncio.Event,
    ) -> None:
        import websockets

        backoff = 1.0
        while not stop.is_set():
            try:
                async with websockets.connect(
                    url,
                    ping_interval=20,
                    ping_timeout=60,
                    max_size=8 * 1024 * 1024,
                ) as ws:
                    logger.info("%s connected (%d streams in URL)", label, url.count("/") + 1)
                    backoff = 1.0
                    async for message in ws:
                        if stop.is_set():
                            break
                        try:
                            payload = json.loads(message)
                        except json.JSONDecodeError:
                            self.stats["errors"] = int(self.stats.get("errors", 0)) + 1
                            continue
                        if isinstance(payload, dict):
                            self.handle_payload(payload)
                        self.maybe_flush_state()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.stats["errors"] = int(self.stats.get("errors", 0)) + 1
                logger.warning("%s disconnected: %s — retry in %.1fs", label, exc, backoff)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2.0, 60.0)

    async def _poll_one_futures(
        self,
        session: Any,
        sym: str,
    ) -> None:
        """심볼 하나의 funding/OI/L·S를 한 번에 폴링."""
        # ① Funding rate (mark price 포함)
        try:
            async with session.get(
                "https://fapi.binance.com/fapi/v1/premiumIndex",
                params={"symbol": sym},
            ) as resp:
                if resp.status == 200:
                    d = await resp.json()
                    snap = FundingSnapshot(
                        symbol=str(d.get("symbol") or "").upper(),
                        mark_price=float(d.get("markPrice") or 0),
                        funding_rate=float(d.get("lastFundingRate") or 0),
                        next_funding_ts_ms=int(d.get("nextFundingTime") or 0),
                        ts_ms=int(d.get("time") or 0),
                    )
                    if snap.symbol:
                        self.funding[snap.symbol] = snap
                        self.stats["funding_updates"] = (
                            int(self.stats.get("funding_updates", 0)) + 1
                        )
        except Exception as exc:
            logger.debug("funding REST [%s]: %s", sym, exc)

        # ② Open Interest (미결제약정)
        try:
            async with session.get(
                "https://fapi.binance.com/fapi/v1/openInterest",
                params={"symbol": sym},
            ) as resp:
                if resp.status == 200:
                    d = await resp.json()
                    oi = float(d.get("openInterest") or 0)
                    if oi > 0:
                        prev = self.open_interest.get(sym, oi)
                        if prev > 0:
                            chg = (oi - prev) / prev * 100.0
                            self.open_interest_change[sym] = chg
                        self.open_interest_prev[sym] = prev
                        self.open_interest[sym] = oi
                        self.stats["oi_updates"] = (
                            int(self.stats.get("oi_updates", 0)) + 1
                        )
        except Exception as exc:
            logger.debug("OI REST [%s]: %s", sym, exc)

        # ③ Global Long/Short Ratio
        try:
            async with session.get(
                "https://fapi.binance.com/futures/data/globalLongShortAccountRatio",
                params={"symbol": sym, "period": "5m", "limit": "1"},
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    if data and isinstance(data, list):
                        ls = float(data[0].get("longShortRatio") or 1.0)
                        self.long_short_ratio[sym] = ls
        except Exception as exc:
            logger.debug("L/S REST [%s]: %s", sym, exc)

    async def _poll_funding_rest(self, stop: asyncio.Event) -> None:
        """fapi.binance.com REST로 60초마다 선물 데이터 폴링.

        수집 데이터: funding rate / open interest / long·short ratio
        fstream WebSocket이 지역 차단 등으로 불통일 때 백업 역할도 수행.
        """
        try:
            import aiohttp
        except ImportError:
            logger.warning("aiohttp 없음 — 선물 REST 폴링 비활성화")
            return

        interval = 60  # seconds
        first_run = True
        while not stop.is_set():
            if not first_run:
                for _ in range(interval):
                    if stop.is_set():
                        return
                    await asyncio.sleep(1.0)
            first_run = False

            if stop.is_set():
                return

            try:
                async with aiohttp.ClientSession(
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as session:
                    # 전체 심볼을 동시에 폴링 (asyncio.gather)
                    await asyncio.gather(
                        *[self._poll_one_futures(session, sym) for sym in list(self.symbols)],
                        return_exceptions=True,
                    )
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.debug("futures REST session error: %s", exc)

    async def run_async(self, *, duration_seconds: float = 0.0) -> dict[str, Any]:
        self.persistence = StreamPersistence(
            Path(self.cfg.output_dir),
            max_recent_trades=self.cfg.max_trades_buffered,
        )
        self.prepare()
        stop = asyncio.Event()
        tasks: list[asyncio.Task[None]] = []

        spot_streams = build_spot_stream_names(self.symbols, depth_levels=self.cfg.depth_levels)
        spot_url = combined_ws_url(self.cfg.spot_ws_base, spot_streams)
        tasks.append(asyncio.create_task(self._consume_ws(spot_url, label="spot", stop=stop)))

        if self.cfg.include_funding:
            fut_streams = build_futures_stream_names(self.symbols)
            fut_url = combined_ws_url(self.cfg.futures_ws_base, fut_streams)
            tasks.append(asyncio.create_task(self._consume_ws(fut_url, label="futures", stop=stop)))
            # REST 폴링 백업: fstream WS가 지역 차단 등으로 불통일 때도 funding rate 갱신
            tasks.append(asyncio.create_task(self._poll_funding_rest(stop)))

        try:
            if duration_seconds > 0:
                await asyncio.sleep(duration_seconds)
                stop.set()
            else:
                await asyncio.Event().wait()
        except asyncio.CancelledError:
            stop.set()
            raise
        finally:
            stop.set()
            for t in tasks:
                t.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            self.maybe_flush_state(force=True)
        self._write_feature_snapshot()

        stats = dict(self.stats)
        if self._ob_recorder is not None:
            stats["ob_snapshots_written"] = self._ob_recorder.snapshots_written
        return {
            "symbols": self.symbols,
            "output_dir": str(self.cfg.output_dir),
            "stats": stats,
        }


async def run_binance_stream_async(
    cfg: BinanceStreamConfig,
    *,
    duration_seconds: float = 0.0,
) -> dict[str, Any]:
    pipeline = BinanceRealtimePipeline(cfg)
    return await pipeline.run_async(duration_seconds=duration_seconds)


def run_binance_stream(
    cfg: BinanceStreamConfig,
    *,
    duration_seconds: float = 0.0,
) -> dict[str, Any]:
    return asyncio.run(run_binance_stream_async(cfg, duration_seconds=duration_seconds))
