@echo off
cd /d "%~dp0"
set ROOT=%~dp0

:: 1. Binance price stream
start /min /d "%ROOT%" "DS-Stream" cmd /k "%ROOT%.venv\Scripts\python.exe %ROOT%main.py binance-stream --output-dir outputs"
timeout /t 2 > nul

:: 2. Coin auto runner (no --execute: real orders require UPBIT_DRY_RUN=false + CRYPTO_PAPER_MODE=false in .env)
start /min /d "%ROOT%" "DS-Coin" cmd /k "%ROOT%.venv\Scripts\python.exe %ROOT%main.py crypto-auto-runner --broker upbit --interval-minutes 1.0 --take-profit-pct 2.0 --take-profit-buffer-pct 0.05 --stop-loss-pct -1.5 --stop-loss-buffer-pct 0.05 --min-volume-ratio 0.3 --crypto-universe all_krw --max-scan-markets 100 --max-orders-per-day 0 --output-dir outputs --wait-fill-seconds 60.0 --fill-poll-interval 3.0"
timeout /t 2 > nul

:: 3. Stock daily runner
start /min /d "%ROOT%" "DS-Stock" cmd /k "%ROOT%.venv\Scripts\python.exe %ROOT%main.py run-daily --log-json"
timeout /t 2 > nul

:: 4. Web UI (no-browser: background autostart does not open browser)
start /min /d "%ROOT%" "DS-WebUI" cmd /k "%ROOT%.venv\Scripts\python.exe %ROOT%main.py web-ui --no-browser"
